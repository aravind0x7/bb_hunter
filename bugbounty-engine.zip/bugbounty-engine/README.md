# 🐛 Bug Bounty Engine

**Automated. Intelligent. Always hunting.**

Runs 24/7 on your Ubuntu VPS. Control from Telegram. Wake up to findings with AI-written reports.

---

## Architecture

```
TELEGRAM BOT (/add /scan /findings /report /digest /weekly)
      │
  SCAN ENGINE  ←── background scheduler (rescan every 24h)
      │
  Phase 1: RECON
    subfinder + amass + crt.sh + Wayback Machine
    HTTP probe → JS crawl → secret detection → tech fingerprint
      │
  Phase 2: TAKEOVER CHECK
    40+ provider fingerprints (GitHub Pages, Heroku, S3, Azure, Netlify...)
      │
  Phase 3: CVE MATCH
    tech stack → NVD/CVE lookup → version fingerprint
      │
  Phase 4: PARALLEL SCAN (4 modules simultaneously)
    ┌─ VulnScanner: SQLi XSS SSRF LFI CORS IDOR JWT S3 GraphQL
    ├─ Nuclei: 10k+ community templates + 7 custom
    ├─ APIScanner: auth bypass, rate limit, mass assignment, BOLA, verb tampering
    └─ DeepFuzzer: SSTI XXE host-header CRLF cache-poison proto-pollution smuggling
      │
  Phase 5: AI TRIAGE (Claude)
    false-positive filter → CVSS scoring → exploit chain detection → bounty estimate
      │
  Phase 6: REPORTS
    HTML (dark themed) + Markdown + JSON  →  Telegram alert + web dashboard
```

---

## Quick Start

```bash
# On your VPS:
bash setup.sh
nano config/config.local.yaml   # fill in tokens
sudo systemctl start bugbounty-engine
sudo journalctl -u bugbounty-engine -f
```

---

## Telegram Bot Commands

| Command | Action |
|---------|--------|
| `/add example.com` | Add target |
| `/scan example.com` | Trigger immediate scan |
| `/findings` | All unreported findings |
| `/findings example.com` | Target-specific findings |
| `/report example.com` | Download HTML report |
| `/status` | Engine stats |
| `/stats` | Findings by severity |
| `/digest` | Today's summary with ASCII charts |
| `/weekly` | 7-day trend report |
| `/stop example.com` | Pause target |

---

## CLI

```bash
source venv/bin/activate
python main.py                       # full engine
python main.py scan example.com      # one-shot scan
python main.py add example.com       # add target
python main.py list                  # list targets
python main.py digest                # print today's digest
python main.py dashboard             # web UI at :8080
```

---

## Vulnerability Coverage

| Module | What it finds |
|--------|--------------|
| VulnScanner | SQLi, XSS, SSRF, LFI, Open Redirect, IDOR, JWT alg:none, CORS, Security headers, S3 buckets, GraphQL |
| Nuclei | 10,000+ CVE/misconfig templates + exposed .env .git phpinfo admin backup Firebase debug |
| APIScanner | Auth bypass, verb tampering, no rate-limit, mass assignment, API versioning, BOLA, JWT confusion |
| DeepFuzzer | SSTI, XXE, Host header injection, CRLF, Cache poisoning, Prototype pollution, Hidden params, Deserialization, Encoded traversal |
| TakeoverChecker | 40+ providers: GitHub Pages, Heroku, S3, Azure, Fastly, Netlify, Shopify, Surge, Ghost, Zendesk, Webflow, Bitbucket... |
| CVEChecker | Tech fingerprint → NVD CVE lookup |

---

## Project Structure

```
bugbounty-engine/
├── main.py                    # entry point
├── setup.sh                   # one-command VPS setup
├── bugbounty-engine.service   # systemd unit
├── config/config.yaml         # all settings
├── core/
│   ├── engine.py              # master orchestrator (6 phases)
│   ├── telegram_bot.py        # bot + all commands
│   ├── dashboard.py           # web UI at :8080
│   ├── digest.py              # daily/weekly reports
│   └── rate_limiter.py        # adaptive rate limiting
└── modules/
    ├── recon.py               # subdomain enum + crawl + secrets
    ├── scanner.py             # SQLi XSS SSRF CORS etc.
    ├── api_scanner.py         # API-specific attacks
    ├── fuzz.py                # SSTI XXE cache-poison etc.
    ├── nuclei_scan.py         # Nuclei runner + custom templates
    ├── takeover.py            # subdomain takeover
    ├── cve_checker.py         # CVE matching
    ├── ai_triage.py           # Claude triage + report writing
    ├── reporter.py            # HTML/MD/JSON output
    └── scope.py               # program scope enforcement
```

---

## Config Quick Reference

```yaml
telegram:
  bot_token: "YOUR_TOKEN"
  chat_id: "YOUR_CHAT_ID"
  alert_on_critical: true
  alert_on_high: true
  daily_summary: true
  summary_time: "08:00"

ai:
  api_key: "YOUR_ANTHROPIC_KEY"
  triage_enabled: true
  chain_analysis: true

scheduler:
  rescan_interval_hours: 24
  new_subdomain_alert: true
```

---

## Web Dashboard

```bash
# SSH tunnel to access from your browser:
ssh -L 8080:localhost:8080 user@your-vps
# open http://localhost:8080
```

---

## ⚠️ Legal

**Only scan targets you have explicit permission to test.**
Stay within program scope. This is for authorized security research only.
