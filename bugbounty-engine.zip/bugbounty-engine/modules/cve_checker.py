"""
modules/cve_checker.py — CVE / known-vuln checker
Maps detected technologies + versions to CVEs via:
  - NIST NVD API (free, no key needed for basic use)
  - OSV.dev (open source vulns)
  - GitHub Security Advisories
"""
import asyncio
import aiohttp
import json
import re
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

NVD_API    = "https://services.nvd.nist.gov/rest/json/cves/2.0"
OSV_API    = "https://api.osv.dev/v1/query"
GITHUB_API = "https://api.github.com/graphql"

# Known critical CVEs to always check (tech → CVEs to probe)
HIGH_VALUE_CVES = {
    "wordpress":    ["CVE-2023-2745", "CVE-2022-21663", "CVE-2021-29447"],
    "apache":       ["CVE-2021-41773", "CVE-2021-42013", "CVE-2017-7679"],
    "nginx":        ["CVE-2021-23017", "CVE-2019-9511"],
    "drupal":       ["CVE-2018-7600", "CVE-2019-6340"],
    "joomla":       ["CVE-2023-23752", "CVE-2015-8562"],
    "log4j":        ["CVE-2021-44228", "CVE-2021-45046", "CVE-2021-45105"],
    "spring":       ["CVE-2022-22965", "CVE-2022-22963"],
    "jenkins":      ["CVE-2019-1003000", "CVE-2018-1000861"],
    "confluence":   ["CVE-2022-26134", "CVE-2023-22515"],
    "gitlab":       ["CVE-2021-22205", "CVE-2023-2825"],
    "exchange":     ["CVE-2021-26855", "CVE-2021-34473"],
    "citrix":       ["CVE-2023-3519", "CVE-2019-19781"],
    "fortigate":    ["CVE-2023-27997", "CVE-2022-40684"],
    "pulse":        ["CVE-2019-11510"],
    "vmware":       ["CVE-2021-22005", "CVE-2022-22954"],
    "grafana":      ["CVE-2021-43798"],
    "redis":        ["CVE-2022-0543"],
    "elasticsearch":["CVE-2021-22144"],
    "laravel":      ["CVE-2021-3129"],
    "rails":        ["CVE-2019-5418", "CVE-2020-8163"],
}

# Version extraction patterns
VERSION_PATTERNS = {
    "wordpress":     r'<meta name="generator" content="WordPress ([0-9.]+)"',
    "apache":        r'Apache/([0-9.]+)',
    "nginx":         r'nginx/([0-9.]+)',
    "php":           r'PHP/([0-9.]+)',
    "drupal":        r'Drupal ([0-9.]+)',
    "jquery":        r'jquery[.-]([0-9.]+)',
    "bootstrap":     r'bootstrap[.-]([0-9.]+)',
    "spring":        r'Spring Framework ([0-9.]+)',
    "tomcat":        r'Apache Tomcat/([0-9.]+)',
}


class CVEChecker:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []
        timeout = aiohttp.ClientTimeout(total=15)
        self.session = aiohttp.ClientSession(timeout=timeout)

    async def close(self):
        await self.session.close()

    async def run(self, alive_hosts: list, detected_tech: list) -> list:
        log.info(f"[CVE] Checking {len(detected_tech)} technologies against CVE databases")

        tasks = []
        for tech in detected_tech:
            tech_lower = tech.lower()
            for key in HIGH_VALUE_CVES:
                if key in tech_lower:
                    tasks.append(self._check_known_cves(tech_lower, key, alive_hosts))
                    break
            tasks.append(self._nvd_search(tech_lower, alive_hosts))

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # Also check version-specific vulns
        for host in alive_hosts[:10]:
            await self._check_versions(host)

        await self._save_findings()
        log.info(f"[CVE] Found {len(self.findings)} CVE-related findings")
        return self.findings

    async def _check_known_cves(self, tech: str, key: str, hosts: list):
        cves = HIGH_VALUE_CVES.get(key, [])
        for cve_id in cves:
            details = await self._get_cve_details(cve_id)
            if not details:
                continue

            cvss = details.get("cvss", 0)
            if cvss >= 7.0:
                endpoint = hosts[0]["url"] if hosts else self.domain
                self.findings.append({
                    "vuln_type":   f"cve:{cve_id}",
                    "severity":    "critical" if cvss >= 9.0 else "high",
                    "title":       f"{cve_id} — {tech.title()} potentially vulnerable",
                    "description": details.get("description", "")[:500],
                    "endpoint":    endpoint,
                    "parameter":   "",
                    "payload":     "",
                    "evidence":    f"Tech detected: {tech} | CVSS: {cvss} | {cve_id}",
                    "cve":         cve_id,
                    "cvss":        cvss,
                    "needs_verification": True,
                })

    async def _get_cve_details(self, cve_id: str) -> dict:
        try:
            async with self.session.get(
                NVD_API,
                params={"cveId": cve_id},
                headers={"Accept": "application/json"}
            ) as resp:
                if resp.status != 200:
                    return {}
                data = await resp.json()
                vulns = data.get("vulnerabilities", [])
                if not vulns:
                    return {}

                cve    = vulns[0]["cve"]
                desc   = next((d["value"] for d in cve.get("descriptions", []) if d["lang"] == "en"), "")
                metrics = cve.get("metrics", {})

                # Try CVSS v3 first
                cvss = 0.0
                for key in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                    if key in metrics and metrics[key]:
                        cvss = metrics[key][0].get("cvssData", {}).get("baseScore", 0)
                        break

                return {"description": desc, "cvss": cvss, "cve_id": cve_id}
        except Exception as e:
            log.debug(f"[CVE] NVD lookup failed for {cve_id}: {e}")
            return {}

    async def _nvd_search(self, keyword: str, hosts: list):
        """Search NVD for recent CVEs matching a technology keyword."""
        try:
            async with self.session.get(
                NVD_API,
                params={
                    "keywordSearch": keyword,
                    "resultsPerPage": "5",
                    "cvssV3Severity": "CRITICAL",
                },
                headers={"Accept": "application/json"}
            ) as resp:
                if resp.status != 200:
                    return
                data  = await resp.json()
                vulns = data.get("vulnerabilities", [])

                for v in vulns[:3]:
                    cve    = v.get("cve", {})
                    cve_id = cve.get("id", "")
                    desc   = next((d["value"] for d in cve.get("descriptions", []) if d["lang"] == "en"), "")
                    endpoint = hosts[0]["url"] if hosts else self.domain

                    self.findings.append({
                        "vuln_type":   f"cve:{cve_id}",
                        "severity":    "high",
                        "title":       f"{cve_id} — {keyword.title()} (needs verification)",
                        "description": desc[:400],
                        "endpoint":    endpoint,
                        "parameter":   "",
                        "payload":     "",
                        "evidence":    f"Tech detected: {keyword} | Found via NVD keyword search",
                        "cve":         cve_id,
                        "needs_verification": True,
                    })
        except Exception as e:
            log.debug(f"[CVE] NVD search failed for {keyword}: {e}")

    async def _check_versions(self, host: dict):
        """Extract version numbers from response and check OSV."""
        try:
            async with self.session.get(host["url"]) as resp:
                body = await resp.text(errors="ignore")
                headers_str = str(dict(resp.headers))
                combined = body[:5000] + headers_str

                for tech, pattern in VERSION_PATTERNS.items():
                    match = re.search(pattern, combined, re.IGNORECASE)
                    if match:
                        version = match.group(1)
                        await self._osv_query(tech, version, host["url"])
        except Exception as e:
            log.debug(f"[CVE] Version check failed {host['url']}: {e}")

    async def _osv_query(self, package: str, version: str, endpoint: str):
        """Query OSV.dev for vulnerabilities in a specific package version."""
        try:
            payload = {
                "version": version,
                "package": {"name": package, "ecosystem": "npm"}
            }
            async with self.session.post(OSV_API, json=payload) as resp:
                if resp.status != 200:
                    return
                data  = await resp.json()
                vulns = data.get("vulns", [])
                for v in vulns[:2]:
                    vuln_id = v.get("id", "")
                    summary = v.get("summary", "")
                    severity = "high"
                    for sev in v.get("severity", []):
                        score = sev.get("score", "")
                        if "CVSS:3" in str(score):
                            try:
                                num = float(re.search(r'[\d.]+$', score).group())
                                severity = "critical" if num >= 9 else "high" if num >= 7 else "medium"
                            except:
                                pass

                    self.findings.append({
                        "vuln_type":   f"cve:{vuln_id}",
                        "severity":    severity,
                        "title":       f"{vuln_id} in {package} {version}",
                        "description": summary,
                        "endpoint":    endpoint,
                        "parameter":   "",
                        "payload":     "",
                        "evidence":    f"{package} v{version} detected | OSV: {vuln_id}",
                        "cve":         vuln_id,
                        "needs_verification": False,
                    })
        except Exception as e:
            log.debug(f"[CVE] OSV query failed {package}/{version}: {e}")

    async def _save_findings(self):
        if not self.findings:
            return
        db = await get_db()
        async with db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, self.domain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f["parameter"], f["payload"],
                        f["evidence"], f.get("cve", "")
                    ))
                except Exception as e:
                    log.debug(f"[CVE] DB insert: {e}")
            await db.commit()
