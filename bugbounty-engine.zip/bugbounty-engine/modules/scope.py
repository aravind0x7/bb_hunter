"""
modules/scope.py — Scope validator
Enforces bug bounty program scope rules before any request is made.
Supports: domain wildcards, IP ranges, excluded paths, platform import.
"""
import re
import ipaddress
import json
from urllib.parse import urlparse
from pathlib import Path
import aiosqlite
from core.config import load_config, DB_PATH
from core.logger import log

cfg = load_config()


class ScopeValidator:
    def __init__(self, target_id: int, domain: str):
        self.target_id  = target_id
        self.domain     = domain
        self.in_scope   = []   # list of scope patterns
        self.out_scope  = []   # explicit exclusions
        self._loaded    = False

    async def load(self):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute(
                "SELECT scope FROM targets WHERE id=?", (self.target_id,)
            )
            row = await cursor.fetchone()
        if row and row[0]:
            try:
                scope_data = json.loads(row[0])
                self.in_scope  = scope_data.get("in_scope", [])
                self.out_scope = scope_data.get("out_scope", [])
            except:
                self.in_scope = [f"*.{self.domain}", self.domain]
        else:
            # Default: everything under the root domain is in scope
            self.in_scope = [f"*.{self.domain}", self.domain]

        self._loaded = True
        log.debug(f"[SCOPE] Loaded {len(self.in_scope)} in-scope, {len(self.out_scope)} out-scope rules for {self.domain}")

    async def is_in_scope(self, url: str) -> bool:
        if not self._loaded:
            await self.load()

        parsed = urlparse(url)
        host   = parsed.hostname or url
        path   = parsed.path or "/"

        # Check explicit exclusions first
        for pattern in self.out_scope:
            if self._matches(host, path, pattern):
                log.debug(f"[SCOPE] OUT-OF-SCOPE: {url} matched exclusion: {pattern}")
                return False

        # Check inclusions
        for pattern in self.in_scope:
            if self._matches(host, path, pattern):
                return True

        log.debug(f"[SCOPE] OUT-OF-SCOPE (no match): {url}")
        return False

    def _matches(self, host: str, path: str, pattern: str) -> bool:
        """Match host/path against a scope pattern."""
        pattern = pattern.strip().lower()
        host    = host.lower()

        # URL pattern with path
        if pattern.startswith("http"):
            parsed_p = urlparse(pattern)
            if parsed_p.hostname:
                if not self._host_matches(host, parsed_p.hostname):
                    return False
                if parsed_p.path and parsed_p.path != "/":
                    return path.startswith(parsed_p.path)
                return True

        # Wildcard domain: *.example.com
        if pattern.startswith("*."):
            base = pattern[2:]
            return host == base or host.endswith("." + base)

        # IP range: 192.168.1.0/24
        if "/" in pattern:
            try:
                net = ipaddress.ip_network(pattern, strict=False)
                return ipaddress.ip_address(host) in net
            except ValueError:
                pass

        # Plain domain
        return self._host_matches(host, pattern)

    def _host_matches(self, host: str, pattern: str) -> bool:
        pattern = pattern.lower()
        if pattern.startswith("*."):
            base = pattern[2:]
            return host == base or host.endswith("." + base)
        return host == pattern

    async def set_scope(self, in_scope: list, out_scope: list = None):
        """Update scope rules in DB."""
        scope_data = {
            "in_scope":  in_scope,
            "out_scope": out_scope or [],
        }
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "UPDATE targets SET scope=? WHERE id=?",
                (json.dumps(scope_data), self.target_id)
            )
            await db.commit()
        self.in_scope  = in_scope
        self.out_scope = out_scope or []
        self._loaded   = True
        log.info(f"[SCOPE] Updated scope for {self.domain}: {len(in_scope)} in, {len(out_scope or [])} out")

    def filter_urls(self, urls: list) -> list:
        """Sync filter — use when async is not available."""
        result = []
        for url in urls:
            parsed = urlparse(url)
            host   = parsed.hostname or url
            path   = parsed.path or "/"
            for pattern in self.out_scope:
                if self._matches(host, path, pattern):
                    continue
            for pattern in self.in_scope:
                if self._matches(host, path, pattern):
                    result.append(url)
                    break
        return result


# ── Platform scope parsers ──────────────────────────────────────────────────

def parse_hackerone_scope(scope_json: dict) -> tuple:
    """
    Parse HackerOne program scope JSON into (in_scope, out_scope) lists.
    scope_json: the 'relationships.structured_scopes.data' array from H1 API
    """
    in_scope  = []
    out_scope = []
    for item in scope_json:
        attrs      = item.get("attributes", {})
        identifier = attrs.get("asset_identifier", "")
        asset_type = attrs.get("asset_type", "")
        eligible   = attrs.get("eligible_for_bounty", False)

        if asset_type not in ("URL", "WILDCARD", "DOMAIN", "IP_ADDRESS"):
            continue

        if attrs.get("instruction") == "out_of_scope":
            out_scope.append(identifier)
        elif eligible:
            in_scope.append(identifier)

    return in_scope, out_scope


def parse_bugcrowd_scope(scope_json: dict) -> tuple:
    """Parse Bugcrowd program scope JSON."""
    in_scope  = []
    out_scope = []
    for group in scope_json.get("target_groups", []):
        for target in group.get("targets", []):
            name = target.get("name", "")
            if target.get("in_scope", True):
                in_scope.append(name)
            else:
                out_scope.append(name)
    return in_scope, out_scope
