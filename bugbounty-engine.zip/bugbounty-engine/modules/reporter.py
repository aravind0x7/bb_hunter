"""
modules/reporter.py — Report generator
Outputs: Markdown, HTML, JSON
Formats for: HackerOne, Bugcrowd, Intigriti
"""
import json
import os
from datetime import datetime
from pathlib import Path
from jinja2 import Template
from core.config import load_config
from core.logger import log
from modules.ai_triage import AITriage

cfg = load_config()
OUT_DIR = Path(cfg["reporting"]["output_dir"])
OUT_DIR.mkdir(parents=True, exist_ok=True)

SEVERITY_COLORS = {
    "critical": "#d63031",
    "high":     "#e17055",
    "medium":   "#fdcb6e",
    "low":      "#74b9ff",
    "info":     "#b2bec3",
}

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bug Bounty Report — {{ target }}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0f1117; color: #e0e0e0; padding: 2rem; }
  .header { border-left: 4px solid #6c5ce7; padding-left: 1rem; margin-bottom: 2rem; }
  .header h1 { font-size: 1.8rem; color: #fff; }
  .header p  { color: #888; font-size: 0.9rem; margin-top: 0.3rem; }
  .stats { display: flex; gap: 1rem; margin-bottom: 2rem; flex-wrap: wrap; }
  .stat-card { background: #1a1d2e; border-radius: 8px; padding: 1rem 1.5rem; min-width: 120px; }
  .stat-card .num { font-size: 2rem; font-weight: 700; }
  .stat-card .lbl { font-size: 0.75rem; color: #888; text-transform: uppercase; }
  .critical .num { color: #d63031; }
  .high .num     { color: #e17055; }
  .medium .num   { color: #fdcb6e; }
  .low .num      { color: #74b9ff; }
  .finding { background: #1a1d2e; border-radius: 10px; padding: 1.5rem; margin-bottom: 1.5rem; border-left: 4px solid {{ colors['critical'] }}; }
  .finding.critical { border-color: #d63031; }
  .finding.high     { border-color: #e17055; }
  .finding.medium   { border-color: #fdcb6e; }
  .finding.low      { border-color: #74b9ff; }
  .finding.info     { border-color: #b2bec3; }
  .finding-title { font-size: 1.1rem; font-weight: 600; color: #fff; margin-bottom: 0.5rem; }
  .badges { display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 1rem; }
  .badge { font-size: 0.7rem; padding: 2px 8px; border-radius: 4px; font-weight: 600; text-transform: uppercase; }
  .badge.severity.critical { background: #d63031; color: #fff; }
  .badge.severity.high     { background: #e17055; color: #fff; }
  .badge.severity.medium   { background: #fdcb6e; color: #2d3436; }
  .badge.severity.low      { background: #74b9ff; color: #2d3436; }
  .badge.severity.info     { background: #b2bec3; color: #2d3436; }
  .badge.cvss  { background: #2d3436; color: #e0e0e0; border: 1px solid #444; }
  .badge.chain { background: #6c5ce7; color: #fff; }
  .badge.bounty { background: #00b894; color: #fff; }
  .meta { font-size: 0.82rem; color: #aaa; margin-bottom: 1rem; }
  .meta span { margin-right: 1rem; }
  .section-label { font-size: 0.7rem; text-transform: uppercase; color: #888; margin: 0.8rem 0 0.3rem; letter-spacing: 0.05em; }
  .evidence { background: #0f1117; border-radius: 6px; padding: 0.8rem; font-family: monospace; font-size: 0.78rem; overflow-x: auto; color: #a8e6cf; }
  .report-body { background: #0d1117; border-radius: 6px; padding: 1rem; font-size: 0.85rem; line-height: 1.7; white-space: pre-wrap; margin-top: 0.5rem; border: 1px solid #222; }
  .chain-box { background: #2d1b69; border-radius: 6px; padding: 0.8rem 1rem; margin-top: 0.8rem; font-size: 0.85rem; border-left: 3px solid #6c5ce7; }
  .chain-box strong { color: #a29bfe; }
  details summary { cursor: pointer; color: #a29bfe; font-size: 0.85rem; padding: 0.5rem 0; }
  h2 { color: #fff; margin: 2rem 0 1rem; font-size: 1.1rem; border-bottom: 1px solid #2d3436; padding-bottom: 0.5rem; }
</style>
</head>
<body>
<div class="header">
  <h1>🐛 Bug Bounty Report</h1>
  <p>Target: <strong>{{ target }}</strong> &nbsp;·&nbsp; Generated: {{ timestamp }} &nbsp;·&nbsp; Engine: BBE v1.0</p>
</div>

<div class="stats">
  <div class="stat-card critical"><div class="num">{{ counts.critical }}</div><div class="lbl">Critical</div></div>
  <div class="stat-card high">   <div class="num">{{ counts.high }}</div>   <div class="lbl">High</div></div>
  <div class="stat-card medium"> <div class="num">{{ counts.medium }}</div> <div class="lbl">Medium</div></div>
  <div class="stat-card low">    <div class="num">{{ counts.low }}</div>    <div class="lbl">Low</div></div>
</div>

{% if top_chain %}
<div class="chain-box" style="margin-bottom:2rem;">
  <strong>🔗 Top Exploit Chain: {{ top_chain.chain_title }}</strong><br>
  <span style="color:#e0e0e0;">{{ top_chain.chain_description }}</span><br>
  <span style="color:#6c5ce7;">Combined severity: {{ top_chain.combined_severity.upper() }}</span>
</div>
{% endif %}

<h2>Findings ({{ findings|length }})</h2>

{% for f in findings %}
<div class="finding {{ f.severity }}">
  <div class="finding-title">{{ loop.index }}. {{ f.recommended_title or f.title }}</div>
  <div class="badges">
    <span class="badge severity {{ f.severity }}">{{ f.severity }}</span>
    {% if f.cvss %}<span class="badge cvss">CVSS {{ f.cvss }}</span>{% endif %}
    {% if f.chain_with %}<span class="badge chain">⛓ Chain</span>{% endif %}
    {% if f.bounty_estimate %}<span class="badge bounty">{{ f.bounty_estimate }}</span>{% endif %}
  </div>
  <div class="meta">
    <span>📍 {{ f.endpoint }}</span>
    {% if f.parameter %}<span>🔑 param: {{ f.parameter }}</span>{% endif %}
    <span>🏷 {{ f.vuln_type }}</span>
  </div>
  {% if f.ai_analysis %}
  <div class="section-label">Impact</div>
  <div style="font-size:0.88rem;line-height:1.6;color:#ccc;margin-bottom:0.5rem;">{{ f.ai_analysis }}</div>
  {% endif %}
  {% if f.payload %}
  <div class="section-label">Payload</div>
  <div class="evidence">{{ f.payload }}</div>
  {% endif %}
  {% if f.evidence %}
  <div class="section-label">Evidence</div>
  <div class="evidence">{{ f.evidence[:300] }}</div>
  {% endif %}
  {% if f.chain_description %}
  <div class="chain-box">
    <strong>⛓ Exploit chain opportunity:</strong> {{ f.chain_description }}
  </div>
  {% endif %}
  {% if f.report_text %}
  <details>
    <summary>▶ Full platform report</summary>
    <div class="report-body">{{ f.report_text }}</div>
  </details>
  {% endif %}
</div>
{% endfor %}
</body>
</html>"""


class Reporter:
    def __init__(self, target: str, target_id: int):
        self.target    = target
        self.target_id = target_id
        self.ai        = AITriage()

    async def generate_all_reports(self, findings: list) -> dict:
        if not findings:
            log.info("[REPORTER] No findings to report")
            return {}

        # Generate AI reports for high/critical
        for f in findings:
            if f.get("severity") in ("critical", "high") and not f.get("is_false_positive"):
                f["report_text"] = await self.ai.generate_report(f, self.target)

        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        slug = self.target.replace(".", "_")
        paths = {}

        # JSON
        json_path = OUT_DIR / f"{slug}_{ts}.json"
        with open(json_path, "w") as fh:
            json.dump({"target": self.target, "findings": findings, "generated": ts}, fh, indent=2)
        paths["json"] = str(json_path)

        # Markdown
        md_path = OUT_DIR / f"{slug}_{ts}.md"
        with open(md_path, "w") as fh:
            fh.write(self._render_markdown(findings))
        paths["markdown"] = str(md_path)

        # HTML
        html_path = OUT_DIR / f"{slug}_{ts}.html"
        with open(html_path, "w") as fh:
            fh.write(self._render_html(findings))
        paths["html"] = str(html_path)

        log.info(f"[REPORTER] Reports written: {paths}")
        return paths

    def _severity_counts(self, findings):
        counts = {"critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0}
        for f in findings:
            counts[f.get("severity", "info")] = counts.get(f.get("severity", "info"), 0) + 1
        return counts

    def _render_markdown(self, findings: list) -> str:
        counts = self._severity_counts(findings)
        lines = [
            f"# Bug Bounty Report — {self.target}",
            f"Generated: {datetime.now().isoformat()}  ",
            f"",
            f"## Summary",
            f"| Severity | Count |",
            f"|----------|-------|",
            *[f"| {s.capitalize()} | {c} |" for s, c in counts.items() if c],
            f"",
            f"## Findings",
        ]
        for i, f in enumerate(findings, 1):
            lines += [
                f"",
                f"### {i}. {f.get('recommended_title', f['title'])}",
                f"**Severity:** {f['severity'].upper()} | **CVSS:** {f.get('cvss', 'N/A')} | **Bounty est:** {f.get('bounty_estimate', 'N/A')}",
                f"",
                f"**Endpoint:** `{f['endpoint']}`",
                f"**Parameter:** `{f.get('parameter', 'N/A')}`",
                f"",
                f"**Impact:** {f.get('ai_analysis', f.get('description', ''))}",
                f"",
                f"**Payload:**",
                f"```",
                f.get("payload", "N/A"),
                f"```",
                f"",
                f"**Evidence:** {f.get('evidence', 'N/A')[:200]}",
            ]
            if f.get("chain_description"):
                lines.append(f"\n> 🔗 **Chain:** {f['chain_description']}")
            if f.get("report_text"):
                lines += ["", "<details><summary>Full Report</summary>", "", f.get("report_text", ""), "", "</details>"]
        return "\n".join(lines)

    def _render_html(self, findings: list) -> str:
        counts = self._severity_counts(findings)
        top_chain = next((f.get("top_chain") for f in findings if f.get("top_chain")), None)
        tmpl = Template(HTML_TEMPLATE)
        return tmpl.render(
            target=self.target,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M"),
            findings=findings,
            counts=counts,
            top_chain=top_chain,
            colors=SEVERITY_COLORS,
        )
