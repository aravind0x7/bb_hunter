"""
modules/recon.py — Full recon pipeline
Handles: subdomain enumeration, DNS resolution, port scanning,
         HTTP probing, JS endpoint extraction, secret detection,
         tech fingerprinting
"""
import asyncio
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="bs4")
import aiohttp
import dns.resolver
import json
import re
import subprocess
import shutil
from pathlib import Path
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()
BASE_DIR = Path(__file__).resolve().parent.parent

# ── Secret patterns ────────────────────────────────────────────────────────────
SECRET_PATTERNS = {
    "aws_access_key":      r'AKIA[0-9A-Z]{16}',
    "aws_secret_key":      r'(?i)aws.{0,20}secret.{0,20}["\']([A-Za-z0-9/+=]{40})',
    "github_token":        r'ghp_[0-9a-zA-Z]{36}',
    "slack_token":         r'xox[baprs]-[0-9a-zA-Z\-]{10,72}',
    "google_api_key":      r'AIza[0-9A-Za-z\\-_]{35}',
    "stripe_key":          r'sk_live_[0-9a-zA-Z]{24}',
    "jwt_token":           r'eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',
    "private_key":         r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',
    "generic_api_key":     r'(?i)api[_-]?key["\'\s]*[=:]["\'\s]*([A-Za-z0-9]{20,40})',
    "password_in_url":     r'(?i)password=[^&\s]{4,}',
    "bearer_token":        r'(?i)bearer\s+([A-Za-z0-9\-._~+/]+=*)',
}

# ── Tech fingerprints ──────────────────────────────────────────────────────────
TECH_FINGERPRINTS = {
    "WordPress":  {"headers": [], "body": [r"wp-content", r"wp-includes"]},
    "Laravel":    {"headers": [], "body": [r"laravel_session"]},
    "Django":     {"headers": ["X-Frame-Options"], "body": [r"csrfmiddlewaretoken"]},
    "React":      {"headers": [], "body": [r"react-root", r"__REACT_DEVTOOLS"]},
    "Angular":    {"headers": [], "body": [r"ng-version", r"ng-app"]},
    "Express":    {"headers": ["X-Powered-By: Express"], "body": []},
    "Spring":     {"headers": ["X-Application-Context"], "body": []},
    "Drupal":     {"headers": [], "body": [r"Drupal\.settings"]},
    "Joomla":     {"headers": [], "body": [r"/components/com_"]},
    "Nginx":      {"headers": ["Server: nginx"], "body": []},
    "Apache":     {"headers": ["Server: Apache"], "body": []},
    "Cloudflare": {"headers": ["CF-Ray"], "body": []},
    "AWS S3":     {"headers": ["x-amz-"], "body": [r"AmazonS3"]},
    "GraphQL":    {"headers": [], "body": [r"graphql", r"__typename"]},
}


class ReconEngine:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.cfg       = cfg
        self.results   = {
            "subdomains": [],
            "alive_hosts": [],
            "endpoints": [],
            "secrets": [],
            "technologies": [],
        }
        self._session = None  # created lazily inside async context

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
    async def _get_session(self):
        """Lazily create aiohttp session inside the running event loop."""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=cfg["engine"]["request_timeout"])
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                connector=aiohttp.TCPConnector(ssl=False, limit=50),
                headers={"User-Agent": cfg["engine"]["user_agents"][0]}
            )
        return self._session



    # ── 1. Subdomain Enumeration ───────────────────────────────────────────────
    async def enumerate_subdomains(self) -> list:
        log.info(f"[RECON] Enumerating subdomains for {self.domain}")
        found = set()

        # Method A: external tools (subfinder, amass)
        for tool, args in [
            ("subfinder", ["subfinder", "-d", self.domain, "-silent", "-all"]),
            ("amass",     ["amass", "enum", "-passive", "-d", self.domain, "-silent"]),
        ]:
            if shutil.which(tool):
                try:
                    proc = subprocess.run(args, capture_output=True, text=True, timeout=120)
                    for line in proc.stdout.strip().split("\n"):
                        line = line.strip()
                        if line and self.domain in line:
                            found.add(line.lower())
                except Exception as e:
                    log.warning(f"[RECON] {tool} failed: {e}")

        # Method B: DNS bruteforce from wordlist
        wordlist_path = BASE_DIR / cfg["recon"]["subdomain_wordlist"]
        if wordlist_path.exists():
            with open(wordlist_path) as f:
                words = [w.strip() for w in f.readlines() if w.strip()]
            found.update(await self._dns_bruteforce(words))

        # Method C: Certificate Transparency (crt.sh)
        found.update(await self._crtsh_lookup())

        # Method D: Wayback Machine
        found.update(await self._wayback_subdomains())

        subdomains = list(found)
        log.info(f"[RECON] Found {len(subdomains)} subdomains for {self.domain}")
        self.results["subdomains"] = subdomains
        await self._save_subdomains(subdomains)
        return subdomains

    async def _dns_bruteforce(self, words: list) -> set:
        found = set()
        resolver = dns.resolver.Resolver()
        resolver.nameservers = cfg["recon"]["dns_resolvers"]

        async def resolve(word):
            host = f"{word}.{self.domain}"
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, resolver.resolve, host, "A")
                return host
            except:
                return None

        tasks = [resolve(w) for w in words[:2000]]  # cap for speed
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for r in results:
            if isinstance(r, str):
                found.add(r)
        return found

    async def _crtsh_lookup(self) -> set:
        found = set()
        try:
            url = f"https://crt.sh/?q=%.{self.domain}&output=json"
            async with self._session.get(url) as resp:
                data = await resp.json(content_type=None)
                for entry in data:
                    names = entry.get("name_value", "").split("\n")
                    for name in names:
                        name = name.strip().lstrip("*.")
                        if self.domain in name:
                            found.add(name.lower())
        except Exception as e:
            log.warning(f"[RECON] crt.sh failed: {e}")
        return found

    async def _wayback_subdomains(self) -> set:
        found = set()
        try:
            url = f"http://web.archive.org/cdx/search/cdx?url=*.{self.domain}&output=json&fl=original&collapse=urlkey&limit=10000"
            async with self._session.get(url, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                data = await resp.json(content_type=None)
                for entry in data[1:]:
                    parsed = urlparse(entry[0])
                    if parsed.hostname and self.domain in parsed.hostname:
                        found.add(parsed.hostname.lower())
        except Exception as e:
            log.warning(f"[RECON] Wayback subdomains failed: {e}")
        return found

    async def _save_subdomains(self, subdomains: list):
        import aiosqlite
        from core.config import DB_PATH
        async with aiosqlite.connect(DB_PATH) as db:
            for sub in subdomains:
                try:
                    await db.execute(
                        "INSERT OR IGNORE INTO subdomains (target_id, subdomain) VALUES (?,?)",
                        (self.target_id, sub)
                    )
                except:
                    pass
            await db.commit()

    # ── 2. HTTP Probing ────────────────────────────────────────────────────────
    async def probe_alive_hosts(self, subdomains: list) -> list:
        log.info(f"[RECON] Probing {len(subdomains)} hosts")
        alive = []

        async def probe(sub):
            for scheme in ["https", "http"]:
                url = f"{scheme}://{sub}"
                try:
                    async with self._session.get(url, allow_redirects=True) as resp:
                        title = await self._extract_title(resp)
                        info = {
                            "url": url,
                            "subdomain": sub,
                            "status": resp.status,
                            "title": title,
                            "headers": dict(resp.headers),
                            "tech": self._fingerprint_tech(dict(resp.headers), ""),
                        }
                        alive.append(info)
                        return info
                except:
                    continue

        tasks = [probe(sub) for sub in subdomains]
        chunk_size = 30
        for i in range(0, len(tasks), chunk_size):
            chunk = await asyncio.gather(*tasks[i:i+chunk_size], return_exceptions=True)
            await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

        self.results["alive_hosts"] = alive
        log.info(f"[RECON] {len(alive)} alive hosts")
        return alive

    async def _extract_title(self, resp) -> str:
        try:
            html = await resp.text(errors="ignore")
            soup = BeautifulSoup(html, "html.parser")
            tag  = soup.find("title")
            return tag.text.strip()[:120] if tag else ""
        except:
            return ""

    # ── 3. JS Crawl & Endpoint Extraction ─────────────────────────────────────
    async def crawl_endpoints(self, alive_hosts: list) -> list:
        log.info(f"[RECON] Crawling JS + endpoints on {len(alive_hosts)} hosts")
        all_endpoints = []

        for host in alive_hosts[:50]:  # cap to avoid insane runtime
            url = host["url"]
            endpoints = await self._crawl_url(url)
            all_endpoints.extend(endpoints)

        # Deduplicate
        seen = set()
        unique = []
        for ep in all_endpoints:
            key = ep.get("url", "")
            if key not in seen:
                seen.add(key)
                unique.append(ep)

        self.results["endpoints"] = unique
        log.info(f"[RECON] Found {len(unique)} unique endpoints")
        return unique

    async def _crawl_url(self, base_url: str, depth: int = 0) -> list:
        max_depth = cfg["recon"]["crawl_depth"]
        if depth > max_depth:
            return []
        endpoints = []

        try:
            async with self._session.get(base_url) as resp:
                html = await resp.text(errors="ignore")
                soup = BeautifulSoup(html, "html.parser")

                # Extract links
                for tag in soup.find_all(["a", "form", "script", "link", "img"]):
                    url = tag.get("href") or tag.get("src") or tag.get("action")
                    if not url:
                        continue
                    full_url = urljoin(base_url, url)
                    if self.domain in full_url:
                        endpoints.append({
                            "url": full_url,
                            "type": tag.name,
                            "method": tag.get("method", "GET").upper() if tag.name == "form" else "GET",
                        })

                # Extract JS files and parse them
                if cfg["recon"]["crawl_js"]:
                    js_urls = [
                        urljoin(base_url, s.get("src"))
                        for s in soup.find_all("script", src=True)
                        if self.domain in urljoin(base_url, s.get("src", ""))
                    ]
                    for js_url in js_urls[:10]:
                        js_endpoints = await self._parse_js(js_url)
                        endpoints.extend(js_endpoints)

        except Exception as e:
            log.debug(f"[RECON] Crawl failed {base_url}: {e}")

        return endpoints

    async def _parse_js(self, js_url: str) -> list:
        endpoints = []
        patterns = [
            r'["\'](/[a-zA-Z0-9_\-/]+)["\']',
            r'fetch\(["\']([^"\']+)["\']',
            r'axios\.\w+\(["\']([^"\']+)["\']',
            r'url:\s*["\']([^"\']+)["\']',
            r'endpoint["\']?\s*:\s*["\']([^"\']+)["\']',
            r'api["\']?\s*:\s*["\']([^"\']+)["\']',
        ]
        try:
            async with self._session.get(js_url) as resp:
                content = await resp.text(errors="ignore")

                # Check for secrets
                if cfg["recon"]["find_secrets"]:
                    secrets = self._find_secrets(content, js_url)
                    self.results["secrets"].extend(secrets)

                for pattern in patterns:
                    for match in re.findall(pattern, content):
                        if len(match) > 1 and not match.startswith("//"):
                            endpoints.append({
                                "url": match,
                                "type": "js_extracted",
                                "source": js_url,
                                "method": "GET",
                            })
        except Exception as e:
            log.debug(f"[RECON] JS parse failed {js_url}: {e}")
        return endpoints

    def _find_secrets(self, content: str, source: str) -> list:
        found = []
        for name, pattern in SECRET_PATTERNS.items():
            matches = re.findall(pattern, content)
            for match in matches:
                value = match if isinstance(match, str) else match[0] if match else ""
                if len(value) > 4:
                    found.append({
                        "type": name,
                        "value": value[:50] + "...",  # truncate for safety
                        "source": source,
                        "severity": "critical" if "key" in name or "token" in name else "high",
                    })
        return found

    # ── 4. Tech Fingerprinting ─────────────────────────────────────────────────
    def _fingerprint_tech(self, headers: dict, body: str) -> list:
        detected = []
        headers_str = " ".join(f"{k}: {v}" for k, v in headers.items())

        for tech, sigs in TECH_FINGERPRINTS.items():
            for pattern in sigs["headers"]:
                if pattern.lower() in headers_str.lower():
                    detected.append(tech)
                    break
            for pattern in sigs["body"]:
                if re.search(pattern, body, re.IGNORECASE):
                    if tech not in detected:
                        detected.append(tech)
                    break
        return detected

    # ── 5. Port Scanning ──────────────────────────────────────────────────────
    async def port_scan(self, host: str) -> list:
        if not shutil.which("nmap"):
            log.warning("[RECON] nmap not found, skipping port scan")
            return []
        try:
            top_n = cfg["recon"]["port_scan_top_ports"]
            args  = ["nmap", "-T4", "--open", f"--top-ports={top_n}", "-oG", "-", host]
            proc  = subprocess.run(args, capture_output=True, text=True, timeout=120)
            ports = re.findall(r'(\d+)/open', proc.stdout)
            return [int(p) for p in ports]
        except Exception as e:
            log.warning(f"[RECON] Port scan failed {host}: {e}")
            return []

    # ── Master run ─────────────────────────────────────────────────────────────
    async def run(self) -> dict:
        await self._get_session()  # ensure session in event loop
        try:
            subdomains  = await self.enumerate_subdomains()
            alive_hosts = await self.probe_alive_hosts(subdomains)
            endpoints   = await self.crawl_endpoints(alive_hosts)

            # Save tech info back to DB
            import aiosqlite
            from core.config import DB_PATH
            async with aiosqlite.connect(DB_PATH) as db:
                for host in alive_hosts:
                    await db.execute(
                        """UPDATE subdomains
                           SET tech=?, status='alive', last_seen=CURRENT_TIMESTAMP
                           WHERE target_id=? AND subdomain=?""",
                        (json.dumps(host.get("tech", [])), self.target_id, host["subdomain"])
                    )
                await db.commit()

            return self.results
        finally:
            await self.close()
