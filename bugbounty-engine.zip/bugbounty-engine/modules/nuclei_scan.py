"""
modules/nuclei_scan.py — Nuclei template engine integration
Runs community + custom nuclei templates, parses JSON output,
maps severity, integrates findings into the DB pipeline.
"""
import asyncio
import json
import shutil
import subprocess
from pathlib import Path
from core.config import load_config, get_db
from core.logger import log

cfg      = load_config()
BASE_DIR = Path(__file__).resolve().parent.parent
TMPL_DIR = BASE_DIR / "data" / "nuclei-templates"

# Severity mapping nuclei → our system
SEVERITY_MAP = {
    "critical": "critical",
    "high":     "high",
    "medium":   "medium",
    "low":      "low",
    "info":     "info",
    "unknown":  "low",
}

# Which template tags to run (comma-separated for nuclei -tags)
DEFAULT_TAGS = "cve,sqli,xss,ssrf,lfi,rce,oast,misconfig,exposed,token,jwt,cors,redirect,takeover"

CUSTOM_TEMPLATES = """
# ── Custom Template: Exposed .git directory ──────────────────────────────────
id: exposed-git-dir

info:
  name: Exposed .git directory
  author: bbe
  severity: high
  tags: exposure,git,misconfig

requests:
  - method: GET
    path:
      - "{{BaseURL}}/.git/HEAD"
      - "{{BaseURL}}/.git/config"
    matchers:
      - type: word
        words:
          - "ref: refs/"
          - "[core]"

---
# ── Custom Template: Exposed .env file ──────────────────────────────────────
id: exposed-env-file

info:
  name: Exposed .env file
  author: bbe
  severity: critical
  tags: exposure,config,misconfig

requests:
  - method: GET
    path:
      - "{{BaseURL}}/.env"
      - "{{BaseURL}}/.env.local"
      - "{{BaseURL}}/.env.production"
      - "{{BaseURL}}/.env.backup"
    matchers:
      - type: word
        words:
          - "APP_KEY"
          - "DB_PASSWORD"
          - "SECRET_KEY"
          - "API_KEY"

---
# ── Custom Template: Exposed phpinfo ────────────────────────────────────────
id: exposed-phpinfo

info:
  name: PHPInfo page exposed
  author: bbe
  severity: medium
  tags: exposure,php

requests:
  - method: GET
    path:
      - "{{BaseURL}}/phpinfo.php"
      - "{{BaseURL}}/info.php"
      - "{{BaseURL}}/php_info.php"
    matchers:
      - type: word
        words:
          - "PHP Version"
          - "phpinfo()"

---
# ── Custom Template: Admin panel exposed ────────────────────────────────────
id: exposed-admin-panel

info:
  name: Admin panel accessible
  author: bbe
  severity: high
  tags: exposure,admin

requests:
  - method: GET
    path:
      - "{{BaseURL}}/admin"
      - "{{BaseURL}}/admin/login"
      - "{{BaseURL}}/administrator"
      - "{{BaseURL}}/wp-admin"
      - "{{BaseURL}}/dashboard"
      - "{{BaseURL}}/manage"
      - "{{BaseURL}}/control"
      - "{{BaseURL}}/cp"
    matchers-condition: and
    matchers:
      - type: status
        status: [200]
      - type: word
        words:
          - "login"
          - "password"
          - "username"
          - "admin"
        condition: or

---
# ── Custom Template: Backup files exposed ───────────────────────────────────
id: exposed-backup-files

info:
  name: Backup files exposed
  author: bbe
  severity: high
  tags: exposure,backup

requests:
  - method: GET
    path:
      - "{{BaseURL}}/backup.zip"
      - "{{BaseURL}}/backup.tar.gz"
      - "{{BaseURL}}/backup.sql"
      - "{{BaseURL}}/db.sql"
      - "{{BaseURL}}/database.sql"
      - "{{BaseURL}}/site.zip"
      - "{{BaseURL}}/www.zip"
      - "{{BaseURL}}/htdocs.zip"
    matchers:
      - type: status
        status: [200]

---
# ── Custom Template: Firebase exposed ───────────────────────────────────────
id: firebase-open-db

info:
  name: Firebase database open
  author: bbe
  severity: critical
  tags: exposure,firebase,misconfig

requests:
  - method: GET
    path:
      - "https://{{Hostname}}/.json"
    matchers:
      - type: word
        negative: true
        words:
          - "\"error\""
          - "Permission denied"

---
# ── Custom Template: Debug endpoints ────────────────────────────────────────
id: exposed-debug-endpoints

info:
  name: Debug/trace endpoints exposed
  author: bbe
  severity: medium
  tags: exposure,debug

requests:
  - method: GET
    path:
      - "{{BaseURL}}/debug"
      - "{{BaseURL}}/trace"
      - "{{BaseURL}}/_debug"
      - "{{BaseURL}}/actuator"
      - "{{BaseURL}}/actuator/env"
      - "{{BaseURL}}/actuator/health"
      - "{{BaseURL}}/actuator/mappings"
      - "{{BaseURL}}/__debug__"
      - "{{BaseURL}}/console"
    matchers:
      - type: status
        status: [200]
"""


class NucleiScanner:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []

    def _is_available(self) -> bool:
        return bool(shutil.which("nuclei"))

    def _ensure_custom_templates(self):
        TMPL_DIR.mkdir(parents=True, exist_ok=True)
        custom_path = TMPL_DIR / "bbe-custom.yaml"
        if not custom_path.exists():
            custom_path.write_text(CUSTOM_TEMPLATES)
            log.info(f"[NUCLEI] Custom templates written to {custom_path}")

    async def run(self, alive_hosts: list) -> list:
        if not self._is_available():
            log.warning("[NUCLEI] nuclei not found in PATH — skipping. Install with: go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest")
            return []

        self._ensure_custom_templates()

        urls = [h["url"] for h in alive_hosts[:50]]
        if not urls:
            return []

        log.info(f"[NUCLEI] Scanning {len(urls)} hosts with nuclei templates")

        # Write target list to temp file
        targets_file = BASE_DIR / "data" / f"nuclei_targets_{self.target_id}.txt"
        targets_file.write_text("\n".join(urls))

        output_file = BASE_DIR / "data" / f"nuclei_output_{self.target_id}.json"

        cmd = [
            "nuclei",
            "-list",      str(targets_file),
            "-tags",      DEFAULT_TAGS,
            "-severity",  "critical,high,medium,low",
            "-json",
            "-o",         str(output_file),
            "-silent",
            "-rate-limit", "50",
            "-timeout",   "10",
            "-retries",   "1",
            "-bulk-size", "25",
            "-concurrency", "10",
        ]

        # Also run custom templates
        if TMPL_DIR.exists():
            cmd += ["-t", str(TMPL_DIR)]

        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            )
        except subprocess.TimeoutExpired:
            log.warning("[NUCLEI] Timeout after 10 minutes")
        except Exception as e:
            log.error(f"[NUCLEI] Failed: {e}")
            return []
        finally:
            targets_file.unlink(missing_ok=True)

        # Parse output
        if output_file.exists():
            self.findings = self._parse_output(output_file)
            output_file.unlink(missing_ok=True)

        log.info(f"[NUCLEI] Found {len(self.findings)} findings")
        await self._save_findings()
        return self.findings

    def _parse_output(self, output_file: Path) -> list:
        findings = []
        try:
            with open(output_file) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                        info     = item.get("info", {})
                        severity = SEVERITY_MAP.get(info.get("severity", "low"), "low")
                        findings.append({
                            "vuln_type":   f"nuclei:{item.get('template-id', 'unknown')}",
                            "severity":    severity,
                            "title":       info.get("name", item.get("template-id", "")),
                            "description": info.get("description", ""),
                            "endpoint":    item.get("matched-at", item.get("host", "")),
                            "parameter":   "",
                            "payload":     item.get("request", "")[:300],
                            "evidence":    item.get("response", "")[:500],
                            "cve":         ",".join(info.get("classification", {}).get("cve-id", [])),
                            "source":      "nuclei",
                        })
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            log.error(f"[NUCLEI] Parse error: {e}")
        return findings

    async def _save_findings(self):
        if not self.findings:
            return
        db = await get_db()
        async with db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, self.domain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f["parameter"], f["payload"],
                        f["evidence"], f.get("cve", "")
                    ))
                except Exception as e:
                    log.debug(f"[NUCLEI] DB insert: {e}")
            await db.commit()
