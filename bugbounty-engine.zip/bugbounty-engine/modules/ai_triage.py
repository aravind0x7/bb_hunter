"""
modules/ai_triage.py — AI-powered triage, chaining, dedup, and scoring

Supported providers (set ai.provider in config.yaml):
  sarvam    — FREE, OpenAI-compatible, models: sarvam-m / sarvam-30b / sarvam-105b
  openai    — Paid, models: gpt-4o / gpt-4o-mini
  anthropic — Paid, models: claude-opus-4-20250514
  ollama    — FREE local, models: llama3 / mistral / any ollama model
  groq      — FREE tier, models: llama-3.1-70b-versatile / mixtral-8x7b
"""
import json
import asyncio
import re
import aiohttp
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

# ── Provider configs ──────────────────────────────────────────────────────────
PROVIDERS = {
    "sarvam": {
        "base_url": "https://api.sarvam.ai/v1",
        "default_model": "sarvam-105b",
        "auth_header": "api-subscription-key",   # Sarvam uses this header
    },
    "openai": {
        "base_url": "https://api.openai.com/v1",
        "default_model": "gpt-4o-mini",
        "auth_header": "Authorization",
    },
    "anthropic": {
        "base_url": None,   # uses SDK directly
        "default_model": "claude-opus-4-20250514",
        "auth_header": None,
    },
    "ollama": {
        "base_url": "http://localhost:11434/v1",  # local
        "default_model": "llama3",
        "auth_header": None,
    },
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "default_model": "llama-3.1-70b-versatile",
        "auth_header": "Authorization",
    },
}

TRIAGE_PROMPT = """You are an expert bug bounty hunter and security researcher.
Analyze these security findings from an automated scanner and:

1. FILTER: Mark obvious false positives (is_false_positive: true)
2. CVSS: Estimate CVSS 3.1 score (0.0-10.0) for each real finding
3. CHAINS: Identify exploit chains where 2+ findings combine for higher impact
   (examples: CORS+XSS=session theft, SSRF+IDOR=data exfil, SQLi+admin=full compromise)
4. SUMMARY: Write a 2-sentence hacker-style impact summary per finding
5. PRIORITY: Rank by bounty potential (1=highest value)

Return ONLY valid JSON, no markdown, no explanation:
{
  "findings": [
    {
      "index": 0,
      "is_false_positive": false,
      "cvss": 9.1,
      "priority": 1,
      "impact_summary": "...",
      "chain_with": [],
      "chain_description": "",
      "recommended_title": "...",
      "bounty_estimate": "$500-$2000"
    }
  ],
  "top_chain": {
    "finding_indices": [],
    "chain_title": "",
    "chain_description": "",
    "combined_severity": "critical"
  }
}"""

REPORT_PROMPT = """You are a professional bug bounty report writer.
Write a clear, professional vulnerability report for submission to a bug bounty platform.

Target: {target}
Vulnerability: {vuln}

Format:
## Title
(Clear, specific title)

## Summary
(2-3 sentence executive summary)

## Severity
{severity} — CVSS {cvss}

## Steps to Reproduce
1. (Numbered, precise steps)

## Proof of Concept
```
(Payload / request / curl command)
```

## Impact
(Business impact — what an attacker can achieve)

## Remediation
(Specific fix recommendations)

## References
(CVEs, CWEs, OWASP links if relevant)

Be technical and precise. Use only the evidence provided. Do not fabricate."""


class AITriage:
    def __init__(self):
        ai_cfg        = cfg.get("ai", {})
        self.provider = ai_cfg.get("provider", "sarvam").lower()
        self.api_key  = ai_cfg.get("api_key", "")
        p_cfg         = PROVIDERS.get(self.provider, PROVIDERS["sarvam"])
        self.base_url = ai_cfg.get("base_url", p_cfg["base_url"])
        self.model    = ai_cfg.get("model", p_cfg["default_model"])
        self.auth_hdr = p_cfg["auth_header"]
        log.info(f"[AI] Provider: {self.provider} | Model: {self.model}")

    # ── Core chat call (OpenAI-compatible for all providers except Anthropic) ──
    async def _chat(self, messages: list, max_tokens: int = 4000) -> str:
        if self.provider == "anthropic":
            return await self._chat_anthropic(messages, max_tokens)

        headers = {"Content-Type": "application/json"}
        if self.auth_hdr == "Authorization":
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.auth_hdr == "api-subscription-key":
            headers["api-subscription-key"] = self.api_key

        payload = {
            "model":      self.model,
            "messages":   messages,
            "max_tokens": max_tokens,
            "temperature": 0.2,
        }

        url = f"{self.base_url}/chat/completions"
        timeout = aiohttp.ClientTimeout(total=120)

        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, json=payload, headers=headers) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    raise RuntimeError(f"AI API {resp.status}: {body[:200]}")
                data = await resp.json()
                return data["choices"][0]["message"]["content"]

    async def _chat_anthropic(self, messages: list, max_tokens: int) -> str:
        try:
            import anthropic as anth
            client = anth.Anthropic(api_key=self.api_key)
            loop   = asyncio.get_event_loop()
            resp   = await loop.run_in_executor(
                None,
                lambda: client.messages.create(
                    model=self.model,
                    max_tokens=max_tokens,
                    messages=messages,
                )
            )
            return resp.content[0].text
        except ImportError:
            raise RuntimeError("anthropic package not installed. Run: pip install anthropic")

    def _parse_json(self, raw: str) -> dict:
        """Robustly extract JSON from model response."""
        raw = raw.strip()
        # Strip markdown fences
        raw = re.sub(r"^```(?:json)?\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)
        raw = raw.strip()
        # Find first { ... last }
        start = raw.find("{")
        end   = raw.rfind("}")
        if start != -1 and end != -1:
            raw = raw[start:end+1]
        return json.loads(raw)

    # ── Triage ────────────────────────────────────────────────────────────────
    async def triage_findings(self, findings: list) -> list:
        if not findings or not cfg["ai"].get("triage_enabled", True):
            return findings

        log.info(f"[AI] Triaging {len(findings)} findings via {self.provider}/{self.model}")

        enriched = []
        for i in range(0, len(findings), 20):
            batch         = findings[i:i+20]
            enriched_batch = await self._triage_batch(batch)
            enriched.extend(enriched_batch)

        return enriched

    async def _triage_batch(self, findings: list) -> list:
        findings_json = json.dumps([{
            "index":     i,
            "vuln_type": f["vuln_type"],
            "severity":  f["severity"],
            "title":     f["title"],
            "endpoint":  f["endpoint"],
            "parameter": f.get("parameter", ""),
            "payload":   f.get("payload", "")[:200],
            "evidence":  f.get("evidence", "")[:300],
        } for i, f in enumerate(findings)], indent=2)

        try:
            raw = await self._chat([{
                "role": "user",
                "content": f"{TRIAGE_PROMPT}\n\nFindings:\n{findings_json}"
            }], max_tokens=4000)

            data = self._parse_json(raw)

            for item in data.get("findings", []):
                idx = item.get("index", -1)
                if 0 <= idx < len(findings):
                    findings[idx].update({
                        "is_false_positive": item.get("is_false_positive", False),
                        "cvss":              item.get("cvss", 0),
                        "priority":          item.get("priority", 99),
                        "ai_analysis":       item.get("impact_summary", ""),
                        "chain_with":        item.get("chain_with", []),
                        "chain_description": item.get("chain_description", ""),
                        "bounty_estimate":   item.get("bounty_estimate", "Unknown"),
                        "recommended_title": item.get("recommended_title",
                                                      findings[idx].get("title", "")),
                    })

            top_chain = data.get("top_chain")
            if top_chain and top_chain.get("finding_indices"):
                for idx in top_chain["finding_indices"]:
                    if 0 <= idx < len(findings):
                        findings[idx]["top_chain"] = top_chain

        except json.JSONDecodeError as e:
            log.warning(f"[AI] JSON parse error: {e} — skipping triage for batch")
        except Exception as e:
            log.warning(f"[AI] Triage error ({self.provider}): {e}")

        real_findings = [f for f in findings if not f.get("is_false_positive", False)]
        fp_count = len(findings) - len(real_findings)
        if fp_count:
            log.info(f"[AI] Filtered {fp_count} false positives")

        await self._update_db(real_findings)
        return sorted(real_findings, key=lambda x: x.get("priority", 99))

    async def _update_db(self, findings: list):
        db = await get_db()
        async with db:
            for f in findings:
                try:
                    await db.execute("""
                        UPDATE findings
                        SET cvss=?, ai_analysis=?, chain_ids=?,
                            bounty_estimate=?, recommended_title=?
                        WHERE vuln_type=? AND endpoint=?
                    """, (
                        f.get("cvss"),
                        f.get("ai_analysis"),
                        json.dumps(f.get("chain_with", [])),
                        f.get("bounty_estimate", ""),
                        f.get("recommended_title", f.get("title", "")),
                        f["vuln_type"], f["endpoint"]
                    ))
                except Exception as e:
                    log.debug(f"[AI] DB update: {e}")
            await db.commit()

    # ── Report writer ─────────────────────────────────────────────────────────
    async def generate_report(self, finding: dict, target: str) -> str:
        vuln_str = json.dumps({
            "type":       finding["vuln_type"],
            "title":      finding.get("recommended_title", finding.get("title", "")),
            "endpoint":   finding["endpoint"],
            "parameter":  finding.get("parameter", ""),
            "payload":    finding.get("payload", ""),
            "evidence":   finding.get("evidence", ""),
            "impact":     finding.get("ai_analysis", ""),
            "chain_desc": finding.get("chain_description", ""),
        }, indent=2)

        prompt = REPORT_PROMPT.format(
            target=target,
            vuln=vuln_str,
            severity=finding.get("severity", "").upper(),
            cvss=finding.get("cvss", "N/A")
        )

        try:
            return await self._chat(
                [{"role": "user", "content": prompt}],
                max_tokens=2000
            )
        except Exception as e:
            log.error(f"[AI] Report generation failed: {e}")
            return self._fallback_report(finding, target)

    def _fallback_report(self, f: dict, target: str) -> str:
        return f"""## {f.get('recommended_title', f.get('title', 'Finding'))}

## Summary
{f.get('ai_analysis', f.get('description', ''))}

## Severity
{f.get('severity','').upper()} — CVSS {f.get('cvss', 'N/A')}

## Steps to Reproduce
1. Navigate to: {f['endpoint']}
2. Parameter: {f.get('parameter', 'N/A')}
3. Payload: `{f.get('payload', 'N/A')}`

## Evidence
{f.get('evidence', 'See scan results')}

## Impact
{f.get('chain_description', 'See analysis above')}
"""
