"""
modules/takeover.py — Subdomain takeover detector
Checks DNS CNAME chains for dangling references to cloud services.
A subdomain takeover = CNAME points to a provider where the resource
no longer exists — attacker can register it and serve content.
"""
import asyncio
import dns.resolver
import dns.exception
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

# Fingerprints: (provider, cname_pattern, http_body_indicator, severity)
TAKEOVER_FINGERPRINTS = [
    ("GitHub Pages",     "github.io",           "There isn't a GitHub Pages site here",    "high"),
    ("Heroku",           "herokudns.com",        "No such app",                              "high"),
    ("Heroku",           "herokuapp.com",        "No such app",                              "high"),
    ("Amazon S3",        "s3.amazonaws.com",     "NoSuchBucket",                             "high"),
    ("Amazon S3",        "s3-website",           "NoSuchBucket",                             "high"),
    ("Azure",            "azurewebsites.net",    "404 Web Site not found",                   "high"),
    ("Azure",            "cloudapp.azure.com",   "404 - App Service",                        "high"),
    ("Fastly",           "fastly.net",           "Fastly error: unknown domain",             "high"),
    ("Ghost",            "ghost.io",             "The thing you were looking for is no longer here", "high"),
    ("Shopify",          "myshopify.com",        "Sorry, this shop is currently unavailable","medium"),
    ("Tumblr",           "domains.tumblr.com",   "There's nothing here.",                    "medium"),
    ("Surge",            "surge.sh",             "project not found",                        "high"),
    ("Netlify",          "netlify.app",          "Not Found - Request ID",                   "high"),
    ("Zendesk",          "zendesk.com",          "Help Center Closed",                       "medium"),
    ("Unbounce",         "unbouncepages.com",    "The requested URL was not found",          "medium"),
    ("Cargo",            "cargocollective.com",  "404 Not Found",                            "medium"),
    ("Webflow",          "webflow.io",           "The page you are looking for doesn't exist","medium"),
    ("Strikingly",       "strikinglydns.com",    "But if you're looking to build your own website", "medium"),
    ("Pingdom",          "stats.pingdom.com",    "This public report page has not been activated", "medium"),
    ("WordPress",        "wordpress.com",        "Do you want to register",                  "medium"),
    ("Bitbucket",        "bitbucket.io",         "Repository not found",                     "high"),
    ("Campaign Monitor", "createsend.com",       "Double check the URL",                     "medium"),
    ("HubSpot",          "hs-sites.com",         "Domain not found",                         "medium"),
    ("Readme.io",        "readme.io",            "Project doesnt exist",                     "medium"),
    ("UserVoice",        "uservoice.com",        "This UserVoice subdomain is currently available", "medium"),
    ("Intercom",         "custom.intercom.help", "Uh oh. That page doesn't exist.",          "medium"),
]


class TakeoverChecker:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []
        self.resolver  = dns.resolver.Resolver()
        self.resolver.nameservers = cfg["recon"]["dns_resolvers"]
        self.resolver.timeout     = 5
        self.resolver.lifetime    = 8

    async def run(self, subdomains: list) -> list:
        log.info(f"[TAKEOVER] Checking {len(subdomains)} subdomains for takeover")

        loop  = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(None, self._check_subdomain, sub)
            for sub in subdomains[:200]
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        for r in results:
            if isinstance(r, dict):
                self.findings.append(r)

        log.info(f"[TAKEOVER] Found {len(self.findings)} potential takeovers")
        await self._save_findings()
        return self.findings

    def _check_subdomain(self, subdomain: str) -> dict | None:
        """Resolve CNAME chain and check against fingerprints."""
        try:
            cnames = self._get_cname_chain(subdomain)
        except Exception:
            return None

        if not cnames:
            return None

        for cname in cnames:
            for provider, pattern, body_indicator, severity in TAKEOVER_FINGERPRINTS:
                if pattern.lower() in cname.lower():
                    # Confirm with HTTP check
                    confirmed = self._http_confirm(subdomain, body_indicator)
                    if confirmed:
                        return {
                            "vuln_type":   "subdomain_takeover",
                            "severity":    severity,
                            "title":       f"Subdomain Takeover: {subdomain} → {provider}",
                            "description": (
                                f"CNAME {subdomain} points to {cname} ({provider}), "
                                f"but the resource no longer exists. An attacker can register "
                                f"this resource and serve arbitrary content from your domain."
                            ),
                            "endpoint":    f"https://{subdomain}",
                            "parameter":   "",
                            "payload":     f"CNAME chain: {' → '.join(cnames)}",
                            "evidence":    f"Body indicator: '{body_indicator}' found | Provider: {provider}",
                            "cve":         "",
                            "provider":    provider,
                            "cname_chain": cnames,
                        }
        return None

    def _get_cname_chain(self, host: str, max_depth: int = 10) -> list:
        chain = []
        current = host
        for _ in range(max_depth):
            try:
                answers = self.resolver.resolve(current, "CNAME")
                cname   = str(answers[0].target).rstrip(".")
                chain.append(cname)
                current = cname
            except dns.resolver.NoAnswer:
                break
            except dns.resolver.NXDOMAIN:
                chain.append(f"NXDOMAIN:{current}")
                break
            except Exception:
                break
        return chain

    def _http_confirm(self, subdomain: str, body_indicator: str) -> bool:
        import urllib.request
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode    = ssl.CERT_NONE
        for scheme in ["https", "http"]:
            try:
                req = urllib.request.Request(
                    f"{scheme}://{subdomain}",
                    headers={"User-Agent": "Mozilla/5.0"}
                )
                with urllib.request.urlopen(req, timeout=8, context=ctx) as resp:
                    body = resp.read(4096).decode("utf-8", errors="ignore")
                    if body_indicator.lower() in body.lower():
                        return True
            except Exception:
                continue
        return False

    async def _save_findings(self):
        if not self.findings:
            return
        db = await get_db()
        async with db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, self.domain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f["parameter"], f["payload"],
                        f["evidence"], f.get("cve", "")
                    ))
                except Exception as e:
                    log.debug(f"[TAKEOVER] DB insert: {e}")
            await db.commit()
