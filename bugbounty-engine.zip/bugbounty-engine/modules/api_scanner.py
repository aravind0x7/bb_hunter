"""
modules/api_scanner.py — Deep API Security Scanner
Tests: Auth bypass, rate limiting, mass assignment, versioning issues,
       HTTP verb tampering, parameter pollution, JWT attacks, API key leaks,
       GraphQL depth/batching attacks, Swagger/OpenAPI exposure
"""
import asyncio
import aiohttp
import json
import re
import base64
import string
import random
from urllib.parse import urlparse, urljoin
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

# Common API paths to probe
API_PATHS = [
    "/api", "/api/v1", "/api/v2", "/api/v3",
    "/v1", "/v2", "/v3",
    "/rest", "/rest/api",
    "/graphql", "/gql",
    "/swagger", "/swagger-ui", "/swagger.json", "/swagger.yaml",
    "/openapi.json", "/openapi.yaml",
    "/api-docs", "/api/docs",
    "/redoc",
    "/.well-known/openapi",
    "/api/swagger.json",
    "/api/openapi.json",
]

# HTTP methods for verb tampering
HTTP_VERBS = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD", "TRACE", "CONNECT"]

# Auth bypass headers
AUTH_BYPASS_HEADERS = [
    {"X-Original-URL": "/admin"},
    {"X-Rewrite-URL": "/admin"},
    {"X-Forwarded-For": "127.0.0.1"},
    {"X-Remote-IP": "127.0.0.1"},
    {"X-Client-IP": "127.0.0.1"},
    {"X-Real-IP": "127.0.0.1"},
    {"X-Forwarded-Host": "localhost"},
    {"X-Custom-IP-Authorization": "127.0.0.1"},
    {"X-Originating-IP": "127.0.0.1"},
    {"X-Host": "127.0.0.1"},
]

# Mass assignment test keys
MASS_ASSIGNMENT_KEYS = [
    "isAdmin", "is_admin", "admin", "role", "roles", "permission",
    "permissions", "privilege", "privileges", "level", "access",
    "verified", "is_verified", "active", "is_active", "status",
    "balance", "credits", "points", "subscription", "plan",
    "email_verified", "phone_verified", "two_factor_enabled",
]

# Rate limit test
RATE_LIMIT_THRESHOLD = 20   # requests to send
RATE_LIMIT_WINDOW    = 5    # seconds


class APIScanner:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []
        timeout = aiohttp.ClientTimeout(total=cfg["engine"]["request_timeout"])
        self.session = aiohttp.ClientSession(
            timeout=timeout,
            connector=aiohttp.TCPConnector(ssl=False, limit=30),
            headers={"User-Agent": cfg["engine"]["user_agents"][0]}
        )

    async def close(self):
        await self.session.close()

    def _add(self, vuln_type, severity, title, desc, endpoint,
             param="", payload="", evidence="", cve=""):
        self.findings.append({
            "vuln_type": vuln_type, "severity": severity,
            "title": title, "description": desc,
            "endpoint": endpoint, "parameter": param,
            "payload": payload[:500], "evidence": evidence[:800],
            "cve": cve,
        })
        log.info(f"[API] [{severity.upper()}] {title} @ {endpoint}")

    # ── 1. Discover API spec (Swagger/OpenAPI) ────────────────────────────────
    async def discover_api_spec(self, base_url: str) -> dict:
        parsed = urlparse(base_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"

        for path in API_PATHS:
            url = urljoin(origin, path)
            try:
                async with self.session.get(url) as resp:
                    if resp.status == 200:
                        ct = resp.headers.get("Content-Type", "")
                        body = await resp.text(errors="ignore")

                        # Check for Swagger UI
                        if "swagger" in body.lower() or "openapi" in body.lower():
                            self._add(
                                "swagger_exposed", "medium",
                                "API Documentation Exposed",
                                "Swagger/OpenAPI docs are publicly accessible. Reveals all endpoints, params, auth schemes.",
                                url, evidence=body[:400]
                            )
                            # Try to parse spec for endpoint discovery
                            if "json" in ct or path.endswith(".json"):
                                try:
                                    spec = json.loads(body)
                                    return {"url": url, "spec": spec}
                                except:
                                    pass
                        # GraphQL playground
                        if "graphiql" in body.lower() or "playground" in body.lower():
                            self._add(
                                "graphql_playground", "medium",
                                "GraphQL Playground Exposed",
                                "Interactive GraphQL IDE exposed publicly. Attackers can explore schema interactively.",
                                url
                            )
            except:
                pass

        return {}

    # ── 2. HTTP Verb Tampering ────────────────────────────────────────────────
    async def test_verb_tampering(self, url: str):
        original_status = None
        try:
            async with self.session.get(url) as resp:
                original_status = resp.status
        except:
            return

        if original_status not in (200, 403, 401):
            return

        for verb in ["DELETE", "PUT", "TRACE", "PATCH"]:
            try:
                async with self.session.request(verb, url) as resp:
                    if resp.status == 200 and verb in ("DELETE", "PUT"):
                        self._add(
                            "verb_tampering", "high",
                            f"HTTP Verb Tampering ({verb} allowed)",
                            f"Endpoint accepts {verb} when it likely shouldn't. May allow unauthorized data modification/deletion.",
                            url, payload=f"{verb} {url}",
                            evidence=f"Status {resp.status} on {verb}"
                        )
                    elif resp.status == 200 and verb == "TRACE":
                        self._add(
                            "http_trace_enabled", "low",
                            "HTTP TRACE Method Enabled",
                            "TRACE can facilitate XST (Cross-Site Tracing) to steal cookies.",
                            url, payload=f"TRACE {url}"
                        )
            except:
                pass

    # ── 3. Auth Bypass via Header Injection ───────────────────────────────────
    async def test_auth_bypass_headers(self, url: str):
        # First check if the endpoint is protected
        try:
            async with self.session.get(url) as baseline:
                if baseline.status not in (401, 403):
                    return
                baseline_body = await baseline.text(errors="ignore")
        except:
            return

        for headers in AUTH_BYPASS_HEADERS:
            try:
                async with self.session.get(url, headers=headers) as resp:
                    if resp.status == 200:
                        body = await resp.text(errors="ignore")
                        if body != baseline_body:
                            self._add(
                                "auth_bypass_header", "critical",
                                f"Authentication Bypass via {list(headers.keys())[0]}",
                                f"Adding {headers} header bypasses authentication. Full unauthorized access.",
                                url, payload=str(headers),
                                evidence=f"Protected → {resp.status} with bypass header"
                            )
                            return
            except:
                pass

    # ── 4. Rate Limit Test ────────────────────────────────────────────────────
    async def test_rate_limiting(self, url: str):
        """Send N requests rapidly — if all succeed, rate limiting may be absent."""
        tasks = []
        async def fire():
            try:
                async with self.session.get(url) as r:
                    return r.status
            except:
                return 0

        tasks = [fire() for _ in range(RATE_LIMIT_THRESHOLD)]
        results = await asyncio.gather(*tasks)
        statuses = [s for s in results if s != 0]
        rate_limited = sum(1 for s in statuses if s == 429)

        if rate_limited == 0 and len(statuses) >= RATE_LIMIT_THRESHOLD:
            self._add(
                "no_rate_limit", "medium",
                "No Rate Limiting Detected",
                f"Endpoint accepted {len(statuses)} rapid requests without rate limiting. "
                "Vulnerable to brute-force, enumeration, and DoS.",
                url, evidence=f"Sent {RATE_LIMIT_THRESHOLD} requests, 0 rate-limited (429) responses"
            )

    # ── 5. Mass Assignment ────────────────────────────────────────────────────
    async def test_mass_assignment(self, url: str, method: str = "POST"):
        """Inject privileged fields in POST/PUT bodies."""
        for field in MASS_ASSIGNMENT_KEYS[:10]:
            payload = json.dumps({field: True})
            try:
                async with self.session.request(
                    method, url,
                    data=payload,
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    body = await resp.text(errors="ignore")
                    if resp.status in (200, 201) and field in body:
                        self._add(
                            "mass_assignment", "high",
                            f"Mass Assignment: '{field}' accepted",
                            f"Server accepts and may process privileged field '{field}'. "
                            "Attacker can self-elevate to admin, verify accounts, or modify balance.",
                            url, param=field, payload=payload,
                            evidence=f"Field '{field}' reflected in {resp.status} response"
                        )
                        return
            except:
                pass

    # ── 6. API Versioning — older version still alive ─────────────────────────
    async def test_api_versioning(self, base_url: str):
        parsed = urlparse(base_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"

        version_paths = [
            "/api/v1", "/api/v2", "/api/v3",
            "/v1", "/v2",
            "/api/1.0", "/api/2.0",
        ]

        alive = []
        for path in version_paths:
            url = urljoin(origin, path)
            try:
                async with self.session.get(url) as resp:
                    if resp.status in (200, 401, 403):
                        alive.append((url, resp.status))
            except:
                pass

        if len(alive) > 1:
            self._add(
                "api_versioning", "medium",
                f"Multiple API Versions Active ({len(alive)} found)",
                "Old API versions often lack security patches applied to newer ones. "
                "Test old versions for vulns fixed in newer releases.",
                base_url,
                evidence="\n".join(f"{u} → {s}" for u, s in alive)
            )

    # ── 7. Sensitive endpoints brute-force ────────────────────────────────────
    async def fuzz_api_endpoints(self, base_url: str):
        parsed = urlparse(base_url)
        origin = f"{parsed.scheme}://{parsed.netloc}"

        sensitive = [
            "/api/users", "/api/admin", "/api/config", "/api/settings",
            "/api/debug", "/api/internal", "/api/private", "/api/secret",
            "/api/keys", "/api/tokens", "/api/credentials",
            "/api/users/1", "/api/users/me", "/api/profile",
            "/api/accounts", "/api/billing", "/api/payment",
            "/api/export", "/api/dump", "/api/backup",
            "/api/health", "/api/metrics", "/api/status",
            "/api/logs", "/api/events", "/api/audit",
            "/.env", "/.git/HEAD", "/config.json", "/secrets.json",
            "/wp-json/wp/v2/users",
        ]

        for path in sensitive:
            url = urljoin(origin, path)
            try:
                async with self.session.get(url) as resp:
                    if resp.status == 200:
                        body = await resp.text(errors="ignore")
                        if len(body) > 20:
                            sev = "high" if any(k in path for k in
                                ["admin", "config", "secret", "credential", "key", "token", "backup", "dump"]) else "medium"
                            self._add(
                                "sensitive_endpoint", sev,
                                f"Sensitive API Endpoint Accessible: {path}",
                                f"Endpoint {path} is publicly accessible and returns data.",
                                url, evidence=body[:300]
                            )
                await asyncio.sleep(0.2)
            except:
                pass

    # ── 8. JWT Deep Testing ───────────────────────────────────────────────────
    async def test_jwt_advanced(self, url: str, token: str):
        parts = token.split(".")
        if len(parts) != 3:
            return

        # Test algorithm confusion (RS256 → HS256 with public key as secret)
        try:
            header = json.loads(base64.urlsafe_b64decode(parts[0] + "=="))
            if header.get("alg", "").startswith("RS"):
                # Try switching to HS256 — if server uses public key as HMAC secret
                header["alg"] = "HS256"
                new_header = base64.urlsafe_b64encode(
                    json.dumps(header, separators=(',', ':')).encode()
                ).rstrip(b"=").decode()
                confused_token = f"{new_header}.{parts[1]}."
                async with self.session.get(url, headers={"Authorization": f"Bearer {confused_token}"}) as resp:
                    if resp.status == 200:
                        self._add(
                            "jwt_alg_confusion", "critical",
                            "JWT Algorithm Confusion Attack",
                            "Server accepts RS256 token re-signed as HS256 — full authentication bypass.",
                            url, payload=confused_token[:100]
                        )
        except:
            pass

        # Test expired token still accepted
        try:
            payload_b64 = parts[1]
            payload_bytes = base64.urlsafe_b64decode(payload_b64 + "==")
            payload_json  = json.loads(payload_bytes)
            if "exp" in payload_json:
                old_exp = payload_json["exp"]
                payload_json["exp"] = 1000000  # epoch 1970
                new_payload = base64.urlsafe_b64encode(
                    json.dumps(payload_json, separators=(',', ':')).encode()
                ).rstrip(b"=").decode()
                expired_token = f"{parts[0]}.{new_payload}.{parts[2]}"
                async with self.session.get(url, headers={"Authorization": f"Bearer {expired_token}"}) as resp:
                    if resp.status == 200:
                        self._add(
                            "jwt_expiry_ignored", "high",
                            "JWT Expiry Not Validated",
                            "Server accepts tokens with expired timestamps. Stolen tokens remain valid indefinitely.",
                            url
                        )
        except:
            pass

    # ── 9. BOLA / IDOR at API level ───────────────────────────────────────────
    async def test_bola(self, api_url: str):
        """Broken Object Level Authorization — try sequential IDs."""
        id_patterns = [
            f"{api_url}/1", f"{api_url}/2", f"{api_url}/100",
            f"{api_url}/9999", f"{api_url}/me",
            f"{api_url}?id=1", f"{api_url}?id=2",
            f"{api_url}?user_id=1",
        ]
        responses = []
        for url in id_patterns:
            try:
                async with self.session.get(url) as resp:
                    if resp.status == 200:
                        body = await resp.text(errors="ignore")
                        responses.append((url, len(body)))
            except:
                pass

        if len(responses) >= 2:
            # If multiple IDs return different-size responses — likely BOLA
            sizes = [r[1] for r in responses]
            if len(set(sizes)) > 1 and min(sizes) > 50:
                self._add(
                    "bola", "high",
                    "BOLA / Broken Object Level Authorization",
                    "Multiple object IDs return different data without apparent access control. "
                    "Users may access other users' data by changing IDs.",
                    api_url,
                    evidence="\n".join(f"{u} ({s} bytes)" for u, s in responses[:5])
                )

    # ── Save to DB ─────────────────────────────────────────────────────────────
    async def save_findings(self):
        if not self.findings:
            return
        db = await get_db()
        async with db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, self.domain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f.get("parameter",""), f.get("payload",""),
                        f.get("evidence",""), f.get("cve","")
                    ))
                except Exception as e:
                    log.debug(f"[API] DB insert: {e}")
            await db.commit()

    # ── Master run ─────────────────────────────────────────────────────────────
    async def run(self, alive_hosts: list) -> list:
        try:
            log.info(f"[API] Starting API security scan on {len(alive_hosts)} hosts")
            for host in alive_hosts[:30]:
                url = host["url"]
                await asyncio.gather(
                    self.discover_api_spec(url),
                    self.test_verb_tampering(url),
                    self.test_auth_bypass_headers(url),
                    self.test_rate_limiting(url),
                    self.test_mass_assignment(url),
                    self.test_api_versioning(url),
                    self.fuzz_api_endpoints(url),
                    self.test_bola(url + "/api/users"),
                )
                await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

            await self.save_findings()
            log.info(f"[API] Done — {len(self.findings)} findings")
            return self.findings
        finally:
            await self.close()
