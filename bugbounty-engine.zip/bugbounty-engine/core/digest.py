"""
core/digest.py — Daily/weekly digest builder
Generates rich text digests with ASCII charts for Telegram delivery.
Shows: findings by severity, top targets, new attack surface, bounty pipeline.
"""
import asyncio
from datetime import datetime, timedelta
from core.config import load_config, get_db
from core.logger import log

cfg = load_config()


def _bar(value: int, max_val: int, width: int = 12) -> str:
    """ASCII progress bar."""
    if max_val == 0:
        return "─" * width
    filled = int((value / max_val) * width)
    return "█" * filled + "░" * (width - filled)


def _trend(current: int, previous: int) -> str:
    if previous == 0:
        return "🆕" if current > 0 else "─"
    delta = current - previous
    if delta > 0:
        return f"↑{delta}"
    elif delta < 0:
        return f"↓{abs(delta)}"
    return "─"


class DigestBuilder:
    def __init__(self):
        self.cfg = cfg

    async def build_daily(self) -> str:
        db = await get_db()
        now       = datetime.now()
        today     = now.strftime("%Y-%m-%d")
        yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")

        async with db:
            # Findings today
            today_rows = await (await db.execute("""
                SELECT severity, COUNT(*) FROM findings
                WHERE DATE(found_at) = DATE('now')
                GROUP BY severity ORDER BY
                CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END
            """)).fetchall()

            # Findings yesterday (for trend)
            yesterday_rows = await (await db.execute("""
                SELECT severity, COUNT(*) FROM findings
                WHERE DATE(found_at) = DATE('now', '-1 day')
                GROUP BY severity
            """)).fetchall()

            # All-time totals
            total_rows = await (await db.execute("""
                SELECT severity, COUNT(*) FROM findings GROUP BY severity
            """)).fetchall()

            # Targets
            target_rows = await (await db.execute("""
                SELECT t.domain,
                       COUNT(CASE WHEN DATE(f.found_at)=DATE('now') THEN 1 END) as today_count,
                       COUNT(f.id) as total_count
                FROM targets t
                LEFT JOIN findings f ON t.id = f.target_id
                WHERE t.active = 1
                GROUP BY t.id ORDER BY today_count DESC LIMIT 5
            """)).fetchall()

            # New subdomains today
            new_subs = (await (await db.execute("""
                SELECT COUNT(*) FROM subdomains
                WHERE DATE(first_seen) = DATE('now')
            """)).fetchone())[0]

            # Total unreported
            unreported = (await (await db.execute("""
                SELECT COUNT(*) FROM findings WHERE reported=0
            """)).fetchone())[0]

            # Top findings today
            top_findings = await (await db.execute("""
                SELECT severity, title, endpoint, bounty_estimate
                FROM findings
                WHERE DATE(found_at) = DATE('now')
                ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                WHEN 'medium' THEN 3 ELSE 4 END LIMIT 5
            """)).fetchall()

            # Scan jobs today
            scan_count = (await (await db.execute("""
                SELECT COUNT(*) FROM scan_jobs
                WHERE DATE(started_at) = DATE('now') AND status='done'
            """)).fetchone())[0]

        # ── Build message ──────────────────────────────────────────────────────
        today_map = dict(today_rows)
        yest_map  = dict(yesterday_rows)
        total_map = dict(total_rows)

        SEVERITY_EMO = {
            "critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"
        }

        today_total = sum(today_map.values())
        max_count   = max(today_map.values(), default=1)

        lines = [
            f"📅 *Daily Report — {today}*",
            f"",
            f"🔄 Scans completed: *{scan_count}*  |  🌐 New subdomains: *{new_subs}*",
            f"",
            f"*Findings Today ({today_total} new)*",
            f"```",
        ]

        for sev in ["critical", "high", "medium", "low", "info"]:
            count = today_map.get(sev, 0)
            prev  = yest_map.get(sev, 0)
            if count == 0 and prev == 0:
                continue
            bar   = _bar(count, max_count)
            trend = _trend(count, prev)
            lines.append(f"{sev[:4].upper():<5} {bar} {count:>3}  {trend}")

        lines += [
            "```",
            "",
            f"*All-Time Totals*",
            f"```",
        ]

        all_total = sum(total_map.values())
        max_total = max(total_map.values(), default=1)
        for sev in ["critical", "high", "medium", "low"]:
            count = total_map.get(sev, 0)
            if count == 0:
                continue
            bar = _bar(count, max_total)
            pct = int(count / all_total * 100) if all_total else 0
            lines.append(f"{sev[:4].upper():<5} {bar} {count:>3} ({pct}%)")
        lines += [
            "```",
            "",
        ]

        # Top targets
        if target_rows:
            lines += ["*Top Targets Today*", "```"]
            for domain, today_c, total_c in target_rows:
                if today_c == 0 and total_c == 0:
                    continue
                bar = _bar(today_c, max(r[1] for r in target_rows) or 1)
                lines.append(f"{domain[:22]:<22} +{today_c} ({total_c} total)")
            lines += ["```", ""]

        # Top findings
        if top_findings:
            lines += ["*Top Findings Today*", ""]
            for sev, title, endpoint, bounty in top_findings[:5]:
                emo    = SEVERITY_EMO.get(sev, "⚪")
                short  = title[:45] + "…" if len(title) > 45 else title
                bounty_str = f" 💰{bounty}" if bounty and bounty != "Unknown" else ""
                lines.append(f"{emo} `{short}`{bounty_str}")
                ep_short = endpoint[:50] + "…" if len(endpoint) > 50 else endpoint
                lines.append(f"   └ `{ep_short}`")
                lines.append("")

        # Footer
        lines += [
            f"📬 Unreported findings: *{unreported}*",
            f"",
            f"_Bug Bounty Engine v1.0 — {now.strftime('%H:%M')}_"
        ]

        return "\n".join(lines)

    async def build_weekly(self) -> str:
        db = await get_db()
        async with db:
            week_rows = await (await db.execute("""
                SELECT DATE(found_at) as day, severity, COUNT(*) as cnt
                FROM findings
                WHERE found_at >= DATE('now', '-7 days')
                GROUP BY day, severity
                ORDER BY day
            """)).fetchall()

            top_vulns = await (await db.execute("""
                SELECT vuln_type, COUNT(*) as cnt, MAX(severity) as max_sev
                FROM findings
                WHERE found_at >= DATE('now', '-7 days')
                GROUP BY vuln_type ORDER BY cnt DESC LIMIT 8
            """)).fetchall()

        # Group by day
        from collections import defaultdict
        day_counts = defaultdict(lambda: defaultdict(int))
        for day, sev, cnt in week_rows:
            day_counts[day][sev] = cnt

        lines = [
            "📊 *Weekly Report*",
            f"_{datetime.now().strftime('%Y-%m-%d')}_",
            "",
            "*Findings by Day*",
            "```",
        ]

        days = sorted(day_counts.keys())[-7:]
        max_day = max((sum(day_counts[d].values()) for d in days), default=1)
        for day in days:
            total = sum(day_counts[day].values())
            crit  = day_counts[day].get("critical", 0)
            high  = day_counts[day].get("high", 0)
            bar   = _bar(total, max_day)
            crit_str = f" 🔴{crit}" if crit else ""
            high_str = f" 🟠{high}" if high else ""
            lines.append(f"{day[5:]} {bar} {total:>3}{crit_str}{high_str}")

        lines += ["```", "", "*Top Vulnerability Types*", "```"]
        max_vuln = max((r[1] for r in top_vulns), default=1)
        for vtype, cnt, sev in top_vulns:
            short = vtype.replace("nuclei:", "")[:18]
            bar   = _bar(cnt, max_vuln)
            lines.append(f"{short:<18} {bar} {cnt}")
        lines += ["```"]

        return "\n".join(lines)
