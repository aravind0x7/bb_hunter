"""core/logger.py — Structured logger"""
import logging
import sys
from pathlib import Path
from rich.logging import RichHandler
from rich.console import Console

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

console = Console()

logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[
        RichHandler(console=console, rich_tracebacks=True, markup=True),
        logging.FileHandler(LOG_DIR / "engine.log"),
    ]
)

log = logging.getLogger("bbe")
