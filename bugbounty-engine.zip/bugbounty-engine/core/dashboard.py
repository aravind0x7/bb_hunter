import aiosqlite
"""
core/dashboard.py — Local web dashboard
Serves a real-time dashboard at http://localhost:8080
Shows: targets, findings, scan jobs, stats, live tail of logs
"""
import asyncio
import json
import os
from datetime import datetime
from pathlib import Path
from aiohttp import web
from core.config import load_config, get_db
from core.logger import log

cfg      = load_config()
BASE_DIR = Path(__file__).resolve().parent.parent

DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Bug Bounty Engine — Dashboard</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,sans-serif;background:#0b0d14;color:#e0e0e0;min-height:100vh}
nav{background:#12151f;border-bottom:1px solid #1e2233;padding:.75rem 2rem;display:flex;align-items:center;gap:1.5rem}
nav h1{font-size:1rem;font-weight:600;color:#a78bfa}
nav h1 span{color:#34d399;font-size:.75rem;margin-left:.5rem}
.nav-links a{color:#9ca3af;text-decoration:none;font-size:.85rem;padding:.4rem .8rem;border-radius:6px;transition:all .15s}
.nav-links a:hover,.nav-links a.active{background:#1e2233;color:#fff}
main{padding:2rem;max-width:1400px;margin:0 auto}
.stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem;margin-bottom:2rem}
.stat{background:#12151f;border:1px solid #1e2233;border-radius:10px;padding:1.25rem}
.stat .n{font-size:2rem;font-weight:700;line-height:1}
.stat .l{font-size:.72rem;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;margin-top:.4rem}
.stat.cr .n{color:#ef4444}.stat.hi .n{color:#f97316}.stat.me .n{color:#eab308}
.stat.lo .n{color:#3b82f6}.stat.tg .n{color:#a78bfa}.stat.sb .n{color:#34d399}
section{margin-bottom:2.5rem}
section h2{font-size:.9rem;font-weight:500;color:#9ca3af;text-transform:uppercase;letter-spacing:.08em;margin-bottom:1rem}
table{width:100%;border-collapse:collapse;background:#12151f;border-radius:10px;overflow:hidden}
th{text-align:left;font-size:.75rem;font-weight:500;color:#6b7280;padding:.75rem 1rem;border-bottom:1px solid #1e2233;text-transform:uppercase;letter-spacing:.06em}
td{padding:.7rem 1rem;font-size:.83rem;border-bottom:1px solid #131624;vertical-align:top}
tr:last-child td{border-bottom:none}
tr:hover td{background:#141726}
.badge{display:inline-block;font-size:.68rem;font-weight:600;padding:2px 7px;border-radius:4px;text-transform:uppercase}
.badge.critical{background:#7f1d1d;color:#fca5a5}.badge.high{background:#7c2d12;color:#fdba74}
.badge.medium{background:#713f12;color:#fde68a}.badge.low{background:#1e3a5f;color:#93c5fd}
.badge.info{background:#1f2937;color:#9ca3af}.badge.alive{background:#064e3b;color:#6ee7b7}
.badge.dead{background:#1f2937;color:#9ca3af}.badge.done{background:#064e3b;color:#6ee7b7}
.badge.running{background:#1e3a5f;color:#93c5fd;animation:pulse 1.5s infinite}
.badge.failed{background:#7f1d1d;color:#fca5a5}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
.endpoint{font-family:monospace;font-size:.75rem;color:#a78bfa;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.chain-badge{background:#312e81;color:#c4b5fd;font-size:.68rem;padding:2px 6px;border-radius:4px;margin-left:.4rem}
.bounty{color:#34d399;font-size:.8rem}
#log-tail{background:#0b0d14;border:1px solid #1e2233;border-radius:8px;padding:1rem;font-family:monospace;font-size:.72rem;height:200px;overflow-y:auto;color:#6ee7b7}
.refresh-btn{background:#1e2233;border:1px solid #374151;color:#e0e0e0;padding:.4rem .9rem;border-radius:6px;cursor:pointer;font-size:.8rem}
.refresh-btn:hover{background:#374151}
.empty{color:#4b5563;font-size:.85rem;padding:2rem;text-align:center}
</style>
</head>
<body>
<nav>
  <h1>🐛 Bug Bounty Engine <span id="status-badge">● ONLINE</span></h1>
  <div class="nav-links">
    <a href="#" class="active" onclick="showSection('overview')">Overview</a>
    <a href="#" onclick="showSection('findings')">Findings</a>
    <a href="#" onclick="showSection('targets')">Targets</a>
    <a href="#" onclick="showSection('logs')">Logs</a>
  </div>
  <button class="refresh-btn" onclick="loadAll()">↻ Refresh</button>
</nav>
<main>
  <div id="section-overview">
    <div class="stats" id="stats-grid"></div>
    <section>
      <h2>Recent Findings</h2>
      <div id="recent-findings"></div>
    </section>
    <section>
      <h2>Scan Jobs</h2>
      <div id="scan-jobs"></div>
    </section>
  </div>
  <div id="section-findings" style="display:none">
    <section>
      <h2>All Findings</h2>
      <div id="all-findings"></div>
    </section>
  </div>
  <div id="section-targets" style="display:none">
    <section>
      <h2>Targets</h2>
      <div id="targets-table"></div>
    </section>
  </div>
  <div id="section-logs" style="display:none">
    <section>
      <h2>Log Tail</h2>
      <div id="log-tail"></div>
    </section>
  </div>
</main>
<script>
function showSection(name){
  ['overview','findings','targets','logs'].forEach(s=>{
    document.getElementById('section-'+s).style.display = s===name?'':'none';
  });
  document.querySelectorAll('.nav-links a').forEach((a,i)=>{
    a.classList.toggle('active', ['overview','findings','targets','logs'][i]===name);
  });
  if(name==='logs') loadLogs();
}

async function loadAll(){
  const [stats,findings,targets,jobs] = await Promise.all([
    fetch('/api/stats').then(r=>r.json()),
    fetch('/api/findings?limit=20').then(r=>r.json()),
    fetch('/api/targets').then(r=>r.json()),
    fetch('/api/jobs').then(r=>r.json()),
  ]);
  renderStats(stats);
  renderFindings(findings, 'recent-findings');
  renderFindings(findings, 'all-findings');
  renderTargets(targets);
  renderJobs(jobs);
}

function renderStats(s){
  document.getElementById('stats-grid').innerHTML = `
    <div class="stat cr"><div class="n">${s.critical||0}</div><div class="l">Critical</div></div>
    <div class="stat hi"><div class="n">${s.high||0}</div><div class="l">High</div></div>
    <div class="stat me"><div class="n">${s.medium||0}</div><div class="l">Medium</div></div>
    <div class="stat lo"><div class="n">${s.low||0}</div><div class="l">Low</div></div>
    <div class="stat tg"><div class="n">${s.targets||0}</div><div class="l">Targets</div></div>
    <div class="stat sb"><div class="n">${s.subdomains||0}</div><div class="l">Subdomains</div></div>
  `;
}

function renderFindings(items, id){
  if(!items.length){document.getElementById(id).innerHTML='<div class="empty">No findings yet</div>';return;}
  const rows = items.map(f=>`
    <tr>
      <td><span class="badge ${f.severity}">${f.severity}</span></td>
      <td>${f.vuln_type}</td>
      <td>${(f.recommended_title||f.title||'').slice(0,60)}${f.chain_ids?'<span class="chain-badge">⛓ chain</span>':''}</td>
      <td class="endpoint">${f.endpoint||''}</td>
      <td>${f.cvss||''}</td>
      <td class="bounty">${f.bounty_estimate||''}</td>
      <td style="color:#6b7280;font-size:.75rem">${(f.found_at||'').slice(0,16)}</td>
    </tr>`).join('');
  document.getElementById(id).innerHTML=`
    <table>
      <thead><tr><th>Sev</th><th>Type</th><th>Title</th><th>Endpoint</th><th>CVSS</th><th>Bounty</th><th>Found</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function renderTargets(items){
  if(!items.length){document.getElementById('targets-table').innerHTML='<div class="empty">No targets added yet</div>';return;}
  const rows = items.map(t=>`
    <tr>
      <td><code style="color:#a78bfa">${t.domain}</code></td>
      <td>${t.program||'—'}</td>
      <td><span class="badge ${t.active?'alive':'dead'}">${t.active?'active':'paused'}</span></td>
      <td style="color:#6b7280;font-size:.75rem">${(t.last_scan||'never').slice(0,16)}</td>
      <td>${t.findings||0}</td>
    </tr>`).join('');
  document.getElementById('targets-table').innerHTML=`
    <table>
      <thead><tr><th>Domain</th><th>Program</th><th>Status</th><th>Last Scan</th><th>Findings</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

function renderJobs(items){
  if(!items.length){document.getElementById('scan-jobs').innerHTML='<div class="empty">No scan jobs yet</div>';return;}
  const rows = items.map(j=>`
    <tr>
      <td style="color:#a78bfa">${j.domain||''}</td>
      <td>${j.phase||''}</td>
      <td><span class="badge ${j.status}">${j.status}</span></td>
      <td style="color:#6b7280;font-size:.75rem">${(j.started_at||'').slice(0,16)}</td>
      <td style="color:#6b7280;font-size:.75rem">${(j.finished_at||'').slice(0,16)}</td>
    </tr>`).join('');
  document.getElementById('scan-jobs').innerHTML=`
    <table>
      <thead><tr><th>Target</th><th>Phase</th><th>Status</th><th>Started</th><th>Finished</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

async function loadLogs(){
  try{
    const r = await fetch('/api/logs');
    const t = await r.text();
    const el = document.getElementById('log-tail');
    el.innerHTML = t.split('\n').map(l=>`<div>${l}</div>`).join('');
    el.scrollTop = el.scrollHeight;
  }catch(e){}
}

loadAll();
setInterval(loadAll, 15000);
</script>
</body>
</html>
"""


class Dashboard:
    def __init__(self, host: str = "127.0.0.1", port: int = 8080):
        self.host = host
        self.port = port
        self.app  = web.Application()
        self._setup_routes()

    def _setup_routes(self):
        self.app.router.add_get("/",           self._index)
        self.app.router.add_get("/api/stats",   self._api_stats)
        self.app.router.add_get("/api/findings",self._api_findings)
        self.app.router.add_get("/api/targets", self._api_targets)
        self.app.router.add_get("/api/jobs",    self._api_jobs)
        self.app.router.add_get("/api/logs",    self._api_logs)

        # Static reports
        report_dir = BASE_DIR / cfg["reporting"]["output_dir"]
        report_dir.mkdir(parents=True, exist_ok=True)
        self.app.router.add_static("/reports", report_dir)

    async def _index(self, request):
        return web.Response(text=DASHBOARD_HTML, content_type="text/html")

    async def _api_stats(self, request):
        async with aiosqlite.connect(DB_PATH) as db:
            by_sev = dict(await (await db.execute(
                "SELECT severity, COUNT(*) FROM findings GROUP BY severity"
            )).fetchall())
            targets   = (await (await db.execute("SELECT COUNT(*) FROM targets WHERE active=1")).fetchone())[0]
            subdomains = (await (await db.execute("SELECT COUNT(*) FROM subdomains")).fetchone())[0]

        return web.json_response({
            "critical":   by_sev.get("critical", 0),
            "high":       by_sev.get("high", 0),
            "medium":     by_sev.get("medium", 0),
            "low":        by_sev.get("low", 0),
            "targets":    targets,
            "subdomains": subdomains,
        })

    async def _api_findings(self, request):
        limit = int(request.query.get("limit", 50))
        sev   = request.query.get("severity")
        async with aiosqlite.connect(DB_PATH) as db:
            if sev:
                cursor = await db.execute(
                    "SELECT * FROM findings WHERE severity=? ORDER BY found_at DESC LIMIT ?",
                    (sev, limit)
                )
            else:
                cursor = await db.execute(
                    """SELECT * FROM findings
                       ORDER BY CASE severity
                         WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                         WHEN 'medium' THEN 3 ELSE 4 END,
                       found_at DESC LIMIT ?""",
                    (limit,)
                )
            cols = [d[0] for d in cursor.description]
            rows = [dict(zip(cols, r)) for r in await cursor.fetchall()]
        return web.json_response(rows)

    async def _api_targets(self, request):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("""
                SELECT t.*, COUNT(f.id) as findings
                FROM targets t LEFT JOIN findings f ON t.id=f.target_id
                GROUP BY t.id ORDER BY t.added_at DESC
            """)
            cols = [d[0] for d in cursor.description]
            rows = [dict(zip(cols, r)) for r in await cursor.fetchall()]
        return web.json_response(rows)

    async def _api_jobs(self, request):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("""
                SELECT j.*, t.domain FROM scan_jobs j
                JOIN targets t ON j.target_id=t.id
                ORDER BY j.started_at DESC LIMIT 30
            """)
            cols = [d[0] for d in cursor.description]
            rows = [dict(zip(cols, r)) for r in await cursor.fetchall()]
        return web.json_response(rows)

    async def _api_logs(self, request):
        log_file = BASE_DIR / "logs" / "engine.log"
        if log_file.exists():
            with open(log_file) as f:
                lines = f.readlines()
            return web.Response(text="".join(lines[-200:]), content_type="text/plain")
        return web.Response(text="No logs yet", content_type="text/plain")

    async def start(self):
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, self.host, self.port)
        await site.start()
        log.info(f"[DASHBOARD] Running at http://{self.host}:{self.port}")

    async def run(self):
        """Start and block until cancelled."""
        await self.start()
        try:
            await asyncio.Event().wait()
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass
