"""
core/engine.py — Master scan orchestrator
Ties together: Recon → Takeover → Nuclei → Scanner → CVE → AI Triage → Reporter → Alerts
"""
import asyncio
import json
from datetime import datetime
import aiosqlite
from core.config import load_config, DB_PATH
from core.logger import log
from modules.recon       import ReconEngine
from modules.scanner     import VulnScanner
from modules.ai_triage   import AITriage
from modules.reporter    import Reporter
from modules.nuclei_scan import NucleiScanner
from modules.api_scanner import APIScanner
from modules.cve_checker import CVEChecker
from modules.takeover    import TakeoverChecker
from modules.scope       import ScopeValidator
from modules.fuzz        import DeepFuzzer

cfg = load_config()


class ScanEngine:
    def __init__(self):
        self.running  = {}     # domain -> asyncio.Task
        self._lock    = {}     # domain -> bool, prevents concurrent same-domain scans

    async def get_or_create_target(self, domain: str) -> int:
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("SELECT id FROM targets WHERE domain=?", (domain,))
            row = await cursor.fetchone()
            if row:
                return row[0]
            cursor = await db.execute(
                "INSERT INTO targets (domain) VALUES (?) RETURNING id", (domain,)
            )
            row = await cursor.fetchone()
            await db.commit()
            return row[0]

    async def scan_target(self, domain: str) -> dict:
        if self._lock.get(domain):
            log.warning(f"[ENGINE] Scan already running for {domain} — skipping")
            return {"findings": [], "skipped": True}
        self._lock[domain] = True
        log.info(f"[ENGINE] ══════════════════════════════")
        log.info(f"[ENGINE] Starting full scan: {domain}")
        log.info(f"[ENGINE] ══════════════════════════════")
        target_id = await self.get_or_create_target(domain)

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute("""
                INSERT INTO scan_jobs (target_id, phase, status, started_at)
                VALUES (?, 'full', 'running', CURRENT_TIMESTAMP)
            """, (target_id,))
            job_cursor = await db.execute("SELECT last_insert_rowid()")
            job_id = (await job_cursor.fetchone())[0]
            await db.commit()

        results    = {}
        start_time = datetime.now()

        try:
            # ── Phase 1: Recon ────────────────────────────────────────────────
            log.info(f"[ENGINE] ▶ Phase 1/6: Recon")
            scope = ScopeValidator(target_id, domain)
            await scope.load()

            recon      = ReconEngine(target_id, domain)
            recon_data = await recon.run()
            results["recon"] = recon_data

            # Filter hosts by scope — use urls from alive_hosts dicts
            raw_alive = recon_data.get("alive_hosts", [])
            alive_hosts = [h for h in raw_alive
                           if scope.filter_urls([h.get("url", "")]) or not scope._loaded]
            endpoints   = recon_data.get("endpoints", [])
            secrets     = recon_data.get("secrets", [])
            techs       = recon_data.get("technologies", [])

            log.info(
                f"[ENGINE] Recon: {len(recon_data['subdomains'])} subs | "
                f"{len(alive_hosts)} alive | {len(endpoints)} endpoints | "
                f"{len(secrets)} secrets"
            )

            # ── Phase 2: Subdomain Takeover ───────────────────────────────────
            log.info(f"[ENGINE] ▶ Phase 2/6: Takeover check")
            takeover        = TakeoverChecker(target_id, domain)
            takeover_findings = await takeover.run(recon_data.get("subdomains", []))
            log.info(f"[ENGINE] Takeover: {len(takeover_findings)} candidates")

            # ── Phase 3: CVE matching ─────────────────────────────────────────
            log.info(f"[ENGINE] ▶ Phase 3/6: CVE check")
            cve_checker   = CVEChecker(target_id, domain)
            cve_findings  = await cve_checker.run(alive_hosts)
            log.info(f"[ENGINE] CVE: {len(cve_findings)} potential matches")

            # ── Phase 4: Vuln Scan + Nuclei + API Scanner + Fuzzer (parallel) ─
            log.info(f"[ENGINE] ▶ Phase 4/6: Vuln scan + Nuclei + API scan + Fuzz (parallel)")
            scanner = VulnScanner(target_id, domain)
            nuclei  = NucleiScanner(target_id, domain)
            api     = APIScanner(target_id, domain)
            fuzzer  = DeepFuzzer(target_id, domain)

            vuln_findings, nuclei_findings, api_findings, fuzz_findings = await asyncio.gather(
                scanner.run(alive_hosts, endpoints),
                nuclei.run(alive_hosts),
                api.run(alive_hosts),
                fuzzer.run(alive_hosts, endpoints),
                return_exceptions=True,
            )

            # Flatten and handle exceptions
            def _safe(result, name):
                if isinstance(result, Exception):
                    log.warning(f"[ENGINE] {name} failed: {result}")
                    return []
                return result or []

            vuln_findings   = _safe(vuln_findings,   "VulnScanner")
            nuclei_findings = _safe(nuclei_findings, "Nuclei")
            api_findings    = _safe(api_findings,    "APIScanner")
            fuzz_findings   = _safe(fuzz_findings,   "Fuzzer")

            # Merge all raw findings
            raw_findings = (vuln_findings + nuclei_findings + api_findings +
                            fuzz_findings + cve_findings + takeover_findings)

            # Add secrets as findings
            for s in secrets:
                raw_findings.append({
                    "vuln_type":   "exposed_secret",
                    "severity":    s.get("severity", "critical"),
                    "title":       f"Exposed Secret: {s['type']}",
                    "description": f"Secret found in JS/source: {s.get('source', '')}",
                    "endpoint":    s.get("source", domain),
                    "evidence":    s.get("value", "")[:200],
                    "parameter":   "",
                    "payload":     "",
                    "cve":         "",
                })

            log.info(
                f"[ENGINE] Raw findings: {len(raw_findings)} total "
                f"({len(vuln_findings)} vuln, {len(nuclei_findings)} nuclei, "
                f"{len(api_findings)} api, {len(fuzz_findings)} fuzz, "
                f"{len(secrets)} secrets, {len(cve_findings)} cve, "
                f"{len(takeover_findings)} takeover)"
            )
            results["raw_findings"] = raw_findings

            # ── Phase 5: AI Triage ────────────────────────────────────────────
            log.info(f"[ENGINE] ▶ Phase 5/6: AI triage ({len(raw_findings)} findings)")
            triage   = AITriage()
            findings = await triage.triage_findings(raw_findings)
            results["findings"] = findings

            critical = [f for f in findings if f.get("severity") == "critical"]
            high     = [f for f in findings if f.get("severity") == "high"]
            log.info(
                f"[ENGINE] Triage done: {len(findings)} real "
                f"({len(critical)} critical, {len(high)} high)"
            )

            # ── Phase 6: Reports ──────────────────────────────────────────────
            log.info(f"[ENGINE] ▶ Phase 6/6: Generating reports")
            reporter     = Reporter(domain, target_id)
            report_paths = await reporter.generate_all_reports(findings)
            results["report_paths"] = report_paths

            # ── Finalise ──────────────────────────────────────────────────────
            elapsed = (datetime.now() - start_time).seconds
            log.info(f"[ENGINE] ✓ Scan complete in {elapsed}s — {domain}")

            async with db:
                await db.execute(
                    "UPDATE targets SET last_scan=CURRENT_TIMESTAMP WHERE id=?",
                    (target_id,)
                )
                await db.execute("""
                    UPDATE scan_jobs
                    SET status='done', finished_at=CURRENT_TIMESTAMP, result_json=?
                    WHERE id=?
                """, (json.dumps({
                    "findings":      len(findings),
                    "critical":      len(critical),
                    "high":          len(high),
                    "elapsed_secs":  elapsed,
                    "report":        report_paths,
                }), job_id))
                await db.commit()

            results["elapsed"] = elapsed
            return results

        except Exception as e:
            log.error(f"[ENGINE] Scan failed for {domain}: {e}")
            import traceback; traceback.print_exc()
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute(
                    "UPDATE scan_jobs SET status='failed', finished_at=CURRENT_TIMESTAMP WHERE id=?",
                    (job_id,)
                )
                await db.commit()
            raise
        finally:
            self._lock.pop(domain, None)


class Scheduler:
    """Background scheduler: auto-rescans + daily digest + new-subdomain alerts."""

    def __init__(self, engine: ScanEngine, bot=None):
        self.engine        = engine
        self.bot           = bot
        self.interval      = cfg["scheduler"]["rescan_interval_hours"] * 3600
        self._last_digest  = None   # date string of last digest
        self._known_subs   = {}     # domain -> set of known subdomains

    async def run(self):
        log.info(f"[SCHEDULER] Started — rescan every {cfg['scheduler']['rescan_interval_hours']}h")
        # Seed known subdomains from DB on startup
        await self._seed_known_subdomains()
        while True:
            await asyncio.sleep(60)
            await self._check_and_scan()
            await self._maybe_send_digest()

    async def _seed_known_subdomains(self):
        async with aiosqlite.connect(DB_PATH) as db:
            rows = await (await db.execute(
                "SELECT t.domain, s.subdomain FROM subdomains s JOIN targets t ON s.target_id=t.id"
            )).fetchall()
        for domain, sub in rows:
            self._known_subs.setdefault(domain, set()).add(sub)

    async def _check_and_scan(self):
        async with aiosqlite.connect(DB_PATH) as db:
            cursor = await db.execute("""
                SELECT id, domain FROM targets
                WHERE active=1
                AND (last_scan IS NULL
                     OR (CAST(strftime('%s','now') AS INTEGER) -
                         CAST(strftime('%s', last_scan) AS INTEGER)) > ?)
            """, (self.interval,))
            due = await cursor.fetchall()

        for target_id, domain in due:
            log.info(f"[SCHEDULER] Auto-scan triggered: {domain}")
            try:
                # Capture known subs before scan
                prev_subs = set(self._known_subs.get(domain, set()))

                results  = await self.engine.scan_target(domain)
                findings = results.get("findings", [])

                # Alert on critical/high findings
                if self.bot:
                    alerted = 0
                    for f in findings:
                        if f.get("severity") in ("critical", "high") and alerted < 5:
                            await self.bot.send_finding_alert(f, domain)
                            alerted += 1
                            await asyncio.sleep(1)  # avoid flood

                # Alert on new subdomains
                if self.bot and cfg["scheduler"].get("new_subdomain_alert"):
                    recon    = results.get("recon", {})
                    new_subs = set(recon.get("subdomains", [])) - prev_subs
                    if new_subs:
                        self._known_subs[domain] = set(recon.get("subdomains", []))
                        await self.bot.send_new_subdomains_alert(domain, list(new_subs)[:20])

            except Exception as e:
                log.error(f"[SCHEDULER] Auto-scan failed for {domain}: {e}")

    async def _maybe_send_digest(self):
        if not self.bot:
            return
        if not cfg["telegram"].get("daily_summary"):
            return

        from datetime import datetime
        now      = datetime.now()
        today    = now.strftime("%Y-%m-%d")
        cfg_time = cfg["telegram"].get("summary_time", "08:00")
        h, m     = map(int, cfg_time.split(":"))

        if now.hour == h and now.minute == m and self._last_digest != today:
            self._last_digest = today
            try:
                from core.digest import DigestBuilder
                builder = DigestBuilder()
                text    = await builder.build_daily()
                await self.bot.app.bot.send_message(
                    cfg["telegram"]["chat_id"],
                    text,
                    parse_mode="Markdown"
                )
                log.info("[SCHEDULER] Daily digest sent")
            except Exception as e:
                log.error(f"[SCHEDULER] Digest failed: {e}")
