"""
core/config.py — Config loader + DB manager
"""
import os
import yaml
import aiosqlite
import asyncio
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent

def load_config(path: str = None) -> dict:
    config_path = path or os.getenv("BBE_CONFIG", BASE_DIR / "config" / "config.yaml")
    local_path  = BASE_DIR / "config" / "config.local.yaml"

    with open(config_path) as f:
        cfg = yaml.safe_load(f)

    # Merge local overrides if present
    if local_path.exists():
        with open(local_path) as f:
            local = yaml.safe_load(f) or {}
        cfg = _deep_merge(cfg, local)

    # Allow env-var overrides
    cfg["telegram"]["bot_token"] = os.getenv("TELEGRAM_BOT_TOKEN", cfg["telegram"]["bot_token"])
    cfg["telegram"]["chat_id"]   = os.getenv("TELEGRAM_CHAT_ID",   cfg["telegram"]["chat_id"])
    cfg["ai"]["api_key"]         = os.getenv("ANTHROPIC_API_KEY",  cfg["ai"]["api_key"])

    return cfg

def _deep_merge(base: dict, override: dict) -> dict:
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


DB_PATH = BASE_DIR / "data" / "engine.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS targets (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    domain      TEXT    UNIQUE NOT NULL,
    program     TEXT,
    platform    TEXT,
    scope       TEXT,           -- JSON list of in-scope patterns
    added_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_scan   TIMESTAMP,
    active      INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS subdomains (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id   INTEGER REFERENCES targets(id),
    subdomain   TEXT NOT NULL,
    ip          TEXT,
    ports       TEXT,           -- JSON list
    tech        TEXT,           -- JSON list
    status      TEXT,           -- alive | dead
    first_seen  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_seen   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(target_id, subdomain)
);

CREATE TABLE IF NOT EXISTS findings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id    INTEGER REFERENCES targets(id),
    subdomain    TEXT,
    vuln_type    TEXT NOT NULL,
    severity     TEXT NOT NULL,  -- critical | high | medium | low | info
    title        TEXT,
    description  TEXT,
    endpoint     TEXT,
    parameter    TEXT,
    payload      TEXT,
    evidence     TEXT,
    cvss         REAL,
    cve          TEXT,
    chain_ids    TEXT,           -- JSON list of related finding IDs
    ai_analysis  TEXT,
    bounty_estimate TEXT,
    recommended_title TEXT,
    reported     INTEGER DEFAULT 0,
    report_path  TEXT,
    found_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(target_id, vuln_type, endpoint, parameter)
);

CREATE TABLE IF NOT EXISTS scan_jobs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id   INTEGER REFERENCES targets(id),
    phase       TEXT,
    status      TEXT DEFAULT 'pending',  -- pending | running | done | failed
    started_at  TIMESTAMP,
    finished_at TIMESTAMP,
    result_json TEXT
);
"""

async def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.commit()

async def get_db():
    return await aiosqlite.connect(DB_PATH)
