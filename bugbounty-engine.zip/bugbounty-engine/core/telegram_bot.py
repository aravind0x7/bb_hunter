"""
core/telegram_bot.py — Telegram Bot Interface
Commands:
  /start      — Show menu
  /add <domain> — Add target
  /targets    — List targets
  /scan <domain> — Trigger manual scan
  /findings [domain] — Show recent findings
  /status     — Engine status
  /report <domain> — Get latest report
  /stop <domain> — Pause target
"""
import asyncio
import json
import os
from datetime import datetime
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)
from telegram.constants import ParseMode
from core.config import load_config, get_db
from core.logger import log
from core.engine import ScanEngine

cfg = load_config()
BOT_TOKEN = cfg["telegram"]["bot_token"]
CHAT_ID   = str(cfg["telegram"]["chat_id"])

SEVERITY_EMOJI = {
    "critical": "🔴",
    "high":     "🟠",
    "medium":   "🟡",
    "low":      "🔵",
    "info":     "⚪",
}

def owner_only(func):
    """Decorator: only allow messages from the configured chat_id."""
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if str(update.effective_chat.id) != CHAT_ID:
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await func(update, ctx)
    return wrapper


class BugBountyBot:
    def __init__(self):
        self.app    = Application.builder().token(BOT_TOKEN).build()
        self.engine = ScanEngine()
        self._register_handlers()

    def _register_handlers(self):
        cmds = [
            ("start",    self.cmd_start),
            ("help",     self.cmd_help),
            ("add",      self.cmd_add),
            ("targets",  self.cmd_targets),
            ("scan",     self.cmd_scan),
            ("findings", self.cmd_findings),
            ("status",   self.cmd_status),
            ("report",   self.cmd_report),
            ("stop",     self.cmd_stop),
            ("stats",    self.cmd_stats),
            ("digest",   self.cmd_digest),
            ("weekly",   self.cmd_weekly),
        ]
        for name, handler in cmds:
            self.app.add_handler(CommandHandler(name, handler))
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))

    # ── /start ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "🐛 *Bug Bounty Engine* — Online\n\n"
            "Your automated money-making machine is ready.\n\n"
            "Quick commands:\n"
            "`/add example.com` — Add a target\n"
            "`/scan example.com` — Run full scan\n"
            "`/findings` — Latest findings\n"
            "`/targets` — All targets\n"
            "`/status` — Engine status\n"
            "`/stats` — Earnings dashboard\n"
        )
        keyboard = [
            [InlineKeyboardButton("📋 Targets", callback_data="targets"),
             InlineKeyboardButton("🔍 Findings", callback_data="findings_all")],
            [InlineKeyboardButton("📊 Stats", callback_data="stats"),
             InlineKeyboardButton("⚙️ Status", callback_data="status")],
        ]
        await update.message.reply_text(
            text, parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    @owner_only
    async def cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "🛠 *Commands*\n\n"
            "/add `<domain>` `[program]` — Add target\n"
            "/scan `<domain>` — Trigger full scan now\n"
            "/targets — List all targets\n"
            "/findings `[domain]` — Recent findings\n"
            "/report `<domain>` — Get HTML report link\n"
            "/status — Running scans\n"
            "/stats — Summary dashboard\n"
            "/stop `<domain>` — Pause a target\n"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    # ── /add <domain> [program] ────────────────────────────────────────────────
    @owner_only
    async def cmd_add(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args
        if not args:
            await update.message.reply_text("Usage: `/add example.com [HackerOne:ProgramName]`", parse_mode=ParseMode.MARKDOWN)
            return
        domain  = args[0].lower().strip()
        program = args[1] if len(args) > 1 else ""

        db = await get_db()
        async with db:
            try:
                await db.execute(
                    "INSERT OR IGNORE INTO targets (domain, program) VALUES (?,?)",
                    (domain, program)
                )
                await db.commit()
                await update.message.reply_text(
                    f"✅ Added target: `{domain}`\n"
                    f"Program: {program or 'N/A'}\n\n"
                    f"Run `/scan {domain}` to start immediately, or it will auto-scan on schedule.",
                    parse_mode=ParseMode.MARKDOWN
                )
            except Exception as e:
                await update.message.reply_text(f"❌ Error: {e}")

    # ── /targets ───────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_targets(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        db = await get_db()
        async with db:
            cursor = await db.execute(
                "SELECT domain, program, last_scan, active FROM targets ORDER BY added_at DESC"
            )
            rows = await cursor.fetchall()

        if not rows:
            await update.message.reply_text("No targets yet. Use `/add <domain>` to add one.", parse_mode=ParseMode.MARKDOWN)
            return

        lines = ["🎯 *Active Targets*\n"]
        for domain, program, last_scan, active in rows:
            status = "🟢" if active else "🔴"
            scan_str = last_scan[:16] if last_scan else "never"
            lines.append(f"{status} `{domain}` — {program or 'no program'} — last: {scan_str}")

        keyboard = [[InlineKeyboardButton(f"🔍 Scan {r[0]}", callback_data=f"scan:{r[0]}")]
                    for r in rows[:5]]
        await update.message.reply_text(
            "\n".join(lines), parse_mode=ParseMode.MARKDOWN,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    # ── /scan <domain> ─────────────────────────────────────────────────────────
    @owner_only
    async def cmd_scan(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args
        if not args:
            await update.message.reply_text("Usage: `/scan example.com`", parse_mode=ParseMode.MARKDOWN)
            return
        domain = args[0].lower().strip()

        await update.message.reply_text(
            f"🚀 Starting full scan on `{domain}`...\n\n"
            "Phases: Recon → Vuln Scan → AI Triage → Report\n"
            "I'll alert you when findings are ready.",
            parse_mode=ParseMode.MARKDOWN
        )

        # Run scan in background
        asyncio.create_task(self._run_scan_and_notify(domain, update.effective_chat.id))

    async def _run_scan_and_notify(self, domain: str, chat_id: int):
        try:
            results = await self.engine.scan_target(domain)
            findings = results.get("findings", [])
            critical = [f for f in findings if f.get("severity") == "critical"]
            high     = [f for f in findings if f.get("severity") == "high"]

            msg = (
                f"✅ *Scan Complete: {domain}*\n\n"
                f"🔴 Critical: {len(critical)}\n"
                f"🟠 High: {len(high)}\n"
                f"📊 Total findings: {len(findings)}\n\n"
            )
            if critical:
                msg += "*Top Critical Findings:*\n"
                for f in critical[:3]:
                    msg += f"• `{f.get('recommended_title', f['title'])[:60]}`\n"
                    msg += f"  💰 {f.get('bounty_estimate', 'N/A')}\n"

            report_path = results.get("report_paths", {}).get("html", "")
            if report_path:
                msg += f"\n📄 Report: `{report_path}`"

            keyboard = [[
                InlineKeyboardButton("📋 View Findings", callback_data=f"findings:{domain}"),
                InlineKeyboardButton("🔁 Re-scan", callback_data=f"scan:{domain}"),
            ]]
            await self.app.bot.send_message(
                chat_id, msg, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            log.error(f"[BOT] Scan failed for {domain}: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Scan failed for {domain}: {e}")

    # ── /findings [domain] ─────────────────────────────────────────────────────
    @owner_only
    async def cmd_findings(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        domain = ctx.args[0] if ctx.args else None
        await self._send_findings(update.effective_chat.id, domain)

    async def _send_findings(self, chat_id: int, domain: str = None):
        db = await get_db()
        async with db:
            if domain:
                cursor = await db.execute("""
                    SELECT f.vuln_type, f.severity, f.title, f.endpoint, f.cvss, f.bounty_estimate, f.found_at
                    FROM findings f JOIN targets t ON f.target_id=t.id
                    WHERE t.domain=? AND f.reported=0
                    ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END
                    LIMIT 10
                """, (domain,))
            else:
                cursor = await db.execute("""
                    SELECT f.vuln_type, f.severity, f.title, f.endpoint, f.cvss, f.ai_analysis, f.found_at
                    FROM findings f
                    WHERE f.reported=0
                    ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 WHEN 'medium' THEN 3 ELSE 4 END
                    LIMIT 10
                """)
            rows = await cursor.fetchall()

        if not rows:
            await self.app.bot.send_message(chat_id, "No unreported findings yet.")
            return

        header = f"🔍 *Findings{' for ' + domain if domain else ''}*\n\n"
        lines  = [header]
        for vuln_type, severity, title, endpoint, cvss, extra, found_at in rows:
            emoji = SEVERITY_EMOJI.get(severity, "⚪")
            lines.append(
                f"{emoji} *{severity.upper()}* — {title[:50]}\n"
                f"  🔗 `{endpoint[:60]}`\n"
                f"  CVSS: {cvss or 'N/A'} | {found_at[:10]}\n"
            )

        await self.app.bot.send_message(chat_id, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    # ── /status ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        db = await get_db()
        async with db:
            t_count = (await (await db.execute("SELECT COUNT(*) FROM targets WHERE active=1")).fetchone())[0]
            f_count = (await (await db.execute("SELECT COUNT(*) FROM findings")).fetchone())[0]
            s_count = (await (await db.execute("SELECT COUNT(*) FROM subdomains")).fetchone())[0]
            running = (await (await db.execute("SELECT COUNT(*) FROM scan_jobs WHERE status='running'")).fetchone())[0]

        text = (
            f"⚙️ *Engine Status*\n\n"
            f"🎯 Active targets: {t_count}\n"
            f"🌐 Subdomains found: {s_count}\n"
            f"🐛 Total findings: {f_count}\n"
            f"🔄 Running scans: {running}\n"
            f"🕒 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    # ── /stats ─────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_stats(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        db = await get_db()
        async with db:
            by_sev = await (await db.execute("""
                SELECT severity, COUNT(*) FROM findings GROUP BY severity
            """)).fetchall()
            top_targets = await (await db.execute("""
                SELECT t.domain, COUNT(f.id) as cnt
                FROM targets t LEFT JOIN findings f ON t.id=f.target_id
                GROUP BY t.id ORDER BY cnt DESC LIMIT 5
            """)).fetchall()

        sev_str = "\n".join(f"{SEVERITY_EMOJI.get(s,'⚪')} {s.capitalize()}: {c}" for s, c in by_sev)
        top_str = "\n".join(f"  `{d}` — {c} findings" for d, c in top_targets)

        text = (
            f"📊 *Stats Dashboard*\n\n"
            f"*By Severity:*\n{sev_str}\n\n"
            f"*Top Targets:*\n{top_str}"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    # ── /report <domain> ──────────────────────────────────────────────────────
    @owner_only
    async def cmd_report(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text("Usage: `/report example.com`", parse_mode=ParseMode.MARKDOWN)
            return
        domain = ctx.args[0]
        out_dir = Path(cfg["reporting"]["output_dir"])
        slug    = domain.replace(".", "_")
        reports = sorted(out_dir.glob(f"{slug}_*.html"), reverse=True)
        if reports:
            await update.message.reply_document(
                document=open(reports[0], "rb"),
                filename=reports[0].name,
                caption=f"📄 Latest report for {domain}"
            )
        else:
            await update.message.reply_text(f"No reports found for {domain}. Run `/scan {domain}` first.")

    # ── /stop <domain> ────────────────────────────────────────────────────────
    @owner_only
    async def cmd_stop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text("Usage: `/stop example.com`")
            return
        domain = ctx.args[0]
        db = await get_db()
        async with db:
            await db.execute("UPDATE targets SET active=0 WHERE domain=?", (domain,))
            await db.commit()
        await update.message.reply_text(f"⏸ Target `{domain}` paused.", parse_mode=ParseMode.MARKDOWN)

    # ── Inline Callbacks ──────────────────────────────────────────────────────
    async def handle_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data  = query.data

        if data == "targets":
            await self.cmd_targets(update, ctx)
        elif data == "findings_all":
            await self._send_findings(query.message.chat_id)
        elif data == "status":
            await self.cmd_status(update, ctx)
        elif data == "stats":
            await self.cmd_stats(update, ctx)
        elif data.startswith("scan:"):
            domain = data.split(":", 1)[1]
            await query.message.reply_text(f"🚀 Launching scan on `{domain}`...", parse_mode=ParseMode.MARKDOWN)
            asyncio.create_task(self._run_scan_and_notify(domain, query.message.chat_id))
        elif data.startswith("findings:"):
            domain = data.split(":", 1)[1]
            await self._send_findings(query.message.chat_id, domain)

    # ── Alert helpers (called by engine) ──────────────────────────────────────
    async def send_finding_alert(self, finding: dict, target: str):
        severity = finding.get("severity", "info")
        if severity == "critical" and not cfg["telegram"]["alert_on_critical"]:
            return
        if severity == "high" and not cfg["telegram"]["alert_on_high"]:
            return
        if severity == "medium" and not cfg["telegram"]["alert_on_medium"]:
            return

        emoji = SEVERITY_EMOJI.get(severity, "⚪")
        text = (
            f"{emoji} *New {severity.upper()} Finding*\n\n"
            f"🎯 Target: `{target}`\n"
            f"🐛 {finding.get('recommended_title', finding.get('title', ''))[:60]}\n"
            f"🔗 `{finding.get('endpoint', '')[:80]}`\n"
            f"💰 {finding.get('bounty_estimate', 'N/A')}\n\n"
            f"{finding.get('ai_analysis', '')[:200]}"
        )
        try:
            await self.app.bot.send_message(CHAT_ID, text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] Alert send failed: {e}")

    async def send_new_subdomains_alert(self, domain: str, new_subs: list):
        text = (
            f"🌐 *New Attack Surface: {domain}*\n\n"
            f"Found *{len(new_subs)}* new subdomain(s):\n"
            + "\n".join(f"  • `{s}`" for s in new_subs[:15])
            + ("\n  _(and more...)_" if len(new_subs) > 15 else "")
        )
        try:
            keyboard = [[InlineKeyboardButton(f"🔍 Scan now", callback_data=f"scan:{domain}")]]
            await self.app.bot.send_message(
                CHAT_ID, text, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            log.error(f"[BOT] Subdomain alert failed: {e}")

    @owner_only
    async def cmd_weekly(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        from core.digest import DigestBuilder
        builder = DigestBuilder()
        text    = await builder.build_weekly()
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    @owner_only
    async def cmd_digest(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        from core.digest import DigestBuilder
        builder = DigestBuilder()
        text    = await builder.build_daily()
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    async def send_daily_summary(self):
        db = await get_db()
        async with db:
            rows = await (await db.execute("""
                SELECT severity, COUNT(*) FROM findings
                WHERE DATE(found_at) = DATE('now')
                GROUP BY severity
            """)).fetchall()
        if not rows:
            return
        lines = ["📅 *Daily Summary*\n"]
        for sev, cnt in rows:
            lines.append(f"{SEVERITY_EMOJI.get(sev,'⚪')} {sev.capitalize()}: {cnt}")
        try:
            await self.app.bot.send_message(CHAT_ID, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] Daily summary failed: {e}")

    def run(self):
        log.info("[BOT] Starting Telegram bot...")
        self.app.run_polling(drop_pending_updates=True)
