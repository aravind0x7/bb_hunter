"""
core/telegram_bot.py — Telegram Bot Interface
All DB access uses fresh aiosqlite.connect() per call — thread-safe.
"""
import asyncio
import aiosqlite
import functools
import json
from datetime import datetime
from pathlib import Path
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, ContextTypes
)
from telegram.constants import ParseMode
from core.config import load_config, DB_PATH
from core.logger import log

cfg       = load_config()
BOT_TOKEN = cfg["telegram"]["bot_token"]
CHAT_ID   = str(cfg["telegram"]["chat_id"])

SEV_EMOJI = {
    "critical": "🔴", "high": "🟠", "medium": "🟡",
    "low": "🔵", "info": "⚪",
}

# ── Helper: fresh DB connection every time ─────────────────────────────────────
async def db_query(sql: str, params: tuple = (), fetchone=False, fetchall=False, write=False):
    """Execute a single SQL statement with a fresh connection."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cursor = await db.execute(sql, params)
        if write:
            await db.commit()
            return cursor.rowcount
        if fetchone:
            return await cursor.fetchone()
        if fetchall:
            return await cursor.fetchall()

# ── Decorator ──────────────────────────────────────────────────────────────────
def owner_only(func):
    @functools.wraps(func)
    async def wrapper(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if str(update.effective_chat.id) != CHAT_ID:
            await update.message.reply_text("⛔ Unauthorized.")
            return
        return await func(self, update, ctx)
    return wrapper


class BugBountyBot:
    def __init__(self):
        self.app    = Application.builder().token(BOT_TOKEN).build()
        self.engine = None   # initialised in async_init()
        self._register_handlers()

    async def async_init(self):
        """Call after the event loop is running."""
        from core.engine import ScanEngine
        self.engine = ScanEngine()
        log.info("[BOT] ScanEngine ready")

    def _register_handlers(self):
        for name, handler in [
            ("start",    self.cmd_start),
            ("help",     self.cmd_help),
            ("add",      self.cmd_add),
            ("targets",  self.cmd_targets),
            ("scan",     self.cmd_scan),
            ("findings", self.cmd_findings),
            ("status",   self.cmd_status),
            ("stats",    self.cmd_stats),
            ("report",   self.cmd_report),
            ("stop",     self.cmd_stop),
            ("remove",   self.cmd_remove),
            ("digest",   self.cmd_digest),
            ("weekly",   self.cmd_weekly),
        ]:
            self.app.add_handler(CommandHandler(name, handler))
        self.app.add_handler(CallbackQueryHandler(self.handle_callback))

    async def register_commands(self):
        from telegram import BotCommand
        cmds = [
            ("start",    "Show main menu"),
            ("add",      "Add a target domain"),
            ("scan",     "Trigger a full scan"),
            ("findings", "View latest findings"),
            ("report",   "Download HTML report"),
            ("targets",  "List all targets"),
            ("status",   "Engine status"),
            ("stats",    "Findings dashboard"),
            ("digest",   "Today's summary"),
            ("weekly",   "7-day trend report"),
            ("stop",     "Pause a target"),
            ("remove",   "Permanently delete a target"),
            ("help",     "Show all commands"),
        ]
        await self.app.bot.set_my_commands([BotCommand(c, d) for c, d in cmds])
        log.info("[BOT] Commands registered")

    # ── /start ─────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "🐛 *Bug Bounty Engine* — Online\n\n"
            "Your automated hunting machine is ready\\.\n\n"
            "`/add example\\.com` — Add a target\n"
            "`/scan example\\.com` — Run full scan\n"
            "`/findings` — Latest findings\n"
            "`/targets` — All targets\n"
            "`/status` — Engine status\n"
            "`/stats` — Dashboard\n"
        )
        keyboard = [
            [InlineKeyboardButton("📋 Targets",  callback_data="targets"),
             InlineKeyboardButton("🔍 Findings", callback_data="findings_all")],
            [InlineKeyboardButton("📊 Stats",    callback_data="stats"),
             InlineKeyboardButton("⚙️ Status",   callback_data="status")],
        ]
        await update.message.reply_text(
            text, parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=InlineKeyboardMarkup(keyboard)
        )

    # ── /help ──────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "🛠 *Commands*\n\n"
            "/add `domain` — Add target\n"
            "/scan `domain` — Run full scan\n"
            "/targets — List all targets\n"
            "/findings `[domain]` — Recent findings\n"
            "/report `domain` — Get HTML report\n"
            "/status — Engine status\n"
            "/stats — Dashboard\n"
            "/digest — Today's summary\n"
            "/weekly — 7-day trends\n"
            "/stop `domain` — Pause target\n"
        )
        await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    # ── /add ───────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_add(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text(
                "Usage: `/add example.com`\nOptional: `/add example.com ProgramName`",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        domain  = ctx.args[0].lower().strip()
        program = ctx.args[1] if len(ctx.args) > 1 else ""
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute(
                    "INSERT OR IGNORE INTO targets (domain, program) VALUES (?,?)",
                    (domain, program)
                )
                await db.commit()
            await update.message.reply_text(
                f"✅ Added: `{domain}`\n"
                f"Program: {program or 'N/A'}\n\n"
                f"Use `/scan {domain}` to start now, or it auto-scans on schedule.",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            log.error(f"[BOT] cmd_add error: {e}")
            await update.message.reply_text(f"❌ Error adding target: {e}")

    # ── /targets ───────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_targets(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await self._send_targets(update.effective_chat.id)

    # ── /scan ──────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_scan(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text("Usage: `/scan example.com`", parse_mode=ParseMode.MARKDOWN)
            return
        domain = ctx.args[0].lower().strip()
        await update.message.reply_text(
            f"🚀 Scan started: `{domain}`\n\n"
            "Phases: Recon → Takeover → CVE → Vuln → Nuclei → API → Fuzz → AI Triage → Report\n"
            "You'll get an alert when findings are ready.",
            parse_mode=ParseMode.MARKDOWN
        )
        asyncio.create_task(self._run_scan(domain, update.effective_chat.id))

    async def _run_scan(self, domain: str, chat_id: int):
        try:
            results  = await self.engine.scan_target(domain)
            findings = results.get("findings", [])
            critical = [f for f in findings if f.get("severity") == "critical"]
            high     = [f for f in findings if f.get("severity") == "high"]

            msg = (
                f"✅ *Scan Complete: {domain}*\n\n"
                f"🔴 Critical: {len(critical)}\n"
                f"🟠 High: {len(high)}\n"
                f"📊 Total findings: {len(findings)}\n"
            )
            if critical:
                msg += "\n*Top Critical:*\n"
                for f in critical[:3]:
                    title = f.get("recommended_title", f.get("title", ""))[:55]
                    bounty = f.get("bounty_estimate", "N/A")
                    msg += f"• `{title}`\n  💰 {bounty}\n"

            report_path = results.get("report_paths", {}).get("html", "")
            if report_path:
                msg += f"\n📄 Report saved: `{report_path}`"

            keyboard = [[
                InlineKeyboardButton("📋 Findings", callback_data=f"findings:{domain}"),
                InlineKeyboardButton("🔁 Re-scan",  callback_data=f"scan:{domain}"),
            ]]
            await self.app.bot.send_message(
                chat_id, msg, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            log.error(f"[BOT] Scan error for {domain}: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Scan failed for `{domain}`:\n{e}")

    # ── /findings ──────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_findings(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        domain = ctx.args[0] if ctx.args else None
        await self._send_findings(update.effective_chat.id, domain)

    # ── /status ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await self._send_status(update.effective_chat.id)

    # ── /stats ─────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_stats(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await self._send_stats(update.effective_chat.id)

    # ── /report ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_report(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text("Usage: `/report example.com`", parse_mode=ParseMode.MARKDOWN)
            return
        domain  = ctx.args[0]
        out_dir = Path(cfg["reporting"]["output_dir"])
        slug    = domain.replace(".", "_")
        reports = sorted(out_dir.glob(f"{slug}_*.html"), reverse=True)
        if reports:
            await update.message.reply_document(
                document=open(reports[0], "rb"),
                filename=reports[0].name,
                caption=f"📄 Latest report for {domain}"
            )
        else:
            await update.message.reply_text(
                f"No reports yet for `{domain}`.\nRun `/scan {domain}` first.",
                parse_mode=ParseMode.MARKDOWN
            )

    # ── /stop ──────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_stop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text("Usage: `/stop example.com`")
            return
        domain = ctx.args[0].lower().strip()
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("UPDATE targets SET active=0 WHERE domain=?", (domain,))
                await db.commit()
            await update.message.reply_text(f"⏸ Paused: `{domain}`", parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")


    # ── /remove ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_remove(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.message.reply_text(
                "Usage: `/remove example.com`\n\n"
                "This permanently deletes the target and all its findings from the database.\n"
                "Use `/stop example.com` to just pause scanning without deleting.",
                parse_mode=ParseMode.MARKDOWN
            )
            return
        domain = ctx.args[0].lower().strip()
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                # Check it exists first
                row = await (await db.execute(
                    "SELECT id FROM targets WHERE domain=?", (domain,)
                )).fetchone()
                if not row:
                    await update.message.reply_text(
                        f"❌ Target `{domain}` not found in database.",
                        parse_mode=ParseMode.MARKDOWN
                    )
                    return
                target_id = row[0]
                # Delete findings, subdomains, scan jobs, then target
                await db.execute("DELETE FROM findings   WHERE target_id=?", (target_id,))
                await db.execute("DELETE FROM subdomains WHERE target_id=?", (target_id,))
                await db.execute("DELETE FROM scan_jobs  WHERE target_id=?", (target_id,))
                await db.execute("DELETE FROM targets    WHERE id=?",        (target_id,))
                await db.commit()
            await update.message.reply_text(
                f"🗑 Removed: `{domain}`\n"
                f"All findings, subdomains and scan history deleted.",
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            log.error(f"[BOT] cmd_remove error: {e}")
            await update.message.reply_text(f"❌ Error removing target: {e}")

    # ── /digest ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_digest(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            from core.digest import DigestBuilder
            text = await DigestBuilder().build_daily()
            await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            await update.message.reply_text(f"❌ Digest error: {e}")

    # ── /weekly ────────────────────────────────────────────────────────────────
    @owner_only
    async def cmd_weekly(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        try:
            from core.digest import DigestBuilder
            text = await DigestBuilder().build_weekly()
            await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            await update.message.reply_text(f"❌ Weekly error: {e}")

    # ── Inline button handler ──────────────────────────────────────────────────
    async def handle_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query   = update.callback_query
        await query.answer()
        data    = query.data
        chat_id = query.message.chat_id

        if data == "targets":
            await self._send_targets(chat_id)
        elif data == "findings_all":
            await self._send_findings(chat_id)
        elif data == "status":
            await self._send_status(chat_id)
        elif data == "stats":
            await self._send_stats(chat_id)
        elif data.startswith("scan:"):
            domain = data.split(":", 1)[1]
            await query.message.reply_text(
                f"🚀 Launching scan on `{domain}`...", parse_mode=ParseMode.MARKDOWN
            )
            asyncio.create_task(self._run_scan(domain, chat_id))
        elif data.startswith("findings:"):
            domain = data.split(":", 1)[1]
            await self._send_findings(chat_id, domain)

    # ── Reusable send helpers (all use fresh DB connections) ───────────────────
    async def _send_status(self, chat_id: int):
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                t = (await (await db.execute("SELECT COUNT(*) FROM targets WHERE active=1")).fetchone())[0]
                f = (await (await db.execute("SELECT COUNT(*) FROM findings")).fetchone())[0]
                s = (await (await db.execute("SELECT COUNT(*) FROM subdomains")).fetchone())[0]
                r = (await (await db.execute("SELECT COUNT(*) FROM scan_jobs WHERE status='running'")).fetchone())[0]
            text = (
                f"⚙️ *Engine Status*\n\n"
                f"🎯 Active targets: {t}\n"
                f"🌐 Subdomains: {s}\n"
                f"🐛 Total findings: {f}\n"
                f"🔄 Running scans: {r}\n"
                f"🕒 {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            )
            await self.app.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] _send_status: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Status error: {e}")

    async def _send_stats(self, chat_id: int):
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                by_sev = await (await db.execute(
                    "SELECT severity, COUNT(*) FROM findings GROUP BY severity "
                    "ORDER BY CASE severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2 "
                    "WHEN 'medium' THEN 3 WHEN 'low' THEN 4 ELSE 5 END"
                )).fetchall()
                top = await (await db.execute(
                    "SELECT t.domain, COUNT(f.id) FROM targets t "
                    "LEFT JOIN findings f ON t.id=f.target_id "
                    "GROUP BY t.id ORDER BY COUNT(f.id) DESC LIMIT 5"
                )).fetchall()
            sev_str = "\n".join(f"{SEV_EMOJI.get(s,'⚪')} {s.capitalize()}: {c}" for s,c in by_sev) or "No findings yet"
            top_str = "\n".join(f"  `{d}` — {c} findings" for d,c in top) or "  None yet"
            text = f"📊 *Stats*\n\n*By Severity:*\n{sev_str}\n\n*Top Targets:*\n{top_str}"
            await self.app.bot.send_message(chat_id, text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] _send_stats: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Stats error: {e}")

    async def _send_targets(self, chat_id: int):
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                rows = await (await db.execute(
                    "SELECT domain, program, last_scan, active FROM targets ORDER BY added_at DESC"
                )).fetchall()
            if not rows:
                await self.app.bot.send_message(
                    chat_id, "No targets yet.\nUse /add example.com to add one."
                )
                return
            lines = ["🎯 *Targets*\n"]
            for domain, program, last_scan, active in rows:
                icon = "🟢" if active else "🔴"
                scan = last_scan[:16] if last_scan else "never"
                lines.append(f"{icon} `{domain}` — {program or 'no program'} — {scan}")
            keyboard = [
                [InlineKeyboardButton(f"🔍 Scan {r[0]}", callback_data=f"scan:{r[0]}")]
                for r in rows[:5]
            ]
            await self.app.bot.send_message(
                chat_id, "\n".join(lines),
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            log.error(f"[BOT] _send_targets: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Targets error: {e}")

    async def _send_findings(self, chat_id: int, domain: str = None):
        try:
            async with aiosqlite.connect(DB_PATH) as db:
                if domain:
                    rows = await (await db.execute("""
                        SELECT f.severity, f.vuln_type, f.title, f.endpoint, f.cvss, f.bounty_estimate, f.found_at
                        FROM findings f JOIN targets t ON f.target_id=t.id
                        WHERE t.domain=? AND f.reported=0
                        ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                        WHEN 'medium' THEN 3 ELSE 4 END LIMIT 10
                    """, (domain,))).fetchall()
                else:
                    rows = await (await db.execute("""
                        SELECT f.severity, f.vuln_type, f.title, f.endpoint, f.cvss, f.bounty_estimate, f.found_at
                        FROM findings f WHERE f.reported=0
                        ORDER BY CASE f.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                        WHEN 'medium' THEN 3 ELSE 4 END LIMIT 10
                    """)).fetchall()
            if not rows:
                msg = f"No unreported findings yet" + (f" for {domain}" if domain else "") + "."
                await self.app.bot.send_message(chat_id, msg)
                return
            header = f"🔍 *Findings{' — ' + domain if domain else ''}*\n\n"
            lines  = [header]
            for sev, vtype, title, endpoint, cvss, bounty, found_at in rows:
                emo = SEV_EMOJI.get(sev, "⚪")
                short_title = (title or vtype or "")[:50]
                short_ep    = (endpoint or "")[:55]
                lines.append(
                    f"{emo} *{sev.upper()}* — {short_title}\n"
                    f"  🔗 `{short_ep}`\n"
                    f"  CVSS: {cvss or 'N/A'} | 💰 {bounty or 'N/A'} | {(found_at or '')[:10]}\n"
                )
            await self.app.bot.send_message(chat_id, "\n".join(lines), parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] _send_findings: {e}")
            await self.app.bot.send_message(chat_id, f"❌ Findings error: {e}")

    # ── Alert helpers (called by engine/scheduler) ─────────────────────────────
    async def send_finding_alert(self, finding: dict, target: str):
        sev = finding.get("severity", "info")
        if sev == "critical" and not cfg["telegram"].get("alert_on_critical", True): return
        if sev == "high"     and not cfg["telegram"].get("alert_on_high",     True): return
        if sev == "medium"   and not cfg["telegram"].get("alert_on_medium",  False): return
        emo   = SEV_EMOJI.get(sev, "⚪")
        title = finding.get("recommended_title", finding.get("title", ""))[:60]
        ep    = finding.get("endpoint", "")[:80]
        text  = (
            f"{emo} *New {sev.upper()} Finding*\n\n"
            f"🎯 Target: `{target}`\n"
            f"🐛 {title}\n"
            f"🔗 `{ep}`\n"
            f"💰 {finding.get('bounty_estimate', 'N/A')}\n\n"
            f"{finding.get('ai_analysis', '')[:200]}"
        )
        try:
            await self.app.bot.send_message(CHAT_ID, text, parse_mode=ParseMode.MARKDOWN)
        except Exception as e:
            log.error(f"[BOT] Alert failed: {e}")

    async def send_new_subdomains_alert(self, domain: str, new_subs: list):
        text = (
            f"🌐 *New subdomains: {domain}*\n\n"
            f"Found *{len(new_subs)}* new:\n"
            + "\n".join(f"  • `{s}`" for s in new_subs[:15])
            + ("\n  _(and more...)_" if len(new_subs) > 15 else "")
        )
        try:
            keyboard = [[InlineKeyboardButton("🔍 Scan now", callback_data=f"scan:{domain}")]]
            await self.app.bot.send_message(
                CHAT_ID, text, parse_mode=ParseMode.MARKDOWN,
                reply_markup=InlineKeyboardMarkup(keyboard)
            )
        except Exception as e:
            log.error(f"[BOT] Subdomain alert failed: {e}")

    # NOTE: polling started externally in main.py via app.updater.start_polling()
