"""
core/rate_limiter.py — Adaptive rate limiter + smart request manager
Features:
  - Per-domain rate limiting
  - Auto-backoff on 429/503
  - Rotating user agents
  - Random jitter to avoid pattern detection
  - Respect Retry-After headers
"""
import asyncio
import random
import time
from collections import defaultdict
from core.config import load_config
from core.logger import log

cfg = load_config()

USER_AGENTS = [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.1; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Googlebot/2.1 (+http://www.google.com/bot.html)",  # sometimes useful for WAF bypass
]

ACCEPT_HEADERS = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "application/json, text/plain, */*",
]


class RateLimiter:
    """Token-bucket rate limiter per domain."""

    def __init__(self, rate: float = None, burst: int = 10):
        self._rate    = rate or cfg["engine"]["rate_limit_delay"]
        self._burst   = burst
        self._tokens  = defaultdict(lambda: burst)
        self._last    = defaultdict(float)
        self._backoff = defaultdict(float)   # per-domain backoff end timestamp
        self._lock    = asyncio.Lock()

    async def acquire(self, domain: str):
        async with self._lock:
            now = time.monotonic()

            # Check if in backoff
            if self._backoff[domain] > now:
                wait = self._backoff[domain] - now
                log.debug(f"[RATELIMIT] Backing off {domain} for {wait:.1f}s")
                await asyncio.sleep(wait)

            # Refill tokens
            elapsed = now - self._last[domain]
            refill  = elapsed / self._rate
            self._tokens[domain] = min(self._burst, self._tokens[domain] + refill)
            self._last[domain]   = now

            if self._tokens[domain] >= 1:
                self._tokens[domain] -= 1
            else:
                wait = (1 - self._tokens[domain]) * self._rate
                # Add jitter ±20%
                jitter = wait * 0.2 * (random.random() * 2 - 1)
                await asyncio.sleep(wait + jitter)
                self._tokens[domain] = 0

    def on_rate_limited(self, domain: str, retry_after: int = 60):
        """Call this when a 429 is received."""
        backoff = time.monotonic() + retry_after
        self._backoff[domain] = backoff
        log.warning(f"[RATELIMIT] 429 received for {domain} — backing off {retry_after}s")

    def on_error(self, domain: str):
        """Exponential backoff on server errors."""
        current = self._backoff.get(domain, 0)
        now     = time.monotonic()
        elapsed = max(0, current - now)
        new_backoff = min(elapsed * 2 + 5, 120)  # cap at 2 min
        self._backoff[domain] = now + new_backoff


class SmartRequester:
    """
    Wraps aiohttp with rate limiting, UA rotation, retry logic,
    and WAF evasion headers.
    """

    def __init__(self, rate_limiter: RateLimiter = None):
        self.rl = rate_limiter or RateLimiter()

    def _get_headers(self, extra: dict = None) -> dict:
        headers = {
            "User-Agent":      random.choice(USER_AGENTS),
            "Accept":          random.choice(ACCEPT_HEADERS),
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control":   "no-cache",
            "Pragma":          "no-cache",
            "DNT":             "1",
            "Sec-Fetch-Dest":  "document",
            "Sec-Fetch-Mode":  "navigate",
            "Sec-Fetch-Site":  "none",
        }
        if extra:
            headers.update(extra)
        return headers

    async def get(self, session, url: str, retries: int = 3, **kwargs) -> tuple:
        """
        Returns (status_code, response_text, headers) or (None, None, None) on failure.
        """
        from urllib.parse import urlparse
        domain = urlparse(url).hostname or url

        for attempt in range(retries):
            await self.rl.acquire(domain)
            try:
                headers = self._get_headers(kwargs.pop("headers", None))
                async with session.get(url, headers=headers, **kwargs) as resp:
                    if resp.status == 429:
                        retry_after = int(resp.headers.get("Retry-After", 60))
                        self.rl.on_rate_limited(domain, retry_after)
                        await asyncio.sleep(retry_after)
                        continue
                    if resp.status in (500, 502, 503, 504):
                        self.rl.on_error(domain)
                        await asyncio.sleep(2 ** attempt)
                        continue

                    text = await resp.text(errors="ignore")
                    return resp.status, text, dict(resp.headers)

            except asyncio.TimeoutError:
                log.debug(f"[REQUESTER] Timeout: {url} (attempt {attempt+1})")
                await asyncio.sleep(2 ** attempt)
            except Exception as e:
                log.debug(f"[REQUESTER] Error {url}: {e}")
                break

        return None, None, None

    async def post(self, session, url: str, retries: int = 2, **kwargs) -> tuple:
        from urllib.parse import urlparse
        domain = urlparse(url).hostname or url

        for attempt in range(retries):
            await self.rl.acquire(domain)
            try:
                headers = self._get_headers(kwargs.pop("headers", None))
                async with session.post(url, headers=headers, **kwargs) as resp:
                    if resp.status == 429:
                        retry_after = int(resp.headers.get("Retry-After", 60))
                        self.rl.on_rate_limited(domain, retry_after)
                        await asyncio.sleep(retry_after)
                        continue
                    text = await resp.text(errors="ignore")
                    return resp.status, text, dict(resp.headers)
            except Exception as e:
                log.debug(f"[REQUESTER] POST error {url}: {e}")
                break

        return None, None, None


# Singleton
_rate_limiter = RateLimiter()
requester     = SmartRequester(_rate_limiter)
