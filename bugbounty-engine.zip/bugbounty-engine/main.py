#!/usr/bin/env python3
"""
main.py — Bug Bounty Engine entry point
Usage:
  python main.py           — Start full engine (bot + scheduler)
  python main.py scan <domain>  — One-shot scan from CLI
  python main.py add <domain>   — Add target
  python main.py list            — List targets
"""
import asyncio
import sys
import argparse
from core.config import init_db, load_config
from core.logger import log
from core.engine import ScanEngine, Scheduler
from core.telegram_bot import BugBountyBot
from rich.console import Console
from rich.table import Table
from rich import print as rprint

cfg     = Console()
console = Console()


def print_banner():
    console.print("""
[bold purple]
 ██████╗ ██╗   ██╗ ██████╗     ██████╗  ██████╗ ██╗   ██╗███╗   ██╗████████╗██╗   ██╗
 ██╔══██╗██║   ██║██╔════╝     ██╔══██╗██╔═══██╗██║   ██║████╗  ██║╚══██╔══╝╚██╗ ██╔╝
 ██████╔╝██║   ██║██║  ███╗    ██████╔╝██║   ██║██║   ██║██╔██╗ ██║   ██║    ╚████╔╝
 ██╔══██╗██║   ██║██║   ██║    ██╔══██╗██║   ██║██║   ██║██║╚██╗██║   ██║     ╚██╔╝
 ██████╔╝╚██████╔╝╚██████╔╝    ██████╔╝╚██████╔╝╚██████╔╝██║ ╚████║   ██║      ██║
 ╚═════╝  ╚═════╝  ╚═════╝     ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝   ╚═╝      ╚═╝
[/bold purple]
[bold cyan]Bug Bounty Engine v1.0[/bold cyan] — [green]Automated. Intelligent. Always hunting.[/green]
""")


async def run_full_engine():
    """Start the bot + background scheduler + web dashboard together."""
    await init_db()
    engine = ScanEngine()
    bot    = BugBountyBot()
    sched  = Scheduler(engine, bot)

    from core.dashboard import Dashboard
    dash = Dashboard()

    log.info("[MAIN] Engine online — bot + scheduler + dashboard starting")

    # Background tasks
    asyncio.create_task(sched.run())
    asyncio.create_task(dash.start())

    # Bot blocks (polling loop)
    bot.run()


async def cli_scan(domain: str):
    await init_db()
    engine = ScanEngine()
    console.print(f"[cyan]Starting scan:[/cyan] {domain}")
    results  = await engine.scan_target(domain)
    findings = results.get("findings", [])

    table = Table(title=f"Findings — {domain}", show_lines=True)
    table.add_column("Severity", style="bold", width=10)
    table.add_column("Type", width=20)
    table.add_column("Title", width=40)
    table.add_column("CVSS", width=6)
    table.add_column("Bounty Est.", width=14)

    colors = {"critical": "red", "high": "orange3", "medium": "yellow", "low": "blue", "info": "white"}
    for f in findings:
        sev   = f.get("severity", "info")
        color = colors.get(sev, "white")
        table.add_row(
            f"[{color}]{sev.upper()}[/{color}]",
            f.get("vuln_type", ""),
            f.get("recommended_title", f.get("title", ""))[:40],
            str(f.get("cvss", "")),
            f.get("bounty_estimate", ""),
        )

    console.print(table)
    paths = results.get("report_paths", {})
    if paths:
        console.print(f"\n[green]Reports:[/green]")
        for fmt, path in paths.items():
            console.print(f"  [{fmt}] {path}")


async def cli_add(domain: str, program: str = ""):
    await init_db()
    from core.config import get_db
    db = await get_db()
    async with db:
        await db.execute("INSERT OR IGNORE INTO targets (domain, program) VALUES (?,?)", (domain, program))
        await db.commit()
    console.print(f"[green]✓ Added target:[/green] {domain}")


async def cli_list():
    await init_db()
    from core.config import get_db
    db = await get_db()
    async with db:
        cursor = await db.execute("""
            SELECT t.domain, t.program, t.last_scan,
                   COUNT(f.id) as findings
            FROM targets t LEFT JOIN findings f ON t.id=f.target_id
            GROUP BY t.id ORDER BY t.added_at DESC
        """)
        rows = await cursor.fetchall()

    table = Table(title="Targets", show_lines=True)
    table.add_column("Domain")
    table.add_column("Program")
    table.add_column("Last Scan")
    table.add_column("Findings", justify="right")
    for domain, program, last_scan, count in rows:
        table.add_row(domain, program or "—", last_scan[:16] if last_scan else "never", str(count))
    console.print(table)


def main():
    print_banner()
    parser = argparse.ArgumentParser(description="Bug Bounty Engine")
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("start",   help="Start full engine (bot + scheduler + dashboard)")
    sub.add_parser("dashboard", help="Start web dashboard only (port 8080)")
    sub.add_parser("digest",  help="Print today's digest to stdout")

    p_scan = sub.add_parser("scan", help="One-shot scan")
    p_scan.add_argument("domain")

    p_add = sub.add_parser("add", help="Add target")
    p_add.add_argument("domain")
    p_add.add_argument("--program", default="")

    sub.add_parser("list", help="List targets")

    args = parser.parse_args()

    if args.command == "scan":
        asyncio.run(cli_scan(args.domain))
    elif args.command == "add":
        asyncio.run(cli_add(args.domain, args.program))
    elif args.command == "list":
        asyncio.run(cli_list())
    elif args.command == "digest":
        async def _digest():
            await init_db()
            from core.digest import DigestBuilder
            text = await DigestBuilder().build_daily()
            console.print(text)
        asyncio.run(_digest())
    elif args.command == "dashboard":
        async def _dash():
            await init_db()
            from core.dashboard import Dashboard
            d = Dashboard()
            console.print("[cyan]Dashboard at http://localhost:8080[/cyan]")
            await d.run()
        asyncio.run(_dash())
    else:
        # Default: start full engine
        asyncio.run(run_full_engine())


if __name__ == "__main__":
    main()
