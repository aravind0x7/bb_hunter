#!/usr/bin/env python3
"""
main.py — Bug Bounty Engine entry point

Usage:
  python main.py              — Start full engine (bot + scheduler + dashboard)
  python main.py scan <domain>  — One-shot scan from CLI
  python main.py add <domain>   — Add target
  python main.py list           — List targets
  python main.py digest         — Print today's summary
  python main.py dashboard      — Web UI only at :8080
"""
import asyncio
import sys
import signal
import argparse
from core.config import init_db, load_config
from core.logger import log
from rich.console import Console
from rich.table import Table

console = Console()
cfg     = load_config()


def print_banner():
    console.print(
        "\n[bold purple]Bug Bounty Engine v1.0[/bold purple] — "
        "[green]Automated. Intelligent. Always hunting.[/green]\n"
    )


# ── Full engine ────────────────────────────────────────────────────────────────
async def run_full_engine():
    await init_db()

    from core.engine import Scheduler
    from core.telegram_bot import BugBountyBot
    from core.dashboard import Dashboard

    bot    = BugBountyBot()
    dash   = Dashboard()

    log.info("[MAIN] Starting engine...")

    # ── Init Telegram app ──────────────────────────────────────────────────────
    await bot.app.initialize()

    # Delete any leftover webhook from previous runs (fixes the warning)
    try:
        await bot.app.bot.delete_webhook(drop_pending_updates=True)
        log.info("[BOT] Webhook cleared")
    except Exception as e:
        log.warning(f"[BOT] Webhook clear failed (non-fatal): {e}")

    await bot.app.start()

    # Initialise scan engine inside the running event loop (single shared instance)
    await bot.async_init()

    # Pass the same engine instance to scheduler
    sched = Scheduler(bot.engine, bot)

    # Start polling — allowed_updates=[] means all update types
    await bot.app.updater.start_polling(
        drop_pending_updates=True,
        allowed_updates=["message", "callback_query"],
    )
    log.info("[BOT] Polling started")

    # Register commands in Telegram menu
    try:
        await bot.register_commands()
    except Exception as e:
        log.warning(f"[BOT] Command registration failed (non-fatal): {e}")

    # ── Start dashboard ────────────────────────────────────────────────────────
    try:
        await dash.start()
        log.info("[DASHBOARD] http://127.0.0.1:8080")
    except Exception as e:
        log.warning(f"[DASHBOARD] Failed to start (non-fatal): {e}")

    # ── Signal handling ────────────────────────────────────────────────────────
    stop_event = asyncio.Event()

    def _handle_signal():
        log.info("[MAIN] Shutdown signal received")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _handle_signal)
        except (NotImplementedError, RuntimeError):
            pass

    # ── Run scheduler in background ────────────────────────────────────────────
    sched_task = asyncio.create_task(sched.run(), name="scheduler")

    log.info("[MAIN] All systems running. Send /start to your Telegram bot.")

    # ── Wait for shutdown ──────────────────────────────────────────────────────
    try:
        await stop_event.wait()
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass
    finally:
        log.info("[MAIN] Shutting down gracefully...")
        sched_task.cancel()
        try:
            await sched_task
        except asyncio.CancelledError:
            pass
        try:
            await bot.app.updater.stop()
            await bot.app.stop()
            await bot.app.shutdown()
        except Exception as e:
            log.warning(f"[MAIN] Shutdown warning: {e}")
        log.info("[MAIN] Shutdown complete.")


# ── CLI helpers ────────────────────────────────────────────────────────────────
async def cli_scan(domain: str):
    await init_db()
    from core.engine import ScanEngine
    engine   = ScanEngine()
    console.print(f"[cyan]Starting scan:[/cyan] {domain}")
    results  = await engine.scan_target(domain)
    findings = results.get("findings", [])

    table = Table(title=f"Findings — {domain}", show_lines=True)
    table.add_column("Severity", style="bold", width=10)
    table.add_column("Type",     width=22)
    table.add_column("Title",    width=42)
    table.add_column("CVSS",     width=6)
    table.add_column("Bounty",   width=14)

    colors = {"critical": "red", "high": "orange3", "medium": "yellow",
              "low": "blue", "info": "white"}
    for f in findings:
        sev   = f.get("severity", "info")
        color = colors.get(sev, "white")
        table.add_row(
            f"[{color}]{sev.upper()}[/{color}]",
            f.get("vuln_type", "")[:22],
            f.get("recommended_title", f.get("title", ""))[:42],
            str(f.get("cvss", "")),
            f.get("bounty_estimate", ""),
        )

    console.print(table)
    paths = results.get("report_paths", {})
    if paths:
        console.print("\n[green]Reports:[/green]")
        for fmt, path in paths.items():
            console.print(f"  [{fmt}] {path}")


async def cli_add(domain: str, program: str = ""):
    await init_db()
    import aiosqlite
    from core.config import DB_PATH
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO targets (domain, program) VALUES (?,?)",
            (domain, program)
        )
        await db.commit()
    console.print(f"[green]✓ Added target:[/green] {domain}")


async def cli_list():
    await init_db()
    import aiosqlite
    from core.config import DB_PATH
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute("""
            SELECT t.domain, t.program, t.last_scan, COUNT(f.id) as findings
            FROM targets t LEFT JOIN findings f ON t.id = f.target_id
            GROUP BY t.id ORDER BY t.added_at DESC
        """)
        rows = await cursor.fetchall()

    table = Table(title="Targets", show_lines=True)
    table.add_column("Domain")
    table.add_column("Program")
    table.add_column("Last Scan")
    table.add_column("Findings", justify="right")
    for domain, program, last_scan, count in rows:
        table.add_row(
            domain,
            program or "—",
            last_scan[:16] if last_scan else "never",
            str(count)
        )
    console.print(table)


async def cli_digest():
    await init_db()
    from core.digest import DigestBuilder
    text = await DigestBuilder().build_daily()
    console.print(text)


async def cli_dashboard():
    await init_db()
    from core.dashboard import Dashboard
    dash = Dashboard()
    await dash.start()
    console.print("[cyan]Dashboard running at http://127.0.0.1:8080[/cyan]")
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    try:
        await asyncio.Event().wait()
    except (KeyboardInterrupt, asyncio.CancelledError):
        pass


# ── Entry point ────────────────────────────────────────────────────────────────
def main():
    print_banner()

    parser = argparse.ArgumentParser(description="Bug Bounty Engine")
    sub    = parser.add_subparsers(dest="command")

    sub.add_parser("start",     help="Start full engine (default)")
    sub.add_parser("dashboard", help="Web UI only at :8080")
    sub.add_parser("digest",    help="Print today's digest")
    sub.add_parser("list",      help="List all targets")

    p_scan = sub.add_parser("scan", help="One-shot scan")
    p_scan.add_argument("domain")

    p_add = sub.add_parser("add", help="Add target")
    p_add.add_argument("domain")
    p_add.add_argument("--program", default="")

    args = parser.parse_args()
    cmd  = args.command or "start"

    try:
        if cmd == "scan":
            asyncio.run(cli_scan(args.domain))
        elif cmd == "add":
            asyncio.run(cli_add(args.domain, args.program))
        elif cmd == "list":
            asyncio.run(cli_list())
        elif cmd == "digest":
            asyncio.run(cli_digest())
        elif cmd == "dashboard":
            asyncio.run(cli_dashboard())
        else:
            asyncio.run(run_full_engine())
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped.[/yellow]")


if __name__ == "__main__":
    main()
