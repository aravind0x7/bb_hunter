#!/bin/bash
# ============================================================
#  Bug Bounty Engine — VPS Setup Script
#  Supports: Ubuntu 20.04 / 22.04 / 24.04 / Debian 11+
#  Run as: bash setup.sh
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

info()    { echo -e "${GREEN}[+]${NC} $1"; }
warn()    { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[-]${NC} $1"; }
section() { echo -e "\n${BLUE}══${NC} $1"; }

INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_DIR"

echo ""
echo "=================================================="
echo -e "  ${GREEN}Bug Bounty Engine — Setup${NC}"
echo "=================================================="

# ── Detect OS & Python ─────────────────────────────────────
section "Detecting system"
OS=$(lsb_release -si 2>/dev/null || echo "Unknown")
VER=$(lsb_release -sr 2>/dev/null || echo "0")
info "OS: $OS $VER"

# Find best available Python (3.11 > 3.10 > 3.9 > 3.8 > 3)
PYTHON=""
for py in python3.12 python3.11 python3.10 python3.9 python3.8 python3; do
    if command -v "$py" &>/dev/null; then
        PYVER=$($py -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        PYMAJ=$(echo $PYVER | cut -d. -f1)
        PYMIN=$(echo $PYVER | cut -d. -f2)
        if [ "$PYMAJ" -ge 3 ] && [ "$PYMIN" -ge 8 ]; then
            PYTHON="$py"
            info "Found Python: $py ($PYVER)"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    warn "No suitable Python found — attempting to install via deadsnakes PPA"
    sudo apt-get update -qq
    sudo apt-get install -y software-properties-common -qq
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    sudo apt-get update -qq
    sudo apt-get install -y python3.11 python3.11-venv python3.11-distutils -qq
    PYTHON="python3.11"
fi

info "Using: $PYTHON"

# ── System packages ────────────────────────────────────────
section "Installing system packages"
sudo apt-get update -qq

# Core packages — available on all Ubuntu/Debian versions
PKGS="nmap git curl wget unzip build-essential libssl-dev libffi-dev"

# Python dev headers for the detected version
PYVER_SHORT=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PYMAJ=$($PYTHON -c "import sys; print(sys.version_info.major)")
PYMIN=$($PYTHON -c "import sys; print(sys.version_info.minor)")

# Try to install python3.X-dev and python3.X-venv, fall back to generic
if apt-cache show "python${PYVER_SHORT}-dev" &>/dev/null 2>&1; then
    PKGS="$PKGS python${PYVER_SHORT}-dev python${PYVER_SHORT}-venv"
else
    PKGS="$PKGS python3-dev python3-venv"
fi

# pip — try versioned first, fall back to generic
if apt-cache show "python${PYVER_SHORT}-pip" &>/dev/null 2>&1; then
    PKGS="$PKGS python${PYVER_SHORT}-pip"
else
    PKGS="$PKGS python3-pip"
fi

sudo apt-get install -y -qq $PKGS
info "System packages installed"

# Ensure pip is available via ensurepip if still missing
if ! $PYTHON -m pip --version &>/dev/null 2>&1; then
    warn "pip not found via apt — bootstrapping with ensurepip"
    $PYTHON -m ensurepip --upgrade 2>/dev/null || {
        warn "ensurepip failed — downloading get-pip.py"
        curl -sS https://bootstrap.pypa.io/get-pip.py | $PYTHON
    }
fi

# ── Go installation ────────────────────────────────────────
section "Setting up Go"
export GOPATH="$HOME/go"
export PATH="$PATH:/usr/local/go/bin:$GOPATH/bin"

if command -v go &>/dev/null; then
    info "Go already installed: $(go version)"
else
    info "Installing Go 1.22..."
    GOARCH="amd64"
    # Detect ARM
    MACHINE=$(uname -m)
    if [[ "$MACHINE" == "aarch64" || "$MACHINE" == "arm64" ]]; then
        GOARCH="arm64"
    fi
    GO_TAR="go1.22.3.linux-${GOARCH}.tar.gz"
    wget -q "https://go.dev/dl/${GO_TAR}" -O /tmp/${GO_TAR}
    sudo tar -C /usr/local -xzf /tmp/${GO_TAR}
    rm /tmp/${GO_TAR}

    # Persist PATH
    if ! grep -q '/usr/local/go/bin' ~/.bashrc; then
        echo 'export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin' >> ~/.bashrc
    fi
    info "Go installed: $(go version)"
fi

# ── Go security tools ──────────────────────────────────────
section "Installing security tools"

declare -A TOOLS=(
    ["subfinder"]="github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    ["httpx"]="github.com/projectdiscovery/httpx/cmd/httpx@latest"
    ["nuclei"]="github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    ["waybackurls"]="github.com/tomnomnom/waybackurls@latest"
    ["gau"]="github.com/lc/gau/v2/cmd/gau@latest"
    ["ffuf"]="github.com/ffuf/ffuf/v2@latest"
)

for name in "${!TOOLS[@]}"; do
    pkg="${TOOLS[$name]}"
    if command -v "$name" &>/dev/null; then
        warn "$name already installed — skipping"
    else
        info "Installing $name..."
        go install "$pkg" 2>/dev/null && info "$name installed" || warn "$name install failed (non-fatal)"
    fi
done

# Copy go binaries to /usr/local/bin so they're in PATH for all users
for name in subfinder httpx nuclei waybackurls gau ffuf; do
    BIN="$HOME/go/bin/$name"
    if [ -f "$BIN" ] && [ ! -f "/usr/local/bin/$name" ]; then
        sudo cp "$BIN" /usr/local/bin/
    fi
done

# ── Nuclei templates ───────────────────────────────────────
if command -v nuclei &>/dev/null; then
    info "Pulling Nuclei templates (may take a minute)..."
    nuclei -update-templates -silent 2>/dev/null || warn "Nuclei template update failed (non-fatal)"
fi

# ── amass ──────────────────────────────────────────────────
if command -v amass &>/dev/null; then
    warn "amass already installed — skipping"
else
    info "Installing amass..."
    AMASS_VER="v4.2.0"
    AMASS_ARCH="amd64"
    if [[ "$(uname -m)" == "aarch64" ]]; then AMASS_ARCH="arm64"; fi
    AMASS_URL="https://github.com/owasp-amass/amass/releases/download/${AMASS_VER}/amass_Linux_${AMASS_ARCH}.zip"
    wget -q "$AMASS_URL" -O /tmp/amass.zip && \
    unzip -q /tmp/amass.zip -d /tmp/amass_tmp && \
    sudo find /tmp/amass_tmp -name "amass" -type f -exec mv {} /usr/local/bin/ \; && \
    rm -rf /tmp/amass.zip /tmp/amass_tmp && \
    info "amass installed" || warn "amass install failed (non-fatal)"
fi

# ── Python virtual environment ─────────────────────────────
section "Setting up Python environment"

# Check if venv module is available
if ! $PYTHON -m venv --help &>/dev/null 2>&1; then
    warn "venv module missing — trying to install"
    sudo apt-get install -y -qq "python${PYVER_SHORT}-venv" 2>/dev/null || \
    sudo apt-get install -y -qq python3-venv
fi

if [ -d "venv" ]; then
    warn "venv already exists — skipping creation"
else
    $PYTHON -m venv venv
    info "Virtual environment created with $PYTHON"
fi

source venv/bin/activate
pip install --upgrade pip setuptools wheel -q
info "Installing Python dependencies..."
pip install -r requirements.txt -q
info "Python dependencies installed"

# ── Create required directories ────────────────────────────
section "Creating directories"
mkdir -p data/wordlists logs output/reports data/nuclei-templates
info "Directories ready"

# ── Config setup ──────────────────────────────────────────
section "Configuration"
if [ ! -f config/config.local.yaml ]; then
    cp config/config.yaml config/config.local.yaml
    info "Created config/config.local.yaml"
else
    warn "config/config.local.yaml already exists — not overwriting"
fi

# ── Systemd service ────────────────────────────────────────
section "Installing systemd service"
CURRENT_USER=$(whoami)

sed -e "s|User=ubuntu|User=$CURRENT_USER|g" \
    -e "s|WorkingDirectory=/opt/bugbounty-engine|WorkingDirectory=$INSTALL_DIR|g" \
    -e "s|/opt/bugbounty-engine/venv|$INSTALL_DIR/venv|g" \
    -e "s|/opt/bugbounty-engine/config/config.local.yaml|$INSTALL_DIR/config/config.local.yaml|g" \
    bugbounty-engine.service > /tmp/bugbounty-engine.service

sudo cp /tmp/bugbounty-engine.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable bugbounty-engine 2>/dev/null || warn "systemd enable failed (non-fatal)"
info "Service installed"

# ── Verify tools ──────────────────────────────────────────
section "Tool check"
for tool in nmap subfinder nuclei httpx waybackurls; do
    if command -v "$tool" &>/dev/null; then
        echo -e "  ${GREEN}✓${NC} $tool"
    else
        echo -e "  ${YELLOW}✗${NC} $tool (not found — optional)"
    fi
done

# ── Done ──────────────────────────────────────────────────
echo ""
echo "=================================================="
info "Setup complete!"
echo ""
echo -e "  ${YELLOW}Next steps:${NC}"
echo ""
echo -e "  1. Edit config:"
echo -e "     ${GREEN}nano config/config.local.yaml${NC}"
echo ""
echo -e "     Fill in:"
echo -e "       telegram.bot_token   → from @BotFather"
echo -e "       telegram.chat_id     → your Telegram user ID"
echo -e "       ai.api_key           → from dashboard.sarvam.ai (free)"
echo ""
echo -e "  2. Start the engine:"
echo -e "     ${GREEN}sudo systemctl start bugbounty-engine${NC}"
echo ""
echo -e "  3. Watch logs:"
echo -e "     ${GREEN}sudo journalctl -u bugbounty-engine -f${NC}"
echo ""
echo -e "  OR run manually:"
echo -e "     ${GREEN}source venv/bin/activate${NC}"
echo -e "     ${GREEN}python main.py${NC}"
echo ""
echo -e "  ${RED}⚠ Only scan targets you have permission to test!${NC}"
echo "=================================================="
