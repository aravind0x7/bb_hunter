#!/bin/bash
# ============================================================
#  Bug Bounty Engine — VPS Setup Script (Ubuntu 22.04)
#  Run as: bash setup.sh
# ============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

info()  { echo -e "${GREEN}[+]${NC} $1"; }
warn()  { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[-]${NC} $1"; }

info "Bug Bounty Engine — VPS Setup"
echo "=================================================="

# ── System packages ────────────────────────────────────────
info "Updating system packages..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
    python3.11 python3.11-venv python3-pip \
    nmap git curl wget unzip \
    build-essential libssl-dev libffi-dev python3-dev \
    chromium-browser chromium-chromedriver

# ── Go (for subfinder, httpx, nuclei, etc.) ──────────────
if ! command -v go &> /dev/null; then
    info "Installing Go..."
    wget -q https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
    sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
    echo 'export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin' >> ~/.bashrc
    export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin
    rm go1.21.5.linux-amd64.tar.gz
    info "Go installed"
fi

export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin

# ── Security tools ─────────────────────────────────────────
info "Installing Go-based security tools..."

tools=(
    "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    "github.com/projectdiscovery/httpx/cmd/httpx@latest"
    "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    "github.com/tomnomnom/waybackurls@latest"
    "github.com/lc/gau/v2/cmd/gau@latest"
    "github.com/ffuf/ffuf/v2@latest"
)

for tool in "${tools[@]}"; do
    name=$(basename ${tool%@*})
    if command -v "$name" &> /dev/null; then
        warn "$name already installed, skipping"
    else
        info "Installing $name..."
        go install "$tool" 2>/dev/null || warn "Failed to install $name"
    fi
done

# ── nuclei templates ───────────────────────────────────────
if command -v nuclei &> /dev/null; then
    info "Updating Nuclei templates..."
    nuclei -update-templates -silent || warn "Nuclei template update failed (non-fatal)"
fi

# ── amass ──────────────────────────────────────────────────
if ! command -v amass &> /dev/null; then
    info "Installing amass..."
    wget -q https://github.com/owasp-amass/amass/releases/download/v4.2.0/amass_Linux_amd64.zip
    unzip -q amass_Linux_amd64.zip -d /tmp/amass
    sudo mv /tmp/amass/amass_Linux_amd64/amass /usr/local/bin/
    rm -rf amass_Linux_amd64.zip /tmp/amass
fi

# ── Python venv + deps ─────────────────────────────────────
info "Setting up Python environment..."
INSTALL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_DIR"

python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q

info "Python dependencies installed"

# ── Config setup ──────────────────────────────────────────
if [ ! -f config/config.local.yaml ]; then
    cp config/config.yaml config/config.local.yaml
    warn "Created config/config.local.yaml"
    warn ">>> EDIT config/config.local.yaml and fill in:"
    warn "    - telegram.bot_token"
    warn "    - telegram.chat_id"
    warn "    - ai.api_key"
fi

# ── Data dirs ──────────────────────────────────────────────
mkdir -p data logs output/reports

# ── Systemd service ────────────────────────────────────────
info "Installing systemd service..."
CURRENT_USER=$(whoami)
INSTALL_PATH=$(pwd)

# Patch service file with real paths
sed -e "s|User=ubuntu|User=$CURRENT_USER|g" \
    -e "s|WorkingDirectory=/opt/bugbounty-engine|WorkingDirectory=$INSTALL_PATH|g" \
    -e "s|/opt/bugbounty-engine/venv|$INSTALL_PATH/venv|g" \
    -e "s|/opt/bugbounty-engine/config/config.local.yaml|$INSTALL_PATH/config/config.local.yaml|g" \
    bugbounty-engine.service > /tmp/bugbounty-engine.service

sudo cp /tmp/bugbounty-engine.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable bugbounty-engine

echo ""
echo "=================================================="
info "Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Edit your config:  nano config/config.local.yaml"
echo "  2. Start the engine:  sudo systemctl start bugbounty-engine"
echo "  3. Watch logs:        sudo journalctl -u bugbounty-engine -f"
echo ""
echo "  OR run directly:"
echo "  source venv/bin/activate"
echo "  python main.py start             # full engine"
echo "  python main.py scan example.com  # one-shot scan"
echo "  python main.py add example.com   # add target"
echo "  python main.py list              # list targets"
echo ""
warn "Remember: Only scan targets you have permission to test!"
echo "=================================================="
